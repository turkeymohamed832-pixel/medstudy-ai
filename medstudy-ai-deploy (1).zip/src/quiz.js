// Quiz / exam / flashcard generation (rule-based, offline) and grading.
//
// Trust model: a question is only auto-graded when its correctAnswer is stored with it.
// Rule-generated questions take their answer verbatim from the lecture text (or, for
// true/false, from a statement that is the lecture sentence itself or that sentence with one
// number replaced), so the answer is "verified against source". AI-generated questions are
// stored with verified:false until the user confirms them.

import { makeQuestion, makeFlashcard, ORIGIN } from './models.js';

const ARABIC_DIGITS = '٠١٢٣٤٥٦٧٨٩';
export const toWesternDigits = (s) => s.replace(/[٠-٩]/g, (d) => String(ARABIC_DIGITS.indexOf(d)));

/** Split text into sentences, keeping numbers like 2.5 and abbreviations (e.g. "Dr.") intact. */
export function splitSentences(text) {
  const clean = text.replace(/\n+/g, ' ').replace(/\s+/g, ' ').trim();
  const out = [];
  let buf = '';
  for (let i = 0; i < clean.length; i++) {
    const ch = clean[i];
    buf += ch;
    if (ch === '.' || ch === '!' || ch === '?' || ch === '؟') {
      const next = clean[i + 1];
      const prevWord = buf.split(/\s+/).pop();
      const isDecimal = ch === '.' && /\d/.test(clean[i - 1] || '') && /\d/.test(next || '');
      const isAbbrev = ch === '.' && /^(dr|mr|mrs|ms|e\.g|i\.e|vs|fig|approx|no|st)\.$/i.test(prevWord);
      if (!isDecimal && !isAbbrev && (next === undefined || next === ' ')) {
        out.push(buf.trim());
        buf = '';
      }
    }
  }
  if (buf.trim()) out.push(buf.trim());
  return out;
}

// numbers with an optional unit, e.g. "5 mg", "28 days", "2.5%", "35-40 weeks"
const NUM_RE = /\b\d+(?:[.,]\d+)?(?:\s?[-–]\s?\d+(?:[.,]\d+)?)?\s?(?:%|mg|mcg|µg|g|kg|ml|mL|L|IU|cm|mm|mmHg|days?|weeks?|months?|years?|hours?|hrs?|minutes?|mins?|cycles?)?\b%?/g;
const ACRONYM_RE = /\b[A-Z]{2,6}\b/g;
const TERM_RE = /\b[A-Za-z][A-Za-z-]{7,}\b/g;
const STOP = new Set(['however', 'therefore', 'although', 'because', 'between', 'including', 'following', 'patients', 'usually', 'sometimes', 'important', 'generally']);

/** Candidate answers inside a sentence, best first: numbers+units, acronyms, long terms. */
export function candidateBlanks(sentence) {
  const picks = [];
  for (const m of sentence.matchAll(NUM_RE)) {
    if (m[0].trim().length >= 1 && /\d/.test(m[0])) picks.push({ text: m[0].trim(), index: m.index, kind: 'number' });
  }
  for (const m of sentence.matchAll(ACRONYM_RE)) picks.push({ text: m[0], index: m.index, kind: 'acronym' });
  for (const m of sentence.matchAll(TERM_RE)) {
    if (!STOP.has(m[0].toLowerCase()) && m.index > 0) picks.push({ text: m[0], index: m.index, kind: 'term' });
  }
  return picks;
}

export function seededRandom(seed) {
  let s = 0;
  for (let i = 0; i < seed.length; i++) s = (s * 31 + seed.charCodeAt(i)) >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function shuffle(arr, rnd) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/**
 * Build cloze items from lecture pages. Each item: sentence with one blank + the verbatim answer.
 * pages: [{pageId, text, lectureId?}]
 */
export function buildClozeItems(pages, { max = 20, seed = 'seed' } = {}) {
  const items = [];
  for (const p of pages) {
    for (const sentence of splitSentences(p.text)) {
      if (sentence.length < 25 || sentence.length > 300) continue;
      const cands = candidateBlanks(sentence);
      if (!cands.length) continue;
      // prefer numbers (doses/durations matter most), then acronyms, then terms
      const rank = { number: 0, acronym: 1, term: 2 };
      cands.sort((a, b) => rank[a.kind] - rank[b.kind] || a.index - b.index);
      const c = cands[0];
      const prompt = sentence.slice(0, c.index) + '_____' + sentence.slice(c.index + c.text.length);
      items.push({ pageId: p.pageId, lectureId: p.lectureId, sentence, prompt, answer: c.text, kind: c.kind });
    }
  }
  const rnd = seededRandom(seed);
  for (let i = items.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [items[i], items[j]] = [items[j], items[i]];
  }
  return items.slice(0, max);
}

/**
 * Turn cloze items into Question records. When at least 3 other answers of the same kind
 * exist, make a 4-option MCQ (distractors come from other answers in the same lecture);
 * otherwise a typed-answer cloze. The correct answer is always the source text.
 * forceType: 'mcq' (skip items without enough distractors) | 'cloze' (always typed) | undefined (auto).
 */
export function buildQuestions(lectureId, items, { seed = 'q', quizId = null, forceType } = {}) {
  const rnd = seededRandom(seed);
  const byKind = {};
  for (const it of items) (byKind[it.kind] ||= new Set()).add(it.answer);
  const out = [];
  for (const it of items) {
    const pool = [...(byKind[it.kind] || [])].filter((a) => a.toLowerCase() !== it.answer.toLowerCase());
    const common = {
      lectureId: it.lectureId || lectureId, quizId, origin: ORIGIN.RULE, verified: true,
      sourceRef: { pageId: it.pageId, quote: it.sentence },
      explanation: it.sentence,
    };
    const canMcq = pool.length >= 3;
    if (forceType === 'mcq' && !canMcq) continue;
    if (canMcq && forceType !== 'cloze') {
      const distractors = shuffle(pool, rnd).slice(0, 3);
      const choices = shuffle([it.answer, ...distractors], rnd);
      out.push(makeQuestion({
        ...common, type: 'mcq', prompt: it.prompt, choices, correctAnswer: choices.indexOf(it.answer),
        difficulty: it.kind === 'number' ? 'medium' : 'easy',
      }));
    } else {
      out.push(makeQuestion({ ...common, type: 'cloze', prompt: it.prompt, correctAnswer: it.answer, difficulty: 'hard' }));
    }
  }
  return out;
}

// ---------- true / false ----------

const numCore = (s) => toWesternDigits(s).replace(/[^\d.,\-–]/g, '').replace(',', '.');

/**
 * True/false items. A TRUE item is a lecture sentence verbatim. A FALSE item is the same
 * sentence with ONE number swapped for a different number found elsewhere in the lecture; the
 * original sentence (the source) is kept so the answer is always checkable.
 */
export function buildTrueFalseItems(pages, { max = 20, seed = 'tf' } = {}) {
  const rnd = seededRandom(seed);
  const base = [];
  const numbers = [];
  for (const p of pages) {
    for (const sentence of splitSentences(p.text)) {
      if (sentence.length < 25 || sentence.length > 300) continue;
      const c = candidateBlanks(sentence).find((x) => x.kind === 'number');
      if (!c) continue;
      base.push({ pageId: p.pageId, lectureId: p.lectureId, sentence, c });
      numbers.push(c.text);
    }
  }
  const items = [];
  for (const b of shuffle(base, rnd)) {
    const pool = [...new Set(numbers)].filter((n) => numCore(n) !== numCore(b.c.text));
    // prefer a replacement with the same unit suffix so the false statement looks plausible
    const unit = b.c.text.replace(/[\d.,\-–\s]/g, '');
    const same = pool.filter((n) => n.replace(/[\d.,\-–\s]/g, '') === unit);
    const choose = same.length ? same : pool;
    const makeFalse = choose.length > 0 && rnd() < 0.5;
    if (makeFalse) {
      const rep = choose[Math.floor(rnd() * choose.length)];
      const statement = b.sentence.slice(0, b.c.index) + rep + b.sentence.slice(b.c.index + b.c.text.length);
      items.push({ pageId: b.pageId, lectureId: b.lectureId, statement, truth: false, sentence: b.sentence, answer: b.c.text, replacement: rep });
    } else {
      items.push({ pageId: b.pageId, lectureId: b.lectureId, statement: b.sentence, truth: true, sentence: b.sentence, answer: b.c.text, replacement: null });
    }
  }
  return items.slice(0, max);
}

export function buildTrueFalseQuestions(lectureId, items, { quizId = null } = {}) {
  return items.map((it) => makeQuestion({
    lectureId: it.lectureId || lectureId, quizId, type: 'tf', prompt: it.statement, choices: [],
    correctAnswer: it.truth ? 0 : 1, explanation: it.sentence, origin: ORIGIN.RULE, verified: true,
    sourceRef: { pageId: it.pageId, quote: it.sentence }, difficulty: 'hard',
  }));
}

// ---------- definitions and abbreviations ----------

const DEF_RE = /^([A-Z][A-Za-z0-9\-/' ]{2,50}?)\s+(?:is|are|means|refers to|is defined as|are defined as|is known as|are known as)\s+(.{15,})$/;
const PRONOUNS = new Set(['it', 'this', 'that', 'these', 'those', 'there', 'he', 'she', 'they', 'we', 'which', 'what', 'who']);

export function buildDefinitionItems(pages, { max = 20, seed = 'def' } = {}) {
  const out = [];
  for (const p of pages) {
    for (const sentence of splitSentences(p.text)) {
      if (sentence.length < 30 || sentence.length > 300) continue;
      const m = DEF_RE.exec(sentence);
      if (!m) continue;
      const term = m[1].trim();
      const words = term.split(/\s+/);
      if (words.length > 6 || PRONOUNS.has(words[0].toLowerCase())) continue;
      out.push({ pageId: p.pageId, lectureId: p.lectureId, term, sentence });
    }
  }
  const rnd = seededRandom(seed);
  return shuffle(out, rnd).slice(0, max);
}

const ABBR_RE = /([A-Za-z][A-Za-z-]*(?:\s+[A-Za-z][A-Za-z-]*){0,7})\s*\(([A-Z]{2,8})\)/g;

/** Find "Expansion words (ABC)" where the initials really spell the abbreviation. Never guesses. */
export function buildAbbreviationItems(pages, { max = 20, seed = 'abbr' } = {}) {
  const out = [];
  const seen = new Set();
  for (const p of pages) {
    for (const sentence of splitSentences(p.text)) {
      for (const m of sentence.matchAll(ABBR_RE)) {
        const abbr = m[2];
        const words = m[1].split(/[\s]+/).flatMap((w) => w.split('-')).filter(Boolean);
        let expansion = null;
        for (let k = abbr.length; k <= Math.min(words.length, abbr.length + 2); k++) {
          const tail = words.slice(words.length - k);
          const initials = tail.map((w) => w[0].toUpperCase()).join('');
          const major = tail.filter((w) => !/^(of|the|and|in|for|to|a|an)$/i.test(w)).map((w) => w[0].toUpperCase()).join('');
          if (initials === abbr || major === abbr) {
            expansion = m[1].trim().split(/\s+/).slice(-k).join(' ');
            break;
          }
        }
        if (!expansion || seen.has(abbr)) continue;
        seen.add(abbr);
        out.push({ pageId: p.pageId, lectureId: p.lectureId, abbr, expansion, sentence });
      }
    }
  }
  const rnd = seededRandom(seed);
  return shuffle(out, rnd).slice(0, max);
}

// ---------- flashcards ----------

const CLOZE_KIND_TO_CARD = { number: 'number', acronym: 'abbreviation', term: 'term' };

/** Flashcards from cloze items: front = sentence with blank, back = answer + full sentence. */
export function buildFlashcards(lectureId, items) {
  return items.map((it) =>
    makeFlashcard({
      lectureId: it.lectureId || lectureId, front: it.prompt, back: `${it.answer}\n\n${it.sentence}`,
      kind: CLOZE_KIND_TO_CARD[it.kind] || 'general',
      origin: ORIGIN.RULE, sourceRef: { pageId: it.pageId, quote: it.sentence },
    }));
}

export const CARD_KINDS = ['number', 'abbreviation', 'definition', 'term'];

/**
 * Cards by kind (numbers/values, abbreviations, definitions, general terms). Every card's answer is
 * verbatim from the lecture. kinds: array of CARD_KINDS; the max is split round-robin across kinds.
 */
export function buildCardsByKind(lectureId, pages, { kinds = CARD_KINDS, max = 10, seed = 'cards' } = {}) {
  const lists = {};
  const all = buildClozeItems(pages, { max: 100000, seed });
  if (kinds.includes('number')) lists.number = buildFlashcards(lectureId, all.filter((i) => i.kind === 'number'));
  if (kinds.includes('term')) lists.term = buildFlashcards(lectureId, all.filter((i) => i.kind === 'term' || i.kind === 'acronym'));
  if (kinds.includes('abbreviation')) {
    lists.abbreviation = buildAbbreviationItems(pages, { max: 100000, seed }).map((it) => makeFlashcard({
      lectureId: it.lectureId || lectureId, front: `What does ${it.abbr} stand for?`, back: `${it.expansion}\n\n${it.sentence}`,
      kind: 'abbreviation', origin: ORIGIN.RULE, sourceRef: { pageId: it.pageId, quote: it.sentence },
    }));
  }
  if (kinds.includes('definition')) {
    lists.definition = buildDefinitionItems(pages, { max: 100000, seed }).map((it) => makeFlashcard({
      lectureId: it.lectureId || lectureId, front: `Define: ${it.term}`, back: it.sentence,
      kind: 'definition', origin: ORIGIN.RULE, sourceRef: { pageId: it.pageId, quote: it.sentence },
    }));
  }
  const queues = Object.values(lists).map((l) => [...l]);
  const out = [];
  while (out.length < max && queues.some((q) => q.length)) {
    for (const q of queues) {
      if (out.length >= max) break;
      if (q.length) out.push(q.shift());
    }
  }
  return out;
}

// ---------- exams ----------

/**
 * Build exam questions from lecture pages (not saved). pages: [{lectureId,pageId,text}].
 * difficulty: 'easy' (MCQ over terms/abbreviations) | 'medium' (MCQ over numbers) |
 * 'hard' (typed answers + true/false number swaps) | 'mixed'.  types: any of mcq, tf, cloze.
 * Returns fewer questions than asked when the lecture has too little content; it never pads with invented ones.
 */
export function buildExamQuestions(pages, { count = 10, difficulty = 'mixed', types = ['mcq', 'tf', 'cloze'], seed = 'exam', topic = '' } = {}) {
  const t = topic.trim().toLowerCase();
  const pool = t ? pages.filter((p) => p.text.toLowerCase().includes(t)) : pages;
  const lectureId = pool[0]?.lectureId || pages[0]?.lectureId || 'x';
  const items = buildClozeItems(pool, { max: 100000, seed });
  const termy = items.filter((i) => i.kind !== 'number');
  const numy = items.filter((i) => i.kind === 'number');
  const lists = {};
  if (types.includes('mcq')) {
    const src = difficulty === 'easy' ? (termy.length ? termy : items) : difficulty === 'medium' ? (numy.length ? numy : items) : items;
    if (difficulty !== 'hard') lists.mcq = buildQuestions(lectureId, src, { seed, forceType: 'mcq' });
  }
  if (types.includes('cloze') && (difficulty === 'hard' || difficulty === 'mixed' || !types.includes('mcq'))) {
    lists.cloze = buildQuestions(lectureId, items, { seed: seed + 'c', forceType: 'cloze' });
  }
  if (types.includes('tf') && difficulty !== 'easy') {
    lists.tf = buildTrueFalseQuestions(lectureId, buildTrueFalseItems(pool, { max: 100000, seed: seed + 't' }));
  }
  const queues = Object.values(lists).map((l) => [...l]);
  const out = [];
  const seen = new Set();
  while (out.length < count && queues.some((q) => q.length)) {
    for (const q of queues) {
      if (out.length >= count) break;
      while (q.length) {
        const cand = q.shift();
        if (!seen.has(cand.prompt)) { seen.add(cand.prompt); out.push(cand); break; }
      }
    }
  }
  return out;
}

const norm = (s) => toWesternDigits(String(s)).trim().replace(/\s+/g, ' ').toLowerCase();

/**
 * Grade an objective question against its stored answer.
 * Returns { gradable, correct, expected }. Essay questions are not auto-graded.
 */
export function grade(question, response) {
  switch (question.type) {
    case 'mcq': {
      if (typeof question.correctAnswer !== 'number') return { gradable: false, correct: null, expected: null };
      const correct = Number(response) === question.correctAnswer;
      return { gradable: true, correct, expected: question.choices[question.correctAnswer] ?? String(question.correctAnswer) };
    }
    case 'tf': {
      if (typeof question.correctAnswer !== 'number') return { gradable: false, correct: null, expected: null };
      return { gradable: true, correct: Number(response) === question.correctAnswer, expected: question.correctAnswer === 0 ? 'True' : 'False' };
    }
    case 'cloze': {
      if (typeof question.correctAnswer !== 'string') return { gradable: false, correct: null, expected: null };
      // numbers must match exactly; spacing/case ignored ("5 mg" == "5mg" is accepted)
      const strip = (s) => norm(s).replace(/\s+/g, '');
      return { gradable: true, correct: strip(response ?? '') === strip(question.correctAnswer), expected: question.correctAnswer };
    }
    default:
      return { gradable: false, correct: null, expected: question.correctAnswer };
  }
}

/**
 * Score a finished attempt: [{question, response, selfRating?}] -> counts.
 * Objective questions are graded against the stored answer. Essays count only when the student
 * rated themselves (0, 0.5 or 1); unrated essays are excluded. Ungradable items are excluded.
 */
export function scoreAttempt(entries) {
  let correct = 0, graded = 0;
  const results = entries.map(({ question, response, selfRating }) => {
    const g = grade(question, response);
    if (g.gradable) {
      graded++;
      if (g.correct) correct++;
      return { questionId: question.id, ...g };
    }
    if (question.type === 'essay' && (selfRating === 0 || selfRating === 0.5 || selfRating === 1)) {
      graded++;
      correct += selfRating;
      return { questionId: question.id, gradable: true, correct: selfRating === 1, partial: selfRating === 0.5, expected: question.correctAnswer, selfGraded: true };
    }
    return { questionId: question.id, ...g };
  });
  return { correct, graded, total: entries.length, percent: graded ? Math.round((correct / graded) * 100) : null, results };
}
