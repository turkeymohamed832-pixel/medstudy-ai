// Plan storage helpers (UI-free): the plan is the set of studyTasks; settings keep exam date + daily minutes.
import { makeStudyTask } from './models.js';
import { generatePlanV2, redistribute, postponeTask, addDays, dateStr } from './planner.js';
import { onTaskDone } from './activity.js';

export async function buildPlan(store, { exam, dailyMinutes, lectureIds, today = dateStr(new Date()), labels }) {
  const lectures = (await store.getAll('lectures')).filter((l) => !l.isDemo && lectureIds.includes(l.id));
  const progress = new Map((await store.getAll('learningProgress')).map((p) => [p.lectureId, p]));
  const answers = await store.getAll('answers');
  const wrongBy = new Map();
  for (const a of answers) if (a.correct === false && a.lectureId) wrongBy.set(a.lectureId, (wrongBy.get(a.lectureId) || 0) + 1);
  const input = [];
  for (const l of lectures) {
    const pages = (await store.getAllBy('sourcePages', 'lectureId', l.id)).filter((p) => p.status !== 'removed_in_update');
    const read = new Set(progress.get(l.id)?.pagesRead || []);
    input.push({ id: l.id, title: l.title, pageCount: pages.length, unreadPages: pages.filter((p) => !read.has(p.id)).length, priority: (wrongBy.get(l.id) || 0) + (l.examTag ? 1 : 0) });
  }
  const plan = generatePlanV2({ lectures: input, start: today, exam, dailyMinutes, labels });
  return plan;
}

export async function savePlan(store, tasks) {
  const old = await store.getAll('studyTasks');
  for (const t of old) await store.delete('studyTasks', t.id);
  await store.put('studyTasks', tasks.map((t) => makeStudyTask(t)));
}

export async function toggleTask(store, task) {
  const done = !task.done;
  const next = { ...task, done, doneAt: done ? (task.doneAt || new Date().toISOString()) : task.doneAt };
  await store.put('studyTasks', next);
  if (done && !task.doneAt) await onTaskDone(store, new Date()); // XP only on the first completion
  return next;
}

export async function postpone(store, task, days = 1) {
  const base = task.dueDate || dateStr(new Date());
  const next = postponeTask(task, addDays(base, days));
  await store.put('studyTasks', next);
  return next;
}

export async function redistributePlan(store, { exam, dailyMinutes, today = dateStr(new Date()) }) {
  const tasks = await store.getAll('studyTasks');
  const r = redistribute({ tasks, today, exam, dailyMinutes });
  const changed = r.tasks.filter((t) => r.moved.includes(t.id));
  if (changed.length) await store.put('studyTasks', changed);
  return r;
}
