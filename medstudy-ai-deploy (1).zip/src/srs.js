// Spaced repetition (SM-2 variant). Pure functions, no storage.
// Ratings: 'again' (0-2 quality => relearn), 'hard' (3), 'good' (4), 'easy' (5).

export const RATINGS = { again: 1, hard: 3, good: 4, easy: 5 };
const DAY = 24 * 60 * 60 * 1000;

export function review(schedule, rating, now = new Date()) {
  const q = RATINGS[rating];
  if (q === undefined) throw new Error(`Unknown rating: ${rating}`);
  let { ease, intervalDays, repetitions, lapses } = schedule;
  if (q < 3) {
    repetitions = 0;
    lapses += 1;
    intervalDays = 0; // see again today (next session), tracked via due = now + 10 min
  } else {
    repetitions += 1;
    if (repetitions === 1) intervalDays = rating === 'easy' ? 4 : 1;
    else if (repetitions === 2) intervalDays = rating === 'hard' ? 3 : 6;
    else {
      const factor = rating === 'hard' ? 1.2 : rating === 'easy' ? ease * 1.3 : ease;
      intervalDays = Math.max(intervalDays + 1, Math.round(intervalDays * factor));
    }
  }
  ease = Math.max(1.3, ease + 0.1 - (5 - q) * (0.08 + (5 - q) * 0.02));
  const due = q < 3 ? new Date(now.getTime() + 10 * 60 * 1000) : new Date(now.getTime() + intervalDays * DAY);
  return {
    ...schedule,
    ease: Math.round(ease * 100) / 100,
    intervalDays,
    repetitions,
    lapses,
    due: due.toISOString(),
    lastReviewed: now.toISOString(),
  };
}

export const isDue = (s, now = new Date()) => new Date(s.due).getTime() <= now.getTime();

/** Preview of the next interval for each button, shown on the buttons themselves. */
export function previewIntervals(schedule, now = new Date()) {
  const out = {};
  for (const r of Object.keys(RATINGS)) {
    const n = review(schedule, r, now);
    out[r] = r === 'again' ? 10 / (24 * 60) : n.intervalDays;
  }
  return out;
}

export function formatInterval(days, lang = 'ar') {
  const ar = lang !== 'en';
  if (days < 1) return ar ? '10 د' : '10 min';
  if (days === 1) return ar ? 'يوم' : '1 d';
  if (days < 30) return ar ? `${days} يوم` : `${days} d`;
  const m = Math.round(days / 30);
  return ar ? `${m} شهر` : `${m} mo`;
}

/** Mastery of one card in 0..1: unreviewed = 0, grows with the interval, full at 21+ days. */
export const cardMastery = (s) => (!s || !s.lastReviewed ? 0 : Math.min(1, s.intervalDays / 21));

/** Real review stats only; returns zeros when there is no data. */
export function scheduleStats(schedules, now = new Date()) {
  let due = 0, fresh = 0, learning = 0, mature = 0;
  for (const s of schedules) {
    if (!s.lastReviewed) fresh++;
    else if (s.intervalDays >= 21) mature++;
    else learning++;
    if (isDue(s, now)) due++;
  }
  return { total: schedules.length, due, new: fresh, learning, mature };
}
