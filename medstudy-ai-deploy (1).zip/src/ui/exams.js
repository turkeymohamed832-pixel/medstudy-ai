import { h, mount, toast } from '../dom.js';
import { t } from '../i18n.js';
import { ctx } from '../ctx.js';
import { loadSnapshot } from '../stats-data.js';
import { loadPagesOf, buildCustomExam, attemptsHistory, wrongQuestionsOf, saveAiQuiz, saveEssayQuestions } from '../study.js';
import { buildExamQuestions } from '../quiz.js';
import { generateAiQuestions, generateAiEssays } from '../ai.js';
import { chip, notice, btn, empty, skeleton, pageHead, section } from './common.js';
import { aiSettings, aiMessage } from './ai-ui.js';
import { runQuestions } from './runner.js';
import { modal as modalFn } from '../dom.js';

export async function renderExams(root, { query }) {
  mount(root, skeleton(3));
  const lectures = (await ctx.store.getAll('lectures')).sort((a, b) => a.title.localeCompare(b.title));
  const snap = await loadSnapshot(ctx.store, new Date());
  if (query.get('weak')) return weakExam(root, snap, lectures);
  const sel = new Set(query.get('lecture') ? [query.get('lecture')] : []);
  const state = { count: 10, difficulty: 'mixed', types: new Set(['mcq', 'tf', 'cloze']), topic: '', minutes: 0 };
  const view = h('div', { class: 'stack fade-in' });
  view.append(pageHead(t('nav.exams'), t('ex.sub')));
  if (!lectures.length) { mount(root, view, empty('📝', t('ex.emptyTitle'), t('ex.emptyText'), btn(t('home.importFirst'), () => ctx.navigate('#/import'), 'primary'))); return; }

  const lecList = h('div', { class: 'list' }, lectures.map((l) => h('label', { class: 'item' }, h('input', { type: 'checkbox', checked: sel.has(l.id), onchange: (e) => { e.target.checked ? sel.add(l.id) : sel.delete(l.id); } }), h('div', { class: 'grow' }, h('b', null, l.title), h('div', { class: 'tiny' }, `${l.examTag ? `🎓 ${l.examTag} · ` : ''}${l.pageCount} ${t('ex.pages')}`)), l.isDemo ? chip(t('lib.demo'), 'warn') : null)));
  const num = h('select', { 'aria-label': t('ex.count'), onchange: (e) => { state.count = Number(e.target.value); } }, [5, 10, 15, 20, 30, 50].map((n) => h('option', { value: n, selected: n === 10 }, String(n))));
  const diff = h('select', { 'aria-label': t('ex.difficulty'), onchange: (e) => { state.difficulty = e.target.value; } }, ['mixed', 'easy', 'medium', 'hard'].map((d) => h('option', { value: d }, t(`ex.diff.${d}`))));
  const tm = h('select', { 'aria-label': t('ex.timer'), onchange: (e) => { state.minutes = Number(e.target.value); } }, [0, 10, 20, 30, 45, 60, 90].map((m) => h('option', { value: m }, m ? t('ex.minutes', { n: m }) : t('ex.noTimer'))));
  const topic = h('input', { type: 'text', placeholder: t('ex.topicPh'), 'aria-label': t('ex.topic'), oninput: (e) => { state.topic = e.target.value; } });
  const types = h('div', { class: 'row' }, ['mcq', 'tf', 'cloze', 'essay'].map((k) => h('label', { class: 'chip' }, h('input', { type: 'checkbox', checked: state.types.has(k), onchange: (e) => { e.target.checked ? state.types.add(k) : state.types.delete(k); } }), ` ${t(`ex.type.${k}`)}`)));
  const msg = h('div', { 'aria-live': 'polite' });

  async function start() {
    const ids = [...sel];
    if (!ids.length) { mount(msg, notice(t('ex.pickLecture'), 'bad')); return; }
    mount(msg, skeleton(1));
    const { questions, pagesUsed } = await buildCustomExam(ctx.store, { lectureIds: ids, count: state.count, difficulty: state.difficulty, types: [...state.types].filter((x) => x !== 'essay'), topic: state.topic });
    let qs = questions;
    if (state.types.has('essay')) {
      const all = await ctx.store.getAll('questions');
      const essays = all.filter((q) => q.type === 'essay' && ids.includes(q.lectureId)).slice(0, Math.max(1, Math.round(state.count / 5)));
      qs = [...qs, ...essays];
    }
    if (!qs.length) { mount(msg, notice(t('ex.notEnough', { pages: pagesUsed }), 'bad')); return; }
    const demo = ids.every((id) => lectures.find((l) => l.id === id)?.isDemo);
    const go = () => runQuestions(root, { title: t('ex.customTitle', { n: qs.length }), questions: qs, lectureIds: ids, kind: 'exam', config: { count: state.count, difficulty: state.difficulty, types: [...state.types], topic: state.topic }, timeLimitSec: state.minutes ? state.minutes * 60 : null, demo });
    if (qs.length < state.count) { mount(msg, notice(t('ex.fewer', { got: qs.length, want: state.count }), 'info'), btn(t('ex.startAnyway'), go, 'primary')); return; }
    go();
  }
  view.append(h('div', { class: 'card stack' }, h('h3', null, t('ex.build')), lecList,
    h('div', { class: 'grid two' }, h('label', { class: 'field' }, h('span', null, t('ex.count')), num), h('label', { class: 'field' }, h('span', null, t('ex.difficulty')), diff), h('label', { class: 'field' }, h('span', null, t('ex.timer')), tm), h('label', { class: 'field' }, h('span', null, `${t('ex.topic')} (${t('common.optional')})`), topic)),
    types, notice(t('ex.sourceOnly'), 'info'), btn(`▶ ${t('ex.start')}`, start, 'primary big'), msg));

  // weak points entry
  view.append(h('div', { class: 'card tint-coral row between' }, h('div', null, h('b', null, `🎯 ${t('ex.weakExam')}`), h('div', { class: 'small muted' }, snap.weak.length ? t('ex.weakHave', { n: snap.weak.length }) : t('ex.weakNone'))), btn(t('ex.start'), () => ctx.navigate('#/exams?weak=1'), 'soft', { disabled: !snap.weak.length })));

  // AI generated questions (clearly unverified)
  const ai = h('div', { class: 'card stack' }, h('h3', null, `🤖 ${t('ex.aiGen')}`), notice(t('ex.aiGenNote')));
  const aiMsg = h('div', { 'aria-live': 'polite' });
  const aiGen = async (kind) => {
    const ids = [...sel];
    if (ids.length !== 1) { mount(aiMsg, notice(t('ex.aiOne'), 'bad')); return; }
    mount(aiMsg, skeleton(1));
    try {
      const pages = (await loadPagesOf(ctx.store, ids)).filter((p) => p.text);
      const text = pages.map((p) => p.text).join('\n\n').slice(0, 9000);
      if (kind === 'mcq') {
        const r = await generateAiQuestions(aiSettings(), text, 5);
        if (!r.questions.length) throw new Error(t('ex.aiNone'));
        await saveAiQuiz(ctx.store, ids[0], r.questions, { title: 'AI quiz', model: r.model });
        mount(aiMsg, notice(t('ex.aiSaved', { n: r.questions.length, d: r.dropped }), 'ok'));
      } else {
        const r = await generateAiEssays(aiSettings(), text, 3);
        if (!r.items.length) throw new Error(t('ex.aiNone'));
        await saveEssayQuestions(ctx.store, ids[0], r.items, { origin: 'ai', model: r.model });
        mount(aiMsg, notice(t('ex.aiSaved', { n: r.items.length, d: r.dropped }), 'ok'));
      }
    } catch (e) { mount(aiMsg, notice(e.code ? aiMessage(e) : e.message, 'bad')); }
  };
  ai.append(h('div', { class: 'row' }, btn(t('ex.aiMcq'), () => aiGen('mcq'), 'soft sm'), btn(t('ex.aiEssay'), () => aiGen('essay'), 'soft sm')), aiMsg);
  view.append(ai);

  // history
  const attempts = (await attemptsHistory(ctx.store)).reverse();
  view.append(section(t('ex.history')));
  if (!attempts.length) view.append(h('div', { class: 'muted small' }, t('ex.noHistory')));
  else {
    view.append(h('div', { class: 'card' }, h('div', { class: 'tiny' }, t('ex.trend')), h('div', { class: 'row', style: { alignItems: 'flex-end', flexWrap: 'nowrap', height: '70px' } }, [...attempts].reverse().slice(-14).map((a) => { const i = h('i', { title: `${a.percent ?? '—'}%` }); i.style.display = 'block'; i.style.width = '100%'; i.style.height = `${Math.max(4, a.percent ?? 4) * 0.7}px`; i.style.background = 'var(--primary)'; i.style.borderRadius = '6px 6px 0 0'; const w = h('div', { style: { flex: '1' } }, i); return w; }))));
    for (const a of attempts.slice(0, 30)) view.append(attemptRow(a, root));
  }
  mount(root, view);
}

function attemptRow(a, root) {
  const lec = a.lectureIds.length === 1 ? a.lectureIds[0] : null;
  return h('button', { type: 'button', class: 'item', onclick: () => openAttempt(a, root) },
    h('div', { class: 'grow' }, h('b', null, a.title), h('div', { class: 'tiny' }, `${a.finishedAt.slice(0, 16).replace('T', ' ')} · ${t('ex.qs', { n: a.entries.length })}${a.timedOut ? ` · ⏱ ${t('ex.timeUp')}` : ''}`)),
    chip(a.percent === null ? '—' : `${a.percent}%`, a.percent === null ? '' : a.percent >= 70 ? 'ok' : a.percent >= 50 ? 'warn' : 'bad'));
}
async function openAttempt(a, root) {
  const wrong = await wrongQuestionsOf(ctx.store, a);
  const qs = new Map((await ctx.store.getAll('questions')).map((q) => [q.id, q]));
  modalFn((close) => h('div', { class: 'stack' }, h('h3', null, a.title), h('div', { class: 'small muted' }, `${a.finishedAt.slice(0, 16).replace('T', ' ')} · ${a.correct}/${a.graded} · ${a.percent ?? '—'}%`),
    h('div', { class: 'list', style: { maxHeight: '45vh', overflow: 'auto' } }, wrong.length ? wrong.map((q) => h('div', { class: 'card flat small ltr' }, `✘ ${q.prompt}`)) : h('div', { class: 'muted' }, t('ex.noWrong'))),
    h('div', { class: 'row' }, wrong.length ? btn(`🔁 ${t('ex.retakeWrong', { n: wrong.length })}`, () => { close(); runQuestions(root, { title: `${t('ex.retakeTitle')}: ${a.title}`, questions: wrong, lectureIds: a.lectureIds, kind: 'retake', config: { from: a.id } }); }, 'primary') : null, btn(t('common.close'), () => close(), 'ghost'))));
}

async function weakExam(root, snap, lectures) {
  const view = h('div', { class: 'stack fade-in' }, pageHead(t('ex.weakExam'), t('ex.weakSub')));
  if (!snap.weak.length) { mount(root, view, empty('🎯', t('ex.weakNone'), t('ex.weakNoneText'), btn(t('nav.exams'), () => ctx.navigate('#/exams'), 'primary'))); return; }
  const pageIds = new Set(snap.weak.map((w) => w.pageId));
  const lecIds = [...new Set(snap.weak.map((w) => w.lectureId))];
  const pages = (await loadPagesOf(ctx.store, lecIds)).filter((p) => pageIds.has(p.pageId) && p.text);
  const allQ = await ctx.store.getAll('questions');
  const wrongIds = new Set(snap.answers.filter((a) => a.correct === false).map((a) => a.questionId));
  const wrongQs = allQ.filter((q) => wrongIds.has(q.id) && q.type !== 'essay');
  const fresh = buildExamQuestions(pages, { count: 10, difficulty: 'mixed', types: ['mcq', 'tf', 'cloze'], seed: `weak:${Date.now()}` });
  const seen = new Set(); const qs = [];
  for (const q of [...wrongQs.slice(0, 8), ...fresh]) { if (!seen.has(q.prompt)) { seen.add(q.prompt); qs.push(q); } if (qs.length >= 12) break; }
  if (!qs.length) { mount(root, view, notice(t('ex.notEnough', { pages: pages.length }), 'bad')); return; }
  runQuestions(root, { title: t('ex.weakTitle'), questions: qs, lectureIds: lecIds, kind: 'weak', config: { weak: true }, demo: false });
}
