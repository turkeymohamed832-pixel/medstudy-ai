import { h, mount, toast } from '../dom.js';
import { t } from '../i18n.js';
import { ctx } from '../ctx.js';
import { extractFiles, saveNewLecture, reimportLecture, findDuplicate, MAX_FILE_BYTES } from '../importer.js';
import { makeSubject } from '../models.js';
import { pageHead, notice, btn, bar, chip } from './common.js';
import { afterActivity } from './common.js';
import { checkAchievements } from '../activity.js';

// files dropped on the library are handed over here (module state, nothing persisted)
let staged = [];
export const stagedFiles = { set: (f) => { staged = f; }, take: () => { const f = staged; staged = []; return f; } };

const readFile = async (f) => ({ name: f.name, data: new Uint8Array(await f.arrayBuffer()), blob: f, size: f.size });

export async function renderImport(root) {
  const subjects = await ctx.store.getAll('subjects');
  let files = stagedFiles.take();
  const view = h('div', { class: 'stack fade-in' });
  const fileList = h('div', { class: 'list' });
  const status = h('div', { 'aria-live': 'polite' });
  const picker = h('input', { type: 'file', multiple: true, accept: '.pdf,.pptx,.png,.jpg,.jpeg,.webp,.txt,.md,image/*', class: 'sr-only', id: 'filepick', onchange: (e) => { files = [...e.target.files]; drawFiles(); } });
  const subjSel = h('select', { 'aria-label': t('imp.subject') }, subjects.filter((s) => !s.isDemo).map((s) => h('option', { value: s.id }, s.name)), h('option', { value: '__new' }, `＋ ${t('imp.newSubject')}`));
  if (!subjects.filter((s) => !s.isDemo).length) subjSel.value = '__new';
  const newSubj = h('input', { type: 'text', placeholder: t('imp.subjectName'), 'aria-label': t('imp.subjectName') });
  const title = h('input', { type: 'text', placeholder: t('imp.titlePh'), 'aria-label': t('imp.title') });
  const exam = h('input', { type: 'text', placeholder: t('imp.examPh'), list: 'examtags', 'aria-label': t('imp.exam') });
  const tags = h('datalist', { id: 'examtags' }, ['Midterm', 'Final', 'Quiz', 'Practical'].map((x) => h('option', { value: x })));
  const go = h('button', { type: 'button', class: 'btn primary big', onclick: run }, `⬇ ${t('imp.go')}`);
  const syncNew = () => { newSubj.hidden = subjSel.value !== '__new'; };
  subjSel.addEventListener('change', syncNew);

  function drawFiles() {
    mount(fileList, files.map((f) => h('div', { class: 'item' }, h('div', { class: 'grow' }, h('b', { class: 'ltr' }, f.name), h('div', { class: 'tiny' }, `${(f.size / 1048576).toFixed(1)} MB`)),
      f.size > 30 * 1048576 ? chip(t('imp.big'), 'warn') : null, f.size > MAX_FILE_BYTES ? chip(t('imp.tooBig'), 'bad') : null)));
    go.disabled = !files.length;
    if (files.length === 1 && !title.value) title.value = files[0].name.replace(/\.[^.]+$/, '');
  }
  const drop = h('div', { class: 'drop' }, h('div', { class: 'big' }, '📎'), h('b', null, t('imp.pick')), h('div', { class: 'small muted' }, t('imp.formats')),
    h('div', { style: { marginBlockStart: '.6rem' } }, h('label', { class: 'btn primary', for: 'filepick' }, t('lib.chooseFiles'))));
  ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', (e) => { files = [...e.dataTransfer.files]; drawFiles(); });

  async function run() {
    go.disabled = true;
    try {
      if (files.some((f) => f.size > MAX_FILE_BYTES)) throw new Error(t('imp.tooBig'));
      mount(status, h('div', { class: 'card stack' }, h('b', null, t('imp.reading')), h('div', { class: 'skeleton', style: { height: '12px' } }), h('div', { class: 'small muted' }, t('imp.readingNote'))));
      const loaded = await Promise.all(files.map(readFile));
      let result;
      try { result = await extractFiles(loaded, ctx.loaders); } catch (e) {
        if (e.message === 'NO_FILE') throw new Error(t('imp.errNoFile'));
        if (e.message === 'MULTI_NON_IMAGE') throw new Error(t('imp.errMulti'));
        throw e;
      }
      let subjectId = subjSel.value;
      if (subjectId === '__new') {
        const name = newSubj.value.trim();
        if (!name) throw new Error(t('imp.errSubject'));
        const s = makeSubject({ name }); await ctx.store.put('subjects', s); subjectId = s.id;
      }
      const dup = await findDuplicate(ctx.store, result.sourceHash);
      const ttl = title.value.trim() || loaded[0].name.replace(/\.[^.]+$/, '');
      const blob = loaded.length === 1 ? loaded[0].blob : null;
      if (dup) { showDuplicate(dup, result, { subjectId, ttl, blob }); return; }
      await finish(result, { subjectId, ttl, blob });
    } catch (e) {
      mount(status, notice(`${t('imp.failed')}: ${e.message}`, 'bad'));
      go.disabled = false;
    }
  }
  async function finish(result, { subjectId, ttl, blob }) {
    const lec = await saveNewLecture(ctx.store, { subjectId, title: ttl, fileName: files[0].name, result, fileBlob: blob, examTag: exam.value });
    afterActivity(ctx, checkAchievements, toast);
    summary(lec, result);
  }
  function showDuplicate(dup, result, o) {
    mount(status, h('div', { class: 'card stack' }, notice(t('imp.dup', { title: dup.title }), 'info'),
      h('div', { class: 'row' },
        btn(t('imp.dupOpen'), () => ctx.navigate(`#/lecture/${dup.id}`), 'primary'),
        btn(t('imp.dupReimport'), async () => { await reimportLecture(ctx.store, dup.id, result); toast(t('imp.updated')); ctx.navigate(`#/lecture/${dup.id}`); }, 'soft'),
        btn(t('imp.dupNew'), () => finish(result, o), 'ghost'))));
  }
  function summary(lec, result) {
    const bad = result.pages.filter((p) => p.status !== 'ok');
    mount(status, h('div', { class: 'card stack' },
      notice(bad.length ? t('imp.partial', { ok: result.pages.length - bad.length, total: result.pages.length }) : t('imp.allOk', { total: result.pages.length }), bad.length ? '' : 'ok'),
      ...result.warnings.map((w) => notice(String(w))),
      bad.length ? h('div', null, h('b', null, t('imp.problemPages')), h('ul', null, bad.map((p) => h('li', null, `${p.label || t('lecture.page', { n: p.index })}: ${p.warnings.join(' — ') || p.status}`)))) : null,
      result.pages.some((p) => p.warnings.length && p.status === 'ok') ? notice(t('imp.ocrReview')) : null,
      h('div', { class: 'row' }, btn(t('imp.open'), () => ctx.navigate(`#/lecture/${lec.id}`), 'primary'), btn(t('imp.another'), () => ctx.navigate('#/import'), 'ghost'))));
  }
  view.append(pageHead(t('imp.head'), t('imp.sub')), drop, picker, fileList,
    h('div', { class: 'card stack' }, h('label', { class: 'field' }, h('span', null, t('imp.subject')), subjSel, newSubj), h('label', { class: 'field' }, h('span', null, t('imp.title')), title),
      h('label', { class: 'field' }, h('span', null, `${t('imp.exam')} (${t('common.optional')})`), exam, tags), go),
    notice(t('imp.privacy'), 'info'), status);
  syncNew(); drawFiles(); mount(root, view);
}
