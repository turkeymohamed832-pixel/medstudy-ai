// Shared AI helpers for screens: settings access and honest, translated error messages (never a simulated answer).
import { t } from '../i18n.js';
import { ctx } from '../ctx.js';
import { AiError } from '../ai.js';

export const DEFAULT_AI = { endpoint: '/api/study', consent: false, accessCode: '' };
export const aiSettings = () => ({ ...DEFAULT_AI, ...(ctx.settings.ai || {}) });
export const aiReady = () => { const s = aiSettings(); return !!s.endpoint && !!s.consent; };
export function aiMessage(e) {
  if (e instanceof AiError) {
    const key = `ai.err.${e.code}`;
    const base = t(key);
    return e.code === 'http' && e.detail ? `${base} (${e.status}: ${e.detail})` : base;
  }
  return `${t('common.error')}: ${e.message}`;
}
export const warnText = (w) => {
  if (w.code === 'missing_numbers') return t('ai.warn.missing', { n: w.numbers.join(', ') });
  if (w.code === 'added_numbers') return t('ai.warn.added', { n: w.numbers.join(', ') });
  if (w.code === 'bad_citations') return t('ai.warn.badCitations', { n: w.numbers.join(', ') });
  if (w.code === 'no_citations') return t('ai.warn.noCitations');
  if (w.code === 'unstructured') return t('ai.warn.unstructured');
  return w.code;
};
/** Text shown next to generated content so the student always knows where it came from. */
export const provenanceLine = (row) => `${t('ai.generatedBy', { model: row.provenance?.model || '?' })} · ${(row.provenance?.generatedAt || row.createdAt || '').slice(0, 10)}`;
