import { h, mount, toast, modal, debounce } from '../dom.js';
import { t } from '../i18n.js';
import { ctx, setSetting } from '../ctx.js';
import { loadLecturePages, markPageOpened, toggleBookmark, addHighlight, generateCards, nextUnreadIndex } from '../study.js';
import { paragraphs, anchorHighlights, keyTokenRanges, segmentText, HL_COLORS } from '../reader-text.js';
import { searchPages, highlightRanges, findHeadings } from '../search.js';
import { makeTranslation, makeExplanation, makeStudyNote, makeOriginalText, ORIGIN, effectiveText } from '../models.js';
import { translatePage, explainPage, highYieldPage } from '../ai.js';
import { buildExamQuestions } from '../quiz.js';
import { checkAchievements } from '../activity.js';
import { bar, chip, notice, btn, link, empty, skeleton, afterActivity, confirmDialog, KIND_ICON } from './common.js';
import { aiSettings, aiMessage, warnText, provenanceLine } from './ai-ui.js';
import { runQuestions } from './runner.js';

let offSel = null;
const TABS = [['orig', 'rd.tab.orig'], ['ar', 'rd.tab.ar'], ['egy', 'rd.tab.egy'], ['hy', 'rd.tab.hy'], ['notes', 'rd.tab.notes']];

export async function renderLecture(root, { args, query }) {
  const lectureId = args[0];
  const lecture = await ctx.store.get('lectures', lectureId);
  if (!lecture) { mount(root, empty('🔍', t('rd.notFound'), '', link(t('nav.library'), '#/library', 'primary'))); return; }
  mount(root, skeleton(3));
  const pages = await loadLecturePages(ctx.store, lectureId);
  const subject = await ctx.store.get('subjects', lecture.subjectId);
  if (!pages.length) { mount(root, empty('📄', t('rd.noPages'))); return; }

  const state = {
    idx: Math.min(pages.length, Math.max(1, Number(query.get('p')) || await nextUnreadIndex(ctx.store, lectureId))),
    tab: query.get('tab') || 'orig', q: query.get('q') || '', showExtracted: false,
    fs: ctx.settings.readerFont || 1.05, lh: ctx.settings.readerLine || 1.9,
  };
  const cur = () => pages.find((p) => p.index === state.idx) || pages[0];
  const content = h('div', { class: 'stack' });
  const navBox = h('div');
  const searchBox = h('div');
  const view = h('div', { class: 'stack fade-in' });
  const demo = !!lecture.isDemo;

  // ---------- header ----------
  const readSet = new Set((await ctx.store.get('learningProgress', `lp_${lectureId}`))?.pagesRead || []);
  const pct = () => Math.round((readSet.size / pages.length) * 100);
  const progBox = h('div');
  const drawProg = () => mount(progBox, h('div', { class: 'row between small' }, h('span', null, t('lib.readOf', { read: [...readSet].filter((id) => pages.some((p) => p.pageId === id)).length, total: pages.length })), h('b', null, `${pct()}%`)), bar(pct()));
  const errs = lecture.errors || [];
  view.append(
    h('div', { class: 'row' }, h('a', { class: 'icon-btn', href: '#/library', 'aria-label': t('common.back') }, ctx.lang === 'ar' ? '→' : '←'),
      h('div', { class: 'grow' }, h('h1', { style: { margin: 0, fontSize: '1.2rem' } }, `${KIND_ICON[lecture.sourceKind] || ''} ${lecture.title}`),
        h('div', { class: 'row' }, subject ? chip(subject.name) : null, lecture.examTag ? chip(`🎓 ${lecture.examTag}`) : null, demo ? chip(t('lib.demo'), 'warn') : null, h('span', { class: 'tiny ltr' }, lecture.sourceFileName))),
      h('button', { type: 'button', class: 'icon-btn', 'aria-label': t('rd.menu'), onclick: openMenu }, '⋯')),
    progBox);
  drawProg();
  if (errs.length || lecture.processingState !== 'done') {
    view.append(h('details', { class: 'notice' }, h('summary', null, `⚠ ${t('rd.extractWarn', { n: errs.length })}`),
      h('ul', null, errs.map((e) => h('li', null, `${e.page ? `${t('lecture.page', { n: e.page })}: ` : ''}${e.message}`)))));
  }
  view.append(navBox, searchBox, h('div', { class: 'tabs', role: 'tablist' }, TABS.map(([k, key]) => h('button', { type: 'button', role: 'tab', class: 'tab', 'aria-selected': String(state.tab === k), onclick: (e) => { state.tab = k; for (const b of e.currentTarget.parentElement.children) b.setAttribute('aria-selected', 'false'); e.currentTarget.setAttribute('aria-selected', 'true'); drawContent(); } }, t(key)))), content);

  // ---------- page navigation + jump + headings + search ----------
  function drawNav() {
    const sel = h('select', { 'aria-label': t('rd.jump'), onchange: (e) => go(Number(e.target.value)) },
      pages.map((p) => h('option', { value: p.index, selected: p.index === state.idx }, `${p.page.label || t('lecture.page', { n: p.index })}${p.page.status !== 'ok' ? ' ⚠' : ''}${readSet.has(p.pageId) ? ' ✓' : ''}`)));
    mount(navBox, h('div', { class: 'row', style: { flexWrap: 'nowrap' } },
      h('button', { type: 'button', class: 'icon-btn', disabled: state.idx <= 1, 'aria-label': t('rd.prev'), onclick: () => go(state.idx - 1) }, ctx.lang === 'ar' ? '›' : '‹'), h('div', { class: 'grow' }, sel),
      h('button', { type: 'button', class: 'icon-btn', disabled: state.idx >= pages.length, 'aria-label': t('rd.next'), onclick: () => go(state.idx + 1) }, ctx.lang === 'ar' ? '‹' : '›'),
      h('button', { type: 'button', class: 'icon-btn', 'aria-label': t('rd.toc'), onclick: openToc }, '☰'),
      h('button', { type: 'button', class: 'icon-btn', 'aria-label': t('rd.fontSettings'), onclick: openFont }, 'Aa')));
  }
  function go(i) { state.idx = Math.max(1, Math.min(pages.length, i)); history.replaceState(null, '', `#/lecture/${lectureId}?p=${state.idx}${state.tab !== 'orig' ? `&tab=${state.tab}` : ''}`); drawNav(); drawContent(); }
  function openToc() {
    const items = [];
    for (const p of pages) for (const hd of findHeadings(p.text).slice(0, 3)) items.push({ p, text: hd.text });
    modal((close) => h('div', { class: 'stack' }, h('h3', null, t('rd.toc')), h('div', { class: 'tiny' }, t('rd.tocNote')),
      h('div', { class: 'list', style: { maxHeight: '55vh', overflow: 'auto' } }, items.length ? items.slice(0, 250).map((it) => h('button', { type: 'button', class: 'item', onclick: () => { close(); go(it.p.index); } }, h('div', { class: 'grow ltr' }, h('b', null, it.text), h('div', { class: 'tiny' }, it.p.page.label || t('lecture.page', { n: it.p.index }))))) : h('div', { class: 'muted' }, t('rd.noHeadings'))),
      btn(t('common.close'), () => close(), 'ghost')));
  }
  function openFont() {
    modal((close) => h('div', { class: 'stack' }, h('h3', null, t('rd.fontSettings')),
      h('label', { class: 'field' }, h('span', null, t('rd.fontSize')), h('input', { type: 'range', min: '0.85', max: '1.7', step: '0.05', value: String(state.fs), oninput: (e) => { state.fs = Number(e.target.value); setSetting('readerFont', state.fs); applyFont(); } })),
      h('label', { class: 'field' }, h('span', null, t('rd.lineHeight')), h('input', { type: 'range', min: '1.4', max: '2.6', step: '0.1', value: String(state.lh), oninput: (e) => { state.lh = Number(e.target.value); setSetting('readerLine', state.lh); applyFont(); } })),
      btn(t('common.close'), () => close(), 'primary')));
  }
  const applyFont = () => { for (const el of content.querySelectorAll('.reader')) { el.style.setProperty('--rf', `${state.fs}rem`); el.style.setProperty('--rl', String(state.lh)); } };
  const searchInput = h('input', { type: 'search', value: state.q, placeholder: t('rd.searchPh'), 'aria-label': t('rd.searchPh'), oninput: debounce((e) => { state.q = e.target.value; drawSearch(); if (state.tab === 'orig') drawContent(); }, 250) });
  const searchRes = h('div', { class: 'list' });
  function drawSearch() {
    const hits = state.q.trim() ? searchPages(pages, state.q, { limit: 30 }) : [];
    mount(searchRes, state.q.trim() ? [h('div', { class: 'tiny' }, t('lib.searchResults', { n: hits.length })), ...hits.map((x) => h('button', { type: 'button', class: 'item', onclick: () => { state.tab = 'orig'; go(x.index); } }, h('div', { class: 'grow ltr' }, h('b', null, t('lecture.page', { n: x.index })), h('div', { class: 'small' }, x.snippet))))] : []);
  }
  mount(searchBox, searchInput, searchRes);

  // ---------- selection bar ----------
  let selection = null;
  const selBar = h('div', { class: 'selbar' });
  selBar.addEventListener('pointerdown', (e) => e.preventDefault()); // keep the text selection while a button is pressed
  function drawSelBar() {
    mount(selBar,
      ...(selection ? HL_COLORS : []).map((c) => h('button', { type: 'button', class: `swatch ${c}`, 'aria-label': `${t('rd.highlight')} ${c}`, onclick: () => highlightSel(c) })),
      btn(`💡 ${t('rd.explainSimple')}`, explainSelection, 'soft sm'), btn(`❓ ${t('rd.quizMe')}`, quizSelection, 'soft sm'), btn(`🃏 ${t('rd.toCards')}`, cardsSelection, 'soft sm'));
  }
  offSel?.();
  document.addEventListener('selectionchange', onSelChange);
  offSel = () => document.removeEventListener('selectionchange', onSelChange);
  function onSelChange() {
    const s = getSelection();
    const sel = s && !s.isCollapsed ? paraSelection(s) : null;
    if (sel) { if (!selection || selection.text !== sel.text) { selection = sel; drawSelBar(); } } else if (selection) { selection = null; drawSelBar(); }
  }
  function paraSelection(s) {
    const r = s.getRangeAt(0);
    const a = (r.startContainer.nodeType === 3 ? r.startContainer.parentElement : r.startContainer)?.closest?.('.ptext');
    const b = (r.endContainer.nodeType === 3 ? r.endContainer.parentElement : r.endContainer)?.closest?.('.ptext');
    if (!a || a !== b) return null;
    const pre = r.cloneRange(); pre.selectNodeContents(a); pre.setEnd(r.startContainer, r.startOffset);
    const text = r.toString();
    if (!text.trim()) return null;
    const start = Number(a.dataset.start) + pre.toString().length;
    return { start, end: start + text.length, text };
  }
  const targetText = () => (selection ? selection.text : cur().text);
  async function highlightSel(color) {
    if (!selection) return;
    const hl = await addHighlight(ctx.store, { lectureId, pageId: cur().pageId, start: selection.start, end: selection.end, text: selection.text, color });
    highlights.push(hl); getSelection().removeAllRanges(); selection = null; drawSelBar(); drawContent();
  }
  async function explainSelection() {
    const text = targetText();
    const box = h('div', { class: 'stack' }, h('h3', null, `💡 ${t('rd.explainSimple')}`), h('blockquote', { class: 'small ltr muted' }, text.slice(0, 400)), h('div', { class: 'skeleton', style: { height: '80px' } }));
    const done = modal((close) => { box.append(btn(t('common.close'), () => close(), 'ghost')); return box; });
    try {
      const r = await explainPage(aiSettings(), text);
      box.querySelector('.skeleton')?.replaceWith(h('div', { class: 'stack' }, h('div', { class: 'card flat', style: { whiteSpace: 'pre-wrap' } }, r.text), notice(t('ai.verifyNote')), ...r.warnings.map((w) => notice(warnText(w))),
        btn(t('rd.saveAsNote'), async () => { await ctx.store.put('studyNotes', makeStudyNote({ lectureId, pageId: cur().pageId, text: `${t('rd.explainSimple')}: ${r.text}`, origin: ORIGIN.AI })); toast(t('common.saved')); }, 'soft sm')));
    } catch (e) { box.querySelector('.skeleton')?.replaceWith(notice(aiMessage(e), 'bad')); }
    await done;
  }
  async function quizSelection() {
    const p = cur();
    const pseudo = [{ lectureId, pageId: p.pageId, index: p.index, text: targetText(), label: p.page.label }];
    const questions = buildExamQuestions(pseudo, { count: 5, difficulty: 'mixed', types: ['mcq', 'tf', 'cloze'], seed: `sel:${Date.now()}` });
    if (!questions.length) { toast(t('rd.quizTooShort'), 'error'); return; }
    runQuestions(content.closest('main') || root, { title: t('rd.quizTitle', { title: lecture.title }), questions, lectureIds: [lectureId], kind: 'quiz', demo, onExit: () => ctx.navigate(`#/lecture/${lectureId}?p=${p.index}`) });
  }
  async function cardsSelection() {
    const p = cur();
    const r = await generateCards(ctx.store, lectureId, { pageIds: [p.pageId], max: 10 });
    toast(r.none ? t('rd.cardsNone') : t('rd.cardsMade', { n: r.added, s: r.skipped }), r.none ? 'error' : 'info');
  }

  // ---------- content ----------
  let highlights = await ctx.store.getAllBy('highlights', 'lectureId', lectureId);
  let bookmarks = await ctx.store.getAllBy('bookmarks', 'lectureId', lectureId);

  async function drawContent() {
    const p = cur();
    const first = mount(content, skeleton(1));
    if (!readSet.has(p.pageId)) { readSet.add(p.pageId); }
    markPageOpened(ctx.store, lectureId, p.pageId, { demo }).then((r) => { if (r.first) afterActivity(ctx, checkAchievements, toast); drawProg(); drawNav(); });
    const head = [];
    if (p.page.status !== 'ok') head.push(notice(`⚠ ${(p.page.warnings || []).join(' — ') || t(`rd.status.${p.page.status}`)}`, 'bad'));
    else if (p.page.warnings?.length) head.push(notice(p.page.warnings.join(' — ')));
    head.push(h('div', { class: 'tiny' }, `${t('rd.source')}: ${lecture.sourceFileName} · ${p.page.label || t('lecture.page', { n: p.index })} (${p.index}/${pages.length})`));
    if (state.tab === 'orig') mount(content, ...head, await originalView(p));
    else if (state.tab === 'notes') mount(content, ...head, await notesView(p));
    else mount(content, ...head, await aiView(p, state.tab));
    applyFont(); drawSelBar();
    if (state.tab === 'orig') content.append(selBar);
    content.append(pageActions());
  }

  async function originalView(p) {
    const ot = p.original;
    const corrected = ot && ot.reviewedText !== null && ot.reviewedText !== undefined;
    const text = state.showExtracted && ot ? ot.extractedText : p.text;
    const pageHl = highlights.filter((x) => x.pageId === p.pageId);
    const { ok: anchored, orphans } = state.showExtracted ? { ok: [], orphans: [] } : anchorHighlights(text, pageHl);
    const searchR = state.q.trim() ? highlightRanges(text, state.q) : [];
    const keys = keyTokenRanges(text);
    const pbm = bookmarks.filter((b) => b.pageId === p.pageId);
    const box = h('div', { class: 'reader en', lang: 'en', dir: 'ltr' });
    if (!text.trim()) box.append(h('div', { class: 'muted' }, t('rd.emptyPage')));
    for (const para of paragraphs(text)) {
      const local = (arr) => arr.filter((r) => r.end > para.start && r.start < para.end).map((r) => ({ ...r, start: Math.max(r.start, para.start) - para.start, end: Math.min(r.end, para.end) - para.start }));
      const segs = segmentText(para.text, { highlights: local(anchored), search: local(searchR), keys: local(keys) });
      const marked = pbm.some((b) => b.paragraphIndex === para.index);
      box.append(h('p', { class: 'para' },
        h('span', { class: 'ptext', 'data-start': String(para.start) }, segs.map((s) => {
          if (!s.hl && !s.search && !s.key) return s.text;
          const cls = [s.hl ? `hl hl-${s.hl}` : '', s.search ? 'found' : '', s.key ? `k-${s.key}` : ''].filter(Boolean).join(' ');
          return h(s.hl || s.search ? 'mark' : 'span', { class: cls }, s.text);
        })),
        h('button', { type: 'button', class: 'bm', 'aria-pressed': String(marked), 'aria-label': t('rd.bookmark'), onclick: async () => {
          const r = await toggleBookmark(ctx.store, { lectureId, pageId: p.pageId, paragraphIndex: para.index, snippet: para.text });
          bookmarks = await ctx.store.getAllBy('bookmarks', 'lectureId', lectureId); toast(r ? t('rd.bookmarked') : t('rd.unbookmarked')); drawContent();
        } }, marked ? '🔖' : '🏷️')));
    }
    const tools = h('div', { class: 'row' },
      corrected ? chip(`✏️ ${t('rd.corrected')}`, 'warn') : null,
      orphans.length ? chip(t('rd.orphanHl', { n: orphans.length }), 'bad') : null,
      ot ? btn(state.showExtracted ? t('rd.showCurrent') : t('rd.showExtracted'), () => { state.showExtracted = !state.showExtracted; drawContent(); }, 'ghost sm') : null,
      ot && !state.showExtracted ? btn(`✏️ ${t('rd.correct')}`, () => correctText(p), 'ghost sm') : null,
      corrected && !state.showExtracted ? btn(t('rd.revert'), async () => { if (await confirmDialog(t('rd.revert'), t('rd.revertAsk'))) { const row = { ...ot, reviewedText: null, edits: [...ot.edits, { at: new Date().toISOString(), note: 'reverted to extracted text' }] }; await ctx.store.put('originalTexts', row); p.original = row; p.text = row.extractedText; drawContent(); } }, 'ghost sm') : null,
      pageHl.length ? btn(t('rd.clearHl'), async () => { for (const x of pageHl) await ctx.store.delete('highlights', x.id); highlights = highlights.filter((x) => x.pageId !== p.pageId); drawContent(); }, 'ghost sm') : null);
    return h('div', { class: 'stack' }, tools, state.showExtracted ? notice(t('rd.extractedNote'), 'info') : null, box, h('div', { class: 'tiny' }, t('rd.originalNote')));
  }

  function correctText(p) {
    modal((close) => {
      const ta = h('textarea', { class: 'ltr', style: { minHeight: '40vh' } }); ta.value = p.text;
      return h('div', { class: 'stack' }, h('h3', null, t('rd.correct')), notice(t('rd.correctNote'), 'info'), ta,
        h('div', { class: 'row', style: { justifyContent: 'flex-end' } }, btn(t('common.cancel'), () => close(), 'ghost'), btn(t('common.save'), async () => {
          const ot = p.original || makeOriginalText({ lectureId, pageId: p.pageId, extractedText: '' });
          const row = { ...ot, reviewedText: ta.value, edits: [...ot.edits, { at: new Date().toISOString(), note: 'manual correction' }] };
          await ctx.store.put('originalTexts', row); p.original = row; p.text = ta.value; close(); drawContent(); toast(t('common.saved'));
        }, 'primary')));
    });
  }

  async function aiView(p, tab) {
    const isTr = tab === 'ar';
    const store = isTr ? 'translations' : 'explanations';
    const wanted = isTr ? `tr_${p.pageId}` : tab === 'egy' ? `ex_${p.pageId}` : `hy_${p.pageId}`;
    const row = await ctx.store.get(store, wanted);
    const box = h('div', { class: 'stack' });
    if (!p.text.trim()) return notice(t('rd.emptyPage'));
    if (row) {
      box.append(h('div', { class: 'reader', dir: 'rtl' }, h('div', { style: { whiteSpace: 'pre-wrap' } }, row.text)),
        h('div', { class: 'row' }, chip(`🤖 ${provenanceLine(row)}`), ...(row.warnings || []).map((w) => chip(`⚠ ${warnText(w)}`, 'warn'))),
        notice(t('ai.verifyNote')),
        h('div', { class: 'row' }, btn(t('rd.regen'), () => generate(true), 'soft sm'), btn(t('common.delete'), async () => { await ctx.store.delete(store, row.id); drawContent(); }, 'ghost sm')));
    } else {
      box.append(empty(tab === 'ar' ? '🌐' : tab === 'egy' ? '💬' : '⭐', t(`rd.none.${tab}`), t('rd.needsInternet')), h('div', { class: 'row', style: { justifyContent: 'center' } }, btn(`✨ ${t('rd.generate')}`, () => generate(false), 'primary')));
    }
    async function generate(replace) {
      mount(box, skeleton(2));
      try {
        const fn = isTr ? translatePage : tab === 'egy' ? explainPage : highYieldPage;
        const r = await fn(aiSettings(), p.text);
        const prov = { model: r.model, generatedAt: new Date().toISOString(), endpoint: aiSettings().endpoint };
        const common = { lectureId, pageId: p.pageId, text: r.text, origin: ORIGIN.AI, provenance: prov, warnings: r.warnings, sourceRef: { pageId: p.pageId } };
        const rowNew = isTr ? makeTranslation(common) : makeExplanation({ ...common, style: tab === 'egy' ? 'egyptian-arabic' : 'high-yield' });
        await ctx.store.put(store, rowNew); drawContent();
      } catch (e) { mount(box, notice(aiMessage(e), 'bad'), btn(t('common.retry'), () => generate(replace), 'soft sm')); }
    }
    return box;
  }

  async function notesView(p) {
    const notes = (await ctx.store.getAllBy('studyNotes', 'lectureId', lectureId)).filter((n) => n.pageId === p.pageId);
    const ta = h('textarea', { placeholder: t('rd.notePh'), 'aria-label': t('rd.notePh') });
    return h('div', { class: 'stack' }, ta, btn(t('rd.addNote'), async () => { if (!ta.value.trim()) return; await ctx.store.put('studyNotes', makeStudyNote({ lectureId, pageId: p.pageId, text: ta.value.trim() })); drawContent(); }, 'primary'),
      notes.length ? notes.sort((a, b) => b.createdAt.localeCompare(a.createdAt)).map((n) => h('div', { class: 'card' }, h('div', { style: { whiteSpace: 'pre-wrap' } }, n.text), h('div', { class: 'row between' }, h('span', { class: 'tiny' }, `${n.origin === 'ai' ? '🤖 ' : ''}${n.createdAt.slice(0, 10)}`),
        h('div', { class: 'row' }, btn(t('common.edit'), () => editNote(n), 'ghost sm'), btn(t('common.delete'), async () => { await ctx.store.delete('studyNotes', n.id); drawContent(); }, 'ghost sm'))))) : h('div', { class: 'muted small' }, t('rd.noNotes')));
  }
  function editNote(n) {
    modal((close) => { const ta = h('textarea'); ta.value = n.text; return h('div', { class: 'stack' }, ta, h('div', { class: 'row' }, btn(t('common.cancel'), () => close(), 'ghost'), btn(t('common.save'), async () => { await ctx.store.put('studyNotes', { ...n, text: ta.value }); close(); drawContent(); }, 'primary'))); });
  }

  function pageActions() {
    return h('div', { class: 'row', style: { justifyContent: 'space-between' } },
      btn(`${ctx.lang === 'ar' ? '→' : '←'} ${t('rd.prev')}`, () => go(state.idx - 1), 'ghost', { disabled: state.idx <= 1 }),
      btn(`${t('rd.next')} ${ctx.lang === 'ar' ? '←' : '→'}`, () => go(state.idx + 1), 'primary', { disabled: state.idx >= pages.length }));
  }

  function openMenu() {
    modal((close) => h('div', { class: 'stack' }, h('h3', null, lecture.title),
      link(`📝 ${t('rd.examLecture')}`, `#/exams?lecture=${lectureId}`, 'soft'), link(`🃏 ${t('rd.cardsLecture')}`, `#/cards?lecture=${lectureId}`, 'soft'), link(`🤖 ${t('rd.askAssistant')}`, `#/assistant?lecture=${lectureId}`, 'soft'),
      btn(`🗑 ${t('rd.delete')}`, async () => { if (await confirmDialog(t('rd.delete'), t('rd.deleteAsk'), { danger: true, ok: t('common.delete') })) { await ctx.store.deleteLecture(lectureId); close(); toast(t('common.deleted')); ctx.navigate('#/library'); } }, 'danger'),
      btn(t('common.close'), () => close(), 'ghost')));
  }

  drawNav(); drawSearch(); mount(root, view); await drawContent();
}
