// Medical assistant: chat grounded in the chosen lectures. Context is picked locally (BM25), only those pages are sent,
// and the reply separates "from your lecture" (with [n] citations) from "added knowledge". No keys in the browser.
import { h, mount, toast } from '../dom.js';
import { t } from '../i18n.js';
import { ctx } from '../ctx.js';
import { loadPagesOf } from '../study.js';
import { rankPages } from '../search.js';
import { askAssistant } from '../ai.js';
import { makeChatMessage } from '../models.js';
import { aiSettings, aiReady, aiMessage, warnText } from './ai-ui.js';
import { empty, notice, btn, link, pageHead, skeleton, confirmDialog } from './common.js';

const MODES = ['ask', 'explain_term', 'translate', 'simplify', 'compare', 'mcq', 'tf', 'summary'];

export async function renderAssistant(root, { query }) {
  mount(root, skeleton(2));
  const lectures = (await ctx.store.getAll('lectures')).filter((l) => !l.isDemo);
  const state = { picks: new Set(query.get('lecture') ? [query.get('lecture')] : lectures.slice(0, 1).map((l) => l.id)), mode: 'ask', busy: false };
  const view = h('div', { class: 'stack fade-in' }, pageHead(t('as.title'), t('as.sub')));
  if (!lectures.length) { mount(root, view, empty('🤖', t('as.noLecturesTitle'), t('as.noLecturesText'), link(t('home.importFirst'), '#/import', 'primary'))); return; }

  // honest status: never simulate an answer
  const cfg = aiSettings();
  const status = !cfg.endpoint ? notice(t('ai.err.not_configured'), 'warn') : !cfg.consent ? notice(t('as.needConsent'), 'warn') : !ctx.online() ? notice(t('as.offline'), 'warn') : notice(t('as.ready'), 'info');
  if (!aiReady() || !ctx.online()) status.append(' ', link(t('nav.settings'), '#/settings', 'soft sm'));
  view.append(status);

  const pick = h('div', { class: 'row' }, lectures.map((l) => h('label', { class: 'chip' }, h('input', { type: 'checkbox', checked: state.picks.has(l.id), onchange: (e) => { e.target.checked ? state.picks.add(l.id) : state.picks.delete(l.id); } }), ` ${l.title}`)));
  const modeSel = h('select', { 'aria-label': t('as.mode'), onchange: (e) => { state.mode = e.target.value; } }, MODES.map((m) => h('option', { value: m }, t(`as.mode.${m}`))));
  view.append(h('div', { class: 'card stack' }, h('div', { class: 'small muted' }, t('as.pick')), pick, h('label', { class: 'field' }, h('span', null, t('as.mode')), modeSel)));

  const chat = h('div', { class: 'chat', 'aria-live': 'polite' });
  const history = (await ctx.store.getAllBy('chatMessages', 'conversationId', 'default')).sort((a, b) => a.createdAt.localeCompare(b.createdAt));

  function botBlock(m) {
    const box = h('div', { class: 'msg bot' });
    const parts = m.parts || { lecture: m.content, extra: '', structured: false };
    if (parts.structured) {
      if (parts.lecture) box.append(h('div', { class: 'src-block lec' }, h('b', null, `📘 ${t('as.fromLecture')}`), h('div', { dir: 'auto' }, parts.lecture)));
      if (parts.extra) box.append(h('div', { class: 'src-block ext' }, h('b', null, `💡 ${t('as.added')}`), h('div', null, parts.extra), h('div', { class: 'tiny' }, t('as.addedNote'))));
      if (!parts.lecture && !parts.extra) box.append(t('as.nothing'));
    } else box.append(m.content);
    if (m.refs?.length) box.append(h('div', { class: 'tiny', style: { marginBlockStart: '.5rem' } }, `${t('as.sources')}: `, m.refs.map((r) => h('a', { href: `#/lecture/${r.lectureId}?p=${r.index}`, class: 'chip' }, `[${r.n}] ${r.label}`))));
    for (const w of m.warnings || []) box.append(notice(`⚠ ${warnText(w)}`, 'warn'));
    if (m.provenance?.model) box.append(h('div', { class: 'tiny' }, `${t('ai.generatedBy', { model: m.provenance.model })}`));
    return box;
  }
  const draw = (m) => (m.role === 'user' ? h('div', { class: 'msg user' }, m.content) : botBlock(m));
  history.forEach((m) => chat.append(draw(m)));
  if (!history.length) chat.append(h('div', { class: 'muted small', id: 'chat-empty' }, t('as.tryAsking')));

  const input = h('textarea', { rows: 2, maxlength: 2000, placeholder: t('as.placeholder'), 'aria-label': t('as.placeholder'), dir: 'auto' });
  const send = btn(`➤ ${t('as.send')}`, ask, 'primary');
  async function ask() {
    const question = input.value.trim();
    if (!question || state.busy) return;
    if (!state.picks.size) { toast(t('as.needLecture'), 'error'); return; }
    if (!aiReady()) { toast(!cfg.endpoint ? t('ai.err.not_configured') : t('as.needConsent'), 'error'); return; }
    if (!ctx.online()) { toast(t('as.offline'), 'error'); return; }
    state.busy = true; send.disabled = true;
    chat.querySelector('#chat-empty')?.remove();
    const userMsg = makeChatMessage({ role: 'user', content: question, lectureIds: [...state.picks] });
    chat.append(draw(userMsg));
    const wait = h('div', { class: 'msg bot' }, h('div', { class: 'skeleton', style: { height: '18px', width: '60%' } }));
    chat.append(wait);
    wait.scrollIntoView({ block: 'nearest' });
    try {
      const pages = await loadPagesOf(ctx.store, [...state.picks]);
      const ranked = rankPages(pages, question, { k: 6, maxChars: 12000 });
      const context = ranked.map((p, i) => ({ n: i + 1, ref: `${p.title}، ${p.label || `p.${p.index}`}`, text: p.text }));
      const hist = (await ctx.store.getAllBy('chatMessages', 'conversationId', 'default')).sort((a, b) => a.createdAt.localeCompare(b.createdAt)).slice(-6).map((m) => ({ role: m.role, content: m.role === 'assistant' ? (m.parts ? [m.parts.lecture, m.parts.extra].filter(Boolean).join('\n') : m.content) : m.content })).filter((m) => m.content.length <= 4000);
      const r = await askAssistant(aiSettings(), { question, mode: state.mode, context, history: hist });
      const refs = r.citations.map((n) => ({ n, lectureId: ranked[n - 1].lectureId, pageId: ranked[n - 1].pageId, index: ranked[n - 1].index, label: `${ranked[n - 1].title} · ${t('lecture.page', { n: ranked[n - 1].index })}` }));
      const botMsg = makeChatMessage({ role: 'assistant', content: r.raw, refs, lectureIds: [...state.picks], warnings: r.warnings, provenance: { model: r.model, generatedAt: new Date().toISOString() } });
      botMsg.parts = { structured: r.structured, lecture: r.lecture, extra: r.extra };
      await ctx.store.put('chatMessages', [userMsg, botMsg]);
      wait.replaceWith(draw(botMsg));
      if (!ranked.length) chat.append(notice(t('as.noContext'), 'info'));
      input.value = '';
    } catch (e) {
      wait.replaceWith(notice(`⚠ ${aiMessage(e)}`, 'bad'));
    } finally { state.busy = false; send.disabled = false; }
  }
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) ask(); });
  view.append(chat, h('div', { class: 'card stack' }, input, h('div', { class: 'row between' },
    btn(`🗑 ${t('as.clear')}`, async () => { if (await confirmDialog(t('as.clear'), t('as.clearAsk'), { danger: true })) { for (const m of await ctx.store.getAllBy('chatMessages', 'conversationId', 'default')) await ctx.store.delete('chatMessages', m.id); ctx.rerender(); } }, 'ghost sm'), send)),
    notice(t('as.eduNote'), 'info'));
  mount(root, view);
}
