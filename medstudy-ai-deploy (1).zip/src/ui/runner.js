// Exam / quiz runner: one question at a time, optional timer, results only after submit,
// essay self-grading, review with source references, retake of wrong answers.
import { h, mount, toast } from '../dom.js';
import { t } from '../i18n.js';
import { ctx } from '../ctx.js';
import { submitExam, wrongQuestionsOf } from '../study.js';
import { grade, scoreAttempt } from '../quiz.js';
import { checkAchievements } from '../activity.js';
import { bar, ring, chip, notice, btn, afterActivity, confirmDialog, celebrate } from './common.js';

const pageIndexOf = (q) => { const m = /_(\d+)$/.exec(q.sourceRef?.pageId || ''); return m ? Number(m[1]) : null; };

export function runQuestions(root, { title, questions, lectureIds, kind = 'exam', config = {}, timeLimitSec = null, demo = false, onExit }) {
  const entries = questions.map((question) => ({ question, response: null, selfRating: null }));
  const startedAt = new Date().toISOString();
  let i = 0; let timerId = null; let left = timeLimitSec; let finished = false;
  const view = h('div', { class: 'stack fade-in' });
  const body = h('div', { class: 'stack' });
  const timerEl = h('span', { class: 'timer', role: 'timer' });
  const exit = () => { clearInterval(timerId); (onExit || (() => ctx.navigate('#/exams')))(); };
  ctx.tracker?.setActive(true, demo);

  const fmt = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
  if (timeLimitSec) {
    const paint = () => { timerEl.textContent = fmt(Math.max(0, left)); timerEl.classList.toggle('low', left <= 60); };
    paint();
    timerId = setInterval(() => { left--; paint(); if (left <= 0) { clearInterval(timerId); toast(t('ex.timeUp')); selfGradeStep(true); } }, 1000);
  }

  function head() {
    return h('div', { class: 'row between' }, h('b', null, title), h('div', { class: 'row' }, timeLimitSec ? timerEl : null, btn('✕', async () => { if (finished || await confirmDialog(t('ex.quit'), t('ex.quitAsk'), { danger: true })) exit(); }, 'ghost sm', { 'aria-label': t('common.close') })));
  }
  function draw() {
    const e = entries[i]; const q = e.question;
    const answered = entries.filter((x) => x.response !== null && x.response !== '').length;
    mount(body, bar(((i + 1) / entries.length) * 100), h('div', { class: 'small muted' }, t('ex.qOf', { n: i + 1, total: entries.length, a: answered })),
      h('div', { class: 'card stack' }, chip(t(`ex.type.${q.type}`)), h('div', { class: 'ltr', style: { fontWeight: '600', whiteSpace: 'pre-wrap' } }, q.prompt), input(e, q)),
      h('div', { class: 'row between' }, btn(`${ctx.lang === 'ar' ? '→' : '←'} ${t('rd.prev')}`, () => { i--; draw(); }, 'ghost', { disabled: i === 0 }),
        i < entries.length - 1 ? btn(`${t('rd.next')} ${ctx.lang === 'ar' ? '←' : '→'}`, () => { i++; draw(); }, 'primary') : btn(`✔ ${t('ex.finish')}`, () => tryFinish(), 'primary')),
      h('div', { class: 'tabs' }, entries.map((x, k) => h('button', { type: 'button', class: 'tab', 'aria-selected': String(k === i), onclick: () => { i = k; draw(); } }, `${k + 1}${x.response !== null && x.response !== '' ? '•' : ''}`))));
  }
  function input(e, q) {
    if (q.type === 'mcq') return h('div', null, q.choices.map((c, k) => h('button', { type: 'button', class: 'choice ltr', 'aria-pressed': String(e.response === k), onclick: () => { e.response = k; draw(); } }, c)));
    if (q.type === 'tf') return h('div', null, [[0, 'ex.true'], [1, 'ex.false']].map(([v, key]) => h('button', { type: 'button', class: 'choice', 'aria-pressed': String(e.response === v), onclick: () => { e.response = v; draw(); } }, t(key))));
    if (q.type === 'cloze') return h('input', { type: 'text', class: 'ltr', value: e.response || '', placeholder: t('ex.typeAnswer'), 'aria-label': t('ex.typeAnswer'), autocomplete: 'off', oninput: (ev) => { e.response = ev.target.value; } });
    return h('textarea', { class: 'ltr', placeholder: t('ex.essayPh'), 'aria-label': t('ex.essayPh'), oninput: (ev) => { e.response = ev.target.value; } }, e.response || '');
  }
  async function tryFinish() {
    const blank = entries.filter((x) => x.response === null || x.response === '').length;
    if (blank && !(await confirmDialog(t('ex.finish'), t('ex.unanswered', { n: blank })))) return;
    selfGradeStep(false);
  }
  function selfGradeStep(forced) {
    clearInterval(timerId);
    const essays = entries.filter((x) => x.question.type === 'essay' && x.response);
    if (!essays.length) { submit(forced); return; }
    mount(body, h('h3', null, t('ex.selfGrade')), notice(t('ex.selfGradeNote'), 'info'),
      ...essays.map((x) => {
        const row = h('div', { class: 'row' });
        const paint = () => mount(row, [[1, 'ex.rate.full'], [0.5, 'ex.rate.half'], [0, 'ex.rate.none']].map(([v, key]) => h('button', { type: 'button', class: 'chip', 'aria-pressed': String(x.selfRating === v), onclick: () => { x.selfRating = v; paint(); } }, t(key))));
        paint();
        return h('div', { class: 'card stack' }, h('b', { class: 'ltr' }, x.question.prompt), h('div', { class: 'small' }, h('b', null, t('ex.yourAnswer')), h('div', { class: 'ltr', style: { whiteSpace: 'pre-wrap' } }, x.response)),
          h('div', { class: 'small' }, h('b', null, t('ex.modelAnswer')), h('div', { class: 'ltr', style: { whiteSpace: 'pre-wrap' } }, x.question.correctAnswer || '—')), x.question.verified ? null : notice(t('ex.unverified')), row);
      }), btn(t('ex.submit'), () => submit(forced), 'primary big'));
  }
  async function submit(forced) {
    finished = true; clearInterval(timerId);
    mount(body, h('div', { class: 'skeleton', style: { height: '120px' } }));
    const { score, attempt } = await submitExam(ctx.store, { title, kind, lectureIds, config, entries, startedAt, timeLimitSec, timedOut: !!forced && timeLimitSec !== null && left <= 0, demo });
    afterActivity(ctx, checkAchievements, toast);
    if ((score.percent ?? 0) >= 80) celebrate('🎯');
    results(score, attempt);
  }
  function results(score, attempt) {
    const wrongIdx = entries.map((e, k) => k).filter((k) => { const r = score.results[k]; return r.gradable && !(r.correct && !r.partial); });
    let onlyWrong = false;
    const list = h('div', { class: 'stack' });
    const drawList = () => mount(list, entries.map((e, k) => ({ e, k })).filter(({ k }) => !onlyWrong || wrongIdx.includes(k)).map(({ e, k }) => review(e, score.results[k], k)));
    const q = (e) => e.question;
    function review(e, r, k) {
      const ok = r.gradable && r.correct && !r.partial;
      const tag = !r.gradable ? chip(t('ex.notGraded')) : r.partial ? chip(t('ex.partial'), 'warn') : ok ? chip(`✔ ${t('ex.right')}`, 'ok') : chip(`✘ ${t('ex.wrong')}`, 'bad');
      const mine = e.response === null || e.response === '' ? t('ex.noAnswer') : q(e).type === 'mcq' ? q(e).choices[e.response] : q(e).type === 'tf' ? t(e.response === 0 ? 'ex.true' : 'ex.false') : String(e.response);
      const exp = q(e).type === 'tf' ? t(q(e).correctAnswer === 0 ? 'ex.true' : 'ex.false') : r.expected;
      const pi = pageIndexOf(q(e));
      return h('div', { class: 'card stack' }, h('div', { class: 'row between' }, h('b', null, `${k + 1}.`), tag),
        h('div', { class: 'ltr', style: { whiteSpace: 'pre-wrap' } }, q(e).prompt),
        h('div', { class: 'small' }, `${t('ex.yourAnswer')}: `, h('span', { class: 'ltr' }, mine)), !ok && r.gradable ? h('div', { class: 'small' }, `${t('ex.correctAnswer')}: `, h('b', { class: 'ltr' }, exp ?? '—')) : null,
        q(e).explanation ? h('div', { class: 'small muted ltr' }, q(e).explanation) : null,
        q(e).sourceRef ? h('div', { class: 'tiny' }, `${t('ex.sourceRef')}: `, pi ? h('a', { href: `#/lecture/${q(e).lectureId}?p=${pi}` }, t('lecture.page', { n: pi })) : '—', q(e).sourceRef.quote ? h('span', { class: 'ltr' }, ` “${q(e).sourceRef.quote.slice(0, 120)}”`) : null) : null,
        !q(e).verified && q(e).origin === 'ai' ? notice(t('ex.unverified')) : null);
    }
    const pctv = score.percent;
    mount(body, h('div', { class: 'hero stack' }, h('div', { class: 'row', style: { flexWrap: 'nowrap', gap: '1rem' } }, ring(pctv ?? 0, pctv === null ? '—' : `${pctv}%`), h('div', null, h('h2', null, pctv === null ? t('ex.noGraded') : t('ex.score', { c: score.correct, g: score.graded })), h('div', { class: 'muted' }, t('ex.timeTaken', { s: attempt.durationSec }))))),
      attempt.timedOut ? notice(t('ex.timeUp')) : null, score.graded < entries.length ? notice(t('ex.someNotGraded', { n: entries.length - score.graded })) : null,
      h('div', { class: 'row' }, wrongIdx.length ? btn(`🔁 ${t('ex.retakeWrong', { n: wrongIdx.length })}`, () => runQuestions(root, { title: `${t('ex.retakeTitle')}: ${title}`, questions: wrongIdx.map((k) => entries[k].question), lectureIds, kind: 'retake', config: { from: attempt.id }, timeLimitSec: null, demo, onExit }), 'primary') : null,
        btn(`🎯 ${t('ex.weakExam')}`, () => ctx.navigate('#/exams?weak=1'), 'soft'), btn(t('ex.done'), exit, 'ghost')),
      h('label', { class: 'row' }, h('input', { type: 'checkbox', onchange: (ev) => { onlyWrong = ev.target.checked; drawList(); } }), t('ex.onlyWrong')), list);
    drawList();
  }
  mount(root, view); view.append(head(), body); draw();
}
