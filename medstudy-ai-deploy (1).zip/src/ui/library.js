import { h, mount, debounce } from '../dom.js';
import { t } from '../i18n.js';
import { ctx } from '../ctx.js';
import { loadSnapshot } from '../stats-data.js';
import { loadPagesOf } from '../study.js';
import { searchPages, highlightRanges } from '../search.js';
import { segmentText } from '../reader-text.js';
import { bar, empty, skeleton, chip, pageHead, link, btn, KIND_ICON } from './common.js';
import { stagedFiles } from './import.js';

export async function renderLibrary(root, { query }) {
  mount(root, skeleton(4));
  const snap = await loadSnapshot(ctx.store, new Date());
  const all = await ctx.store.getAll('lectures');
  const subjects = new Map((await ctx.store.getAll('subjects')).map((s) => [s.id, s]));
  const progress = new Map((await ctx.store.getAll('learningProgress')).map((p) => [p.lectureId, p]));
  const pagesAll = await ctx.store.getAll('sourcePages');
  const compById = new Map(snap.completions.map((c) => [c.lectureId, c]));
  // demo lectures have no entry in the real stats; compute their completion the same way
  const { lectureCompletion } = await import('../stats.js');
  for (const l of all.filter((x) => x.isDemo)) compById.set(l.id, lectureCompletion(l, pagesAll.filter((p) => p.lectureId === l.id), progress.get(l.id)));

  const state = { subject: query.get('subject') || '', exam: '', sort: ctx.settings.librarySort || 'opened', q: '' };
  const view = h('div', { class: 'stack fade-in' });
  const list = h('div', { class: 'list' });
  const results = h('div', { class: 'list' });

  const drop = h('div', { class: 'drop', tabindex: '0' }, h('div', { class: 'big', 'aria-hidden': 'true' }, '⬆️'), h('b', null, t('lib.dropTitle')), h('div', { class: 'small muted' }, t('lib.dropText')),
    h('div', { class: 'row', style: { justifyContent: 'center', marginBlockStart: '.6rem' } }, link(t('lib.chooseFiles'), '#/import', 'primary')));
  ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', (e) => { stagedFiles.set([...e.dataTransfer.files]); ctx.navigate('#/import'); });

  const subjectsReal = [...subjects.values()];
  const examTags = [...new Set(all.map((l) => l.examTag).filter(Boolean))];
  const search = h('input', { type: 'search', placeholder: t('lib.search'), 'aria-label': t('lib.search'), oninput: debounce((e) => { state.q = e.target.value; draw(); }, 250) });
  const sortSel = h('select', { 'aria-label': t('lib.sort'), onchange: async (e) => { state.sort = e.target.value; const { setSetting } = await import('../ctx.js'); setSetting('librarySort', state.sort); draw(); } },
    ['opened', 'progress', 'subject', 'title'].map((k) => h('option', { value: k, selected: state.sort === k }, t(`lib.sort.${k}`))));
  const chips = h('div', { class: 'row' });
  const drawChips = () => mount(chips, h('button', { type: 'button', class: 'chip', 'aria-pressed': String(!state.subject), onclick: () => { state.subject = ''; drawChips(); draw(); } }, t('lib.all')),
    subjectsReal.map((s) => h('button', { type: 'button', class: 'chip', 'aria-pressed': String(state.subject === s.id), onclick: () => { state.subject = s.id; drawChips(); draw(); } }, s.name)),
    examTags.map((x) => h('button', { type: 'button', class: 'chip', 'aria-pressed': String(state.exam === x), onclick: () => { state.exam = state.exam === x ? '' : x; drawChips(); draw(); } }, `🎓 ${x}`)));

  async function draw() {
    let ls = all.filter((l) => (!state.subject || l.subjectId === state.subject) && (!state.exam || l.examTag === state.exam));
    const opened = (l) => progress.get(l.id)?.lastOpenedAt || '';
    const cmp = { opened: (a, b) => opened(b).localeCompare(opened(a)) || b.createdAt.localeCompare(a.createdAt), progress: (a, b) => (compById.get(a.id)?.percent ?? 0) - (compById.get(b.id)?.percent ?? 0),
      subject: (a, b) => (subjects.get(a.subjectId)?.name || '').localeCompare(subjects.get(b.subjectId)?.name || ''), title: (a, b) => a.title.localeCompare(b.title) }[state.sort];
    ls = ls.sort(cmp);
    mount(list, ls.length ? ls.map(card) : (all.length ? h('div', { class: 'muted' }, t('lib.noMatch')) : empty('📚', t('lib.emptyTitle'), t('lib.emptyText'))));
    mount(results);
    if (state.q.trim()) {
      const pages = (await loadPagesOf(ctx.store, ls.map((l) => l.id))).filter((p) => p.text);
      const hits = searchPages(pages, state.q, { limit: 40 });
      const byId = new Map(all.map((l) => [l.id, l]));
      mount(results, h('h3', null, t('lib.searchResults', { n: hits.length })), hits.length ? hits.map((x) => {
        const parts = segmentText(x.snippet, { search: highlightRanges(x.snippet, state.q) });
        return h('a', { class: 'item', href: `#/lecture/${x.lectureId}?p=${x.index}&q=${encodeURIComponent(state.q)}` },
          h('div', { class: 'grow' }, h('b', null, byId.get(x.lectureId)?.title), h('div', { class: 'small muted' }, t('lecture.page', { n: x.index })),
            h('div', { class: 'small ltr' }, parts.map((s) => (s.search ? h('mark', { class: 'found' }, s.text) : s.text)))));
      }) : h('div', { class: 'muted small' }, t('lib.noResults')));
    }
  }
  function card(l) {
    const c = compById.get(l.id) || { percent: 0, read: 0, total: l.pageCount, issues: 0, complete: false };
    const sub = subjects.get(l.subjectId);
    const status = l.processingState === 'done' ? null : chip(`⚠ ${t(`lib.state.${l.processingState}`)}`, l.processingState === 'failed' ? 'bad' : 'warn');
    const last = progress.get(l.id)?.lastOpenedPage;
    const pg = last ? pagesAll.find((p) => p.id === last) : null;
    return h('a', { class: 'item', href: `#/lecture/${l.id}${pg ? `?p=${pg.index}` : ''}` },
      h('div', { class: 'thumb' }, KIND_ICON[l.sourceKind] || '📄'),
      h('div', { class: 'grow stack' }, h('div', { class: 'row between' }, h('b', null, l.title), h('span', { class: 'small' }, c.complete ? `✅ ${c.percent}%` : `${c.percent}%`)),
        h('div', { class: 'row' }, sub ? chip(sub.name) : null, l.examTag ? chip(`🎓 ${l.examTag}`) : null, l.isDemo ? chip(t('lib.demo'), 'warn') : null, status,
          c.issues ? chip(t('lib.issues', { n: c.issues }), 'warn') : null, h('span', { class: 'tiny' }, t('lib.readOf', { read: c.read, total: c.total }))),
        bar(c.percent)));
  }
  view.append(pageHead(t('nav.library'), t('lib.sub', { n: all.length }), link(`＋ ${t('lib.add')}`, '#/import', 'primary')), drop, search, chips, h('label', { class: 'field' }, h('span', null, t('lib.sort')), sortSel), results, list);
  drawChips(); mount(root, view); await draw();
}
