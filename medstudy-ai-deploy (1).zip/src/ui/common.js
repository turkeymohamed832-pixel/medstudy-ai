import { h, modal } from '../dom.js';
import { t } from '../i18n.js';

export const bar = (pct, cls = '') => {
  const i = h('i');
  const el = h('div', { class: `bar ${cls}`, role: 'progressbar', 'aria-valuemin': 0, 'aria-valuemax': 100, 'aria-valuenow': Math.round(pct || 0) }, i);
  requestAnimationFrame(() => requestAnimationFrame(() => { i.style.width = `${Math.max(0, Math.min(100, pct || 0))}%`; }));
  return el;
};
export const ring = (pct, label, cls = '') => {
  const el = h('div', { class: `ring ${cls}`, role: 'img', 'aria-label': `${pct ?? 0}%` }, h('b', null, label ?? `${pct ?? 0}%`));
  el.style.setProperty('--p', String(Math.max(0, Math.min(100, pct || 0))));
  return el;
};
export const skeleton = (n = 3) => h('div', { class: 'stack', 'aria-busy': 'true' }, Array.from({ length: n }, () => h('div', { class: 'skeleton', style: { height: '64px' } })));
export const empty = (icon, title, text, ...actions) => h('div', { class: 'empty' }, h('span', { class: 'big', 'aria-hidden': 'true' }, icon), h('h3', null, title), text ? h('p', null, text) : null, actions.length ? h('div', { class: 'row', style: { justifyContent: 'center' } }, actions) : null);
export const chip = (text, cls = '') => h('span', { class: `chip ${cls}` }, text);
export const notice = (text, cls = '') => h('div', { class: `notice ${cls}`, role: cls === 'bad' ? 'alert' : null }, text);
export const section = (title, extra) => h('div', { class: 'section-title' }, h('h2', null, title), extra || null);
export const pageHead = (title, sub, ...actions) => h('div', { class: 'row between', style: { marginBlockEnd: '.8rem' } }, h('div', null, h('h1', null, title), sub ? h('div', { class: 'muted small' }, sub) : null), actions.length ? h('div', { class: 'row' }, actions) : null);
export const btn = (label, onclick, cls = '', attrs = {}) => h('button', { type: 'button', class: `btn ${cls}`, onclick, ...attrs }, label);
export const link = (label, href, cls = '') => h('a', { class: `btn ${cls}`, href }, label);

export function confirmDialog(title, text, { ok = t('common.ok'), danger = false } = {}) {
  return modal((close) => h('div', { class: 'stack' }, h('h3', null, title), h('p', { class: 'muted' }, text),
    h('div', { class: 'row', style: { justifyContent: 'flex-end' } }, btn(t('common.cancel'), () => close(false), 'ghost'), btn(ok, () => close(true), danger ? 'danger' : 'primary'))));
}
export function celebrate(icon = '🎉') {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const el = h('div', { class: 'celebrate', 'aria-hidden': 'true' }, h('span', null, icon));
  document.body.append(el);
  setTimeout(() => el.remove(), 1700);
}
export const pct = (n) => (n === null || n === undefined ? '—' : `${n}%`);
export function fmtNum(n, lang) { return new Intl.NumberFormat(lang === 'en' ? 'en' : 'ar-EG-u-nu-latn').format(n); }
export function dayLabel(date, lang, opts = { weekday: 'short' }) {
  return new Intl.DateTimeFormat(lang === 'en' ? 'en-GB' : 'ar-EG-u-nu-latn', opts).format(new Date(`${date}T12:00:00`));
}

/** After something that can earn a badge: unlock + light celebration. Never blocks the caller. */
export async function afterActivity(ctx, checkAchievements, toast) {
  try {
    const fresh = await checkAchievements(ctx.store, new Date());
    if (fresh.length) { celebrate('🏆'); toast(t('ach.unlocked', { name: t(`badge.${fresh[0]}.name`) })); }
  } catch (e) { console.warn('achievements', e); }
}
export const KIND_ICON = { pdf: '📕', pptx: '📊', image: '🖼️', text: '📝' };
