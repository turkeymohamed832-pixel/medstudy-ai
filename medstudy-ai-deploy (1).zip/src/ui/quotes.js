// Short motivational lines (original wording, no attribution to real people).
export const QUOTES = {
  ar: [
    'كل صفحة بتذاكرها النهارده هي مريض هتطمّن عليه بكرة.',
    'الفهم الهادي أسرع من الحفظ المتوتر.',
    'راجع شوية كل يوم، ده اللي بيفضل في الراس يوم الامتحان.',
    'التمريض علم ورحمة، وإنتي/إنت بتبني الاتنين دلوقتي.',
    'خطوة صغيرة كل يوم أقوى من ليلة امتحان واحدة.',
    'الغلط في المذاكرة فرصة؛ الغلط في المستشفى خطر. اتعلم دلوقتي.',
    'الدقة في الأرقام والجرعات عادة بتتبني من أول محاضرة.',
  ],
  en: [
    'Every page you study today is a patient you will care for better tomorrow.',
    'Calm understanding beats anxious memorising.',
    'A little review every day is what stays with you on exam day.',
    'Nursing is science and compassion — you are building both right now.',
    'One small step a day beats one long night before the exam.',
    'Mistakes in study are lessons; mistakes at the bedside are risks. Learn now.',
    'Precision with numbers and doses is a habit that starts in the first lecture.',
  ],
};
export const quoteOfTheDay = (lang, date) => {
  const list = QUOTES[lang === 'en' ? 'en' : 'ar'];
  const n = Number(date.replaceAll('-', '')) || 0;
  return list[n % list.length];
};
