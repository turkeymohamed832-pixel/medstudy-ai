import { h, modal } from '../dom.js';
import { t } from '../i18n.js';
import { ctx } from '../ctx.js';

export const MORE_ITEMS = [
  ['planner', '🗓️', 'nav.planner'], ['assistant', '🤖', 'nav.assistant'], ['progress', '📈', 'nav.progress'],
  ['achievements', '🏆', 'nav.achievements'], ['bookmarks', '🔖', 'nav.bookmarks'], ['settings', '⚙️', 'nav.settings'],
];
export const openMore = () => modal((close) => h('div', { class: 'stack' },
  h('h3', null, t('nav.more')),
  h('div', { class: 'more-grid' }, MORE_ITEMS.map(([r, ic, key]) => h('button', { type: 'button', class: 'btn', onclick: () => { close(); ctx.navigate(`#/${r}`); } }, h('span', { class: 'ic', 'aria-hidden': 'true' }, ic), t(key)))),
  h('button', { type: 'button', class: 'btn ghost', onclick: () => close() }, t('common.close'))));
