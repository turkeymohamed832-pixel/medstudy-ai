// Progress, achievements and bookmarks screens. Everything shown here is computed from real activity (demo data excluded).
import { h, mount, fmtDuration } from '../dom.js';
import { t } from '../i18n.js';
import { ctx } from '../ctx.js';
import { loadSnapshot } from '../stats-data.js';
import { evaluateBadges, DEFAULT_GOAL } from '../stats.js';
import { bar, ring, skeleton, empty, section, chip, notice, link, btn, pageHead, dayLabel, fmtNum, pct } from './common.js';

export async function renderProgress(root) {
  mount(root, skeleton(4));
  const s = await loadSnapshot(ctx.store, new Date());
  const L = ctx.lang;
  const view = h('div', { class: 'stack fade-in' }, pageHead(t('pr.title'), t('pr.sub')));
  if (!s.lectures.length) { mount(root, view, empty('📈', t('pr.emptyTitle'), t('pr.emptyText'), link(t('home.importFirst'), '#/import', 'primary'))); return; }

  view.append(h('div', { class: 'hero stack' }, h('div', { class: 'row', style: { flexWrap: 'nowrap', gap: '1rem' } },
    ring(s.overall.percent ?? 0, pct(s.overall.percent)),
    h('div', { class: 'grow' }, h('h2', null, t('home.journey')), h('div', null, t('home.journeySub', { read: s.overall.read, total: s.overall.total })),
      s.overall.issues ? h('div', { class: 'small' }, `⚠ ${t('lib.issues', { n: s.overall.issues })}`) : null))));

  const grid = h('div', { class: 'grid two' });
  grid.append(
    h('div', { class: 'card' }, h('div', { class: 'tiny' }, t('home.readiness')), h('div', { class: 'stat' }, s.readiness.score === null ? '—' : `${s.readiness.score}%`),
      s.readiness.score === null ? h('div', { class: 'small muted' }, t('home.readinessNone')) : bar(s.readiness.score), h('div', { class: 'tiny' }, t('home.readinessNote'))),
    h('div', { class: 'card' }, h('div', { class: 'tiny' }, t('pr.streak')), h('div', { class: 'stat' }, `🔥 ${s.streak.current}`), h('div', { class: 'small muted' }, t('pr.bestStreak', { n: s.streak.best })), h('div', { class: 'tiny' }, t('pr.noPenalty'))),
    h('div', { class: 'card' }, h('div', { class: 'tiny' }, t('pr.cardsDeck')), h('div', { class: 'stat' }, fmtNum(s.deck.total ?? 0, L)), h('div', { class: 'small muted' }, t('pr.deckLine', { due: s.deck.due ?? 0, mature: s.deck.mature ?? 0 }))),
    h('div', { class: 'card' }, h('div', { class: 'tiny' }, t('pr.exams')), h('div', { class: 'stat' }, fmtNum(s.attempts.length, L)),
      h('div', { class: 'small muted' }, s.badgeInput.bestPercent === null ? t('pr.noExams') : t('pr.bestExam', { n: s.badgeInput.bestPercent }))));
  view.append(grid);

  // last 14 days of real study time
  const days = Array.from({ length: 14 }, (_, i) => { const d = new Date(s.now.getTime() - (13 - i) * 86400000); const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; return { key, stat: s.dailyStats.find((x) => x.date === key) }; });
  const max = Math.max(60, ...days.map((d) => d.stat?.seconds || 0));
  view.append(section(t('pr.last14')), h('div', { class: 'card' }, h('div', { class: 'row', style: { alignItems: 'flex-end', flexWrap: 'nowrap', gap: '4px', height: '110px' }, role: 'img', 'aria-label': t('pr.last14') },
    days.map((d) => h('div', { style: { flex: '1', display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', height: '100%' }, title: `${d.key}: ${fmtDuration(d.stat?.seconds || 0, L)}` },
      h('div', { style: { height: `${Math.max(3, ((d.stat?.seconds || 0) / max) * 100)}%`, background: d.stat?.seconds ? 'var(--primary)' : 'var(--line)', borderRadius: '6px' } })))),
    h('div', { class: 'tiny' }, t('pr.minutesNote'))));

  view.append(section(t('pr.byLecture')));
  const list = h('div', { class: 'list' });
  for (const c of s.completions) {
    const lec = s.lectures.find((l) => l.id === c.lectureId);
    list.append(h('a', { class: 'item', href: `#/lecture/${c.lectureId}` }, h('div', { class: 'grow stack', style: { gap: '.3rem' } },
      h('b', null, lec?.title), bar(c.percent ?? 0), h('div', { class: 'tiny' }, t('lib.readOf', { read: c.read, total: c.total }), c.issues ? ` · ⚠ ${t('lib.issues', { n: c.issues })}` : '', c.complete ? ` · ✅ ${t('pr.complete')}` : ''))));
  }
  view.append(list);

  if (s.weak.length) {
    const lecs = new Map(s.lectures.map((l) => [l.id, l]));
    const rows = [];
    for (const w of s.weak.slice(0, 8)) {
      const l = lecs.get(w.lectureId); const pg = (s.pagesByLecture.get(w.lectureId) || []).find((p) => p.id === w.pageId);
      if (l && pg) rows.push(h('a', { class: 'item', href: `#/lecture/${l.id}?p=${pg.index}` }, h('div', { class: 'grow' }, h('b', null, l.title), h('div', { class: 'small muted' }, `${pg.label || t('lecture.page', { n: pg.index })} — ${t('home.weakWhy', { wrong: w.wrong, lapses: w.lapses })}`))));
    }
    view.append(section(t('home.weak')), h('div', { class: 'list' }, rows), link(t('home.weakExam'), '#/exams?weak=1', 'soft'));
  }
  mount(root, view);
}

export async function renderAchievements(root) {
  mount(root, skeleton(3));
  const s = await loadSnapshot(ctx.store, new Date());
  const earnedAt = new Map(s.achievements.map((a) => [a.key, a.unlockedAt || a.createdAt]));
  const badges = evaluateBadges(s.badgeInput);
  const L = ctx.lang;
  const view = h('div', { class: 'stack fade-in' }, pageHead(t('ach.title'), t('ach.sub')));
  view.append(h('div', { class: 'hero stack' }, h('div', { class: 'row between' }, h('div', null, h('h2', null, `⭐ ${t('home.level', { n: s.level.level })}`), h('div', null, t('ach.xpTotal', { xp: fmtNum(s.xpTotal, L) }))), h('div', { class: 'stat' }, `🏆 ${badges.filter((b) => b.earned).length}/${badges.length}`)), bar(s.level.percent), h('div', { class: 'small' }, t('ach.toNext', { n: Math.max(0, s.level.span - s.level.into) })), h('div', { class: 'tiny' }, t('ach.xpNote'))));
  const wk = s.week;
  view.append(section(t('home.week')), h('div', { class: 'card stack' },
    h('div', null, t('home.goalTime'), ` ${wk.minutes}/${wk.goal.minutes}`), bar(wk.minutesPct),
    h('div', null, t('home.goalQuestions'), ` ${wk.questions}/${wk.goal.questions}`), bar(wk.questionsPct),
    wk.met ? chip(`🏁 ${t('ach.weekMet')}`, 'ok') : null));
  view.append(section(t('ach.badges')), h('div', { class: 'grid two' }, badges.map((b) => h('div', { class: `badge-tile ${b.earned ? 'earned' : 'locked'}` },
    h('div', { class: 'big', 'aria-hidden': 'true' }, b.icon), h('b', null, t(`badge.${b.key}.name`)), h('div', { class: 'small muted' }, t(`badge.${b.key}.desc`)),
    b.earned ? h('div', { class: 'tiny' }, `✅ ${(earnedAt.get(b.key) || '').slice(0, 10)}`) : [bar((b.cur / b.target) * 100), h('div', { class: 'tiny' }, `${b.cur}/${b.target}`)]))));
  mount(root, view);
}

export async function renderBookmarks(root) {
  mount(root, skeleton(2));
  const [bms, lectures, pages] = await Promise.all([ctx.store.getAll('bookmarks'), ctx.store.getAll('lectures'), ctx.store.getAll('sourcePages')]);
  const lm = new Map(lectures.map((l) => [l.id, l])); const pm = new Map(pages.map((p) => [p.id, p]));
  const view = h('div', { class: 'stack fade-in' }, pageHead(t('bm.title'), t('bm.sub')));
  const rows = bms.filter((b) => lm.has(b.lectureId)).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  if (!rows.length) { mount(root, view, empty('🔖', t('bm.emptyTitle'), t('bm.emptyText'), link(t('nav.library'), '#/library', 'primary'))); return; }
  view.append(h('div', { class: 'list' }, rows.map((b) => {
    const p = pm.get(b.pageId);
    return h('div', { class: 'item' }, h('a', { class: 'grow', href: `#/lecture/${b.lectureId}?p=${p?.index || 1}` }, h('b', null, lm.get(b.lectureId).title), h('div', { class: 'tiny' }, t('lecture.page', { n: p?.index || '?' })), h('div', { class: 'ltr small', dir: 'auto' }, b.snippet)),
      btn('🗑', async () => { await ctx.store.delete('bookmarks', b.id); ctx.rerender(); }, 'ghost sm', { 'aria-label': t('common.delete') }));
  })));
  mount(root, view);
}
