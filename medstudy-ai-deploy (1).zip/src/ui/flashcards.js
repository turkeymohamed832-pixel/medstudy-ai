import { h, mount, toast } from '../dom.js';
import { t } from '../i18n.js';
import { ctx } from '../ctx.js';
import { loadDeck, buildQueue, rateCard, generateCards, addManualCard, updateCard, deleteCard, loadLecturePages } from '../study.js';
import { previewIntervals, formatInterval, cardMastery } from '../srs.js';
import { CARD_KINDS } from '../quiz.js';
import { checkAchievements } from '../activity.js';
import { bar, chip, notice, btn, empty, skeleton, pageHead, section, afterActivity, confirmDialog, celebrate, link } from './common.js';
import { modal } from '../dom.js';

export async function renderCards(root, { query }) {
  mount(root, skeleton(3));
  const lectures = (await ctx.store.getAll('lectures')).sort((a, b) => a.title.localeCompare(b.title));
  const deck = await loadDeck(ctx.store, null, { includeDemo: true });
  const lecById = new Map(lectures.map((l) => [l.id, l]));
  const now = new Date();
  if (query.get('study')) return study(root, deck.filter((d) => !query.get('lecture') || d.card.lectureId === query.get('lecture')), lecById, query.get('lecture'));
  if (query.get('quick')) return quick(root, deck, query.get('lecture'));
  const view = h('div', { class: 'stack fade-in' });
  const byLec = new Map();
  for (const d of deck) { if (!byLec.has(d.card.lectureId)) byLec.set(d.card.lectureId, []); byLec.get(d.card.lectureId).push(d); }
  const dueAll = buildQueue(deck, now);
  view.append(pageHead(t('nav.cards'), t('cards.sub', { n: deck.length })),
    h('div', { class: 'hero stack' }, h('h2', null, t('cards.todayQueue', { n: dueAll.length })), h('div', { class: 'muted' }, t('cards.queueNote')),
      link(`▶ ${t('cards.studyAll')}`, '#/cards?study=1', 'on-hero big')),
    h('div', { class: 'row' }, btn(`🎲 ${t('cards.quick')}`, () => ctx.navigate('#/cards?quick=1'), 'soft', { disabled: deck.length < 4 }), btn(`＋ ${t('cards.add')}`, () => editor(null, lectures, query.get('lecture')), 'soft')));
  if (!deck.length) view.append(empty('🃏', t('cards.emptyTitle'), t('cards.emptyText')));
  view.append(section(t('cards.decks')));
  const decks = h('div', { class: 'list' });
  for (const l of lectures) {
    const items = byLec.get(l.id) || [];
    const due = buildQueue(items, now).length;
    const mastery = items.length ? Math.round((items.reduce((s, d) => s + cardMastery(d.schedule), 0) / items.length) * 100) : 0;
    decks.append(h('div', { class: 'card stack' }, h('div', { class: 'row between' }, h('b', null, l.title), l.isDemo ? chip(t('lib.demo'), 'warn') : null),
      h('div', { class: 'row small' }, chip(t('cards.countN', { n: items.length })), chip(t('cards.dueN', { n: due }), due ? 'warn' : ''), h('span', { class: 'tiny' }, `${t('cards.mastery')} ${mastery}%`)), bar(mastery),
      h('div', { class: 'row' }, link(t('cards.study'), `#/cards?study=1&lecture=${l.id}`, 'primary sm'), btn(t('cards.manage'), () => manage(root, l, lectures), 'soft sm'), btn(`⚙ ${t('cards.generate')}`, () => generate(root, l), 'ghost sm'))));
  }
  view.append(decks, notice(t('cards.verbatimNote'), 'info'));
  mount(root, view);
}

function generate(root, lecture) {
  const picks = new Set(CARD_KINDS);
  modal((close) => h('div', { class: 'stack' }, h('h3', null, `${t('cards.generate')}: ${lecture.title}`), notice(t('cards.verbatimNote'), 'info'),
    h('div', { class: 'row' }, CARD_KINDS.map((k) => h('label', { class: 'chip' }, h('input', { type: 'checkbox', checked: true, onchange: (e) => { e.target.checked ? picks.add(k) : picks.delete(k); } }), ` ${t(`cards.kind.${k}`)}`))),
    h('div', { class: 'row' }, btn(t('common.cancel'), () => close(), 'ghost'), btn(t('cards.generate'), async () => {
      const r = await generateCards(ctx.store, lecture.id, { kinds: [...picks], max: 15 });
      close(); toast(r.none ? t('cards.noneFound') : t('rd.cardsMade', { n: r.added, s: r.skipped }), r.none ? 'error' : 'info'); ctx.rerender();
    }, 'primary'))));
}

function editor(card, lectures, preLecture) {
  return modal((close) => {
    const sel = h('select', { disabled: !!card }, lectures.map((l) => h('option', { value: l.id, selected: (card ? card.lectureId : preLecture) === l.id }, l.title)));
    const front = h('textarea', { class: 'ltr', placeholder: t('cards.front'), 'aria-label': t('cards.front') }); front.value = card?.front || '';
    const back = h('textarea', { class: 'ltr', placeholder: t('cards.back'), 'aria-label': t('cards.back') }); back.value = card?.back || '';
    return h('div', { class: 'stack' }, h('h3', null, card ? t('cards.edit') : t('cards.add')), !lectures.length ? notice(t('cards.needLecture'), 'bad') : null, sel, front, back,
      h('div', { class: 'row', style: { justifyContent: 'flex-end' } }, btn(t('common.cancel'), () => close(), 'ghost'), btn(t('common.save'), async () => {
        if (!front.value.trim() || !back.value.trim() || !sel.value) { toast(t('cards.needBoth'), 'error'); return; }
        if (card) await updateCard(ctx.store, card, { front: front.value, back: back.value }); else await addManualCard(ctx.store, sel.value, { front: front.value, back: back.value });
        close(); ctx.rerender();
      }, 'primary')));
  });
}

async function manage(root, lecture, lectures) {
  const cards = (await loadDeck(ctx.store, lecture.id)).sort((a, b) => a.card.createdAt.localeCompare(b.card.createdAt));
  modal((close) => h('div', { class: 'stack' }, h('h3', null, lecture.title), h('div', { class: 'list', style: { maxHeight: '55vh', overflow: 'auto' } }, cards.length ? cards.map(({ card }) => h('div', { class: 'card flat stack' },
    h('div', { class: 'row between' }, chip(t(`cards.kind.${card.kind}`) || card.kind), h('div', { class: 'row' }, btn('✏️', () => { close(); editor(card, lectures); }, 'ghost sm', { 'aria-label': t('common.edit') }), btn('🗑', async () => { if (await confirmDialog(t('common.delete'), t('cards.deleteAsk'), { danger: true })) { await deleteCard(ctx.store, card.id); close(); ctx.rerender(); } }, 'ghost sm', { 'aria-label': t('common.delete') }))),
    h('div', { class: 'ltr small' }, h('b', null, card.front)), h('div', { class: 'ltr small muted' }, card.back))) : h('div', { class: 'muted' }, t('cards.emptyText'))), btn(t('common.close'), () => close(), 'ghost')));
}

function study(root, deck, lecById, lectureId) {
  const queue = buildQueue(deck, new Date());
  const view = h('div', { class: 'stack fade-in' });
  const stage = h('div', { class: 'stack' });
  let i = 0; let flipped = false; let again = 0; let good = 0;
  const demoOf = (d) => !!lecById.get(d.card.lectureId)?.isDemo;
  ctx.tracker?.setActive(true, queue.length > 0 && queue.every(demoOf));
  const back = () => ctx.navigate(lectureId ? `#/cards` : '#/cards');
  if (!queue.length) { mount(root, view, pageHead(t('cards.study')), empty('🎉', t('cards.nothingDue'), t('cards.nothingDueText'), btn(t('common.back'), back, 'primary'))); return; }
  async function rate(r) {
    const e = queue[i];
    await rateCard(ctx.store, e, r, new Date(), { demo: demoOf(e) });
    r === 'again' ? again++ : good++;
    i++; flipped = false; draw();
  }
  function draw() {
    if (i >= queue.length) { done(); return; }
    const e = queue[i]; const c = e.card;
    const prev = previewIntervals(e.schedule || { ease: 2.5, intervalDays: 0, repetitions: 0, lapses: 0, due: new Date().toISOString() });
    const face = h('div', { class: `flip ${flipped ? 'on' : ''}`, role: 'button', tabindex: '0', 'aria-label': t('cards.flip'), onclick: () => { flipped = !flipped; draw(); }, onkeydown: (ev) => { if (ev.key === ' ' || ev.key === 'Enter') { ev.preventDefault(); flipped = !flipped; draw(); } } },
      h('div', { class: 'flip-in' }, h('div', { class: 'face ltr' }, h('div', { class: 'tiny' }, lecById.get(c.lectureId)?.title), h('div', null, c.front)), h('div', { class: 'face back ltr' }, h('div', null, c.back), c.sourceRef?.pageId ? h('div', { class: 'tiny' }, `${t('ex.sourceRef')}: ${/_(\d+)$/.exec(c.sourceRef.pageId)?.[1] || ''}`) : null)));
    let x0 = null;
    face.addEventListener('pointerdown', (ev) => { x0 = ev.clientX; });
    face.addEventListener('pointerup', (ev) => { if (x0 === null) return; const dx = ev.clientX - x0; x0 = null; if (Math.abs(dx) > 90 && flipped) { ev.preventDefault(); rate(dx > 0 ? 'good' : 'again'); } });
    mount(stage, bar((i / queue.length) * 100), h('div', { class: 'small muted' }, t('cards.progress', { n: i + 1, total: queue.length })), face,
      flipped ? h('div', { class: 'stack' }, h('div', { class: 'rate' }, h('button', { type: 'button', class: 'btn danger big', onclick: () => rate('again') }, `🔁 ${t('cards.again')}`, h('span', { class: 'tiny' }, formatInterval(prev.again, ctx.lang))), h('button', { type: 'button', class: 'btn primary big', onclick: () => rate('good') }, `✅ ${t('cards.knew')}`, h('span', { class: 'tiny' }, formatInterval(prev.good, ctx.lang)))),
        h('div', { class: 'row', style: { justifyContent: 'center' } }, btn(`⚡ ${t('cards.easy')} (${formatInterval(prev.easy, ctx.lang)})`, () => rate('easy'), 'ghost sm')), h('div', { class: 'tiny', style: { textAlign: 'center' } }, t('cards.swipeHint')))
        : h('div', { class: 'row', style: { justifyContent: 'center' } }, btn(t('cards.showAnswer'), () => { flipped = true; draw(); }, 'primary big')));
  }
  async function done() {
    afterActivity(ctx, checkAchievements, toast);
    if (good >= again) celebrate('🌟');
    mount(stage, h('div', { class: 'hero stack' }, h('h2', null, `🎉 ${t('cards.done')}`), h('div', null, t('cards.doneStats', { good, again }))), h('div', { class: 'row' }, btn(t('common.back'), back, 'primary')));
  }
  view.append(h('div', { class: 'row between' }, h('b', null, t('cards.study')), btn('✕', back, 'ghost sm', { 'aria-label': t('common.close') })), stage);
  mount(root, view); draw();
}

function quick(root, deck, lectureId) {
  const pool = deck.filter((d) => !lectureId || d.card.lectureId === lectureId);
  const view = h('div', { class: 'stack fade-in' });
  if (pool.length < 4) { mount(root, empty('🎲', t('cards.quickNeed'), '', btn(t('common.back'), () => ctx.navigate('#/cards'), 'primary'))); return; }
  const shuffle = (a) => { const r = [...a]; for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; } return r; };
  const picks = shuffle(pool).slice(0, 10);
  let i = 0; let score = 0;
  const stage = h('div', { class: 'stack' });
  function draw() {
    if (i >= picks.length) { mount(stage, h('div', { class: 'hero stack' }, h('h2', null, t('cards.quickScore', { s: score, n: picks.length }))), notice(t('cards.quickNote'), 'info'), btn(t('common.back'), () => ctx.navigate('#/cards'), 'primary')); return; }
    const c = picks[i].card;
    const opts = shuffle([c, ...shuffle(pool.filter((d) => d.card.id !== c.id && d.card.back !== c.back)).slice(0, 3).map((d) => d.card)]);
    let answered = false;
    mount(stage, bar((i / picks.length) * 100), h('div', { class: 'card ltr', style: { fontWeight: '700' } }, c.front), h('div', null, opts.map((o) => {
      const b = h('button', { type: 'button', class: 'choice ltr', onclick: () => { if (answered) return; answered = true; const ok = o.id === c.id; if (ok) score++; b.classList.add(ok ? 'right' : 'wrong'); if (!ok) for (const x of b.parentElement.children) if (x.dataset.id === c.id) x.classList.add('right'); setTimeout(() => { i++; draw(); }, 900); } }, o.back);
      b.dataset.id = o.id; return b;
    })));
  }
  view.append(pageHead(`🎲 ${t('cards.quick')}`, t('cards.quickSub')), stage); mount(root, view); draw();
}
