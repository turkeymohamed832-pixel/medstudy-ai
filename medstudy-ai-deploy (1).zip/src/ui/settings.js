// Settings: profile, language, theme, goals, AI connection (key never lives here), backup/restore, wipe.
import { h, mount, toast, download } from '../dom.js';
import { t } from '../i18n.js';
import { ctx, setSetting } from '../ctx.js';
import { deleteDatabase } from '../db.js';
import { applyTheme, changeLang } from '../prefs.js';
import { DEFAULT_GOAL } from '../stats.js';
import { aiSettings, DEFAULT_AI } from './ai-ui.js';
import { notice, btn, pageHead, section, confirmDialog } from './common.js';

export async function renderSettings(root) {
  const view = h('div', { class: 'stack fade-in' }, pageHead(t('st.title'), t('st.sub')));
  const goal = { ...DEFAULT_GOAL, ...(ctx.settings.goal || {}) };
  let theme = (() => { try { return localStorage.getItem('ms_theme') || ctx.settings.theme || 'auto'; } catch { return 'auto'; } })();

  // profile + look
  const name = h('input', { type: 'text', value: ctx.settings.studentName || '', maxlength: 40, placeholder: t('st.namePh'), onchange: async (e) => { await setSetting('studentName', e.target.value.trim()); toast(t('common.saved')); } });
  const langSel = h('select', { onchange: (e) => changeLang(e.target.value) }, [['ar', 'العربية'], ['en', 'English']].map(([v, l]) => h('option', { value: v, selected: ctx.lang === v }, l)));
  const themeSel = h('select', { onchange: (e) => applyTheme(e.target.value) }, ['auto', 'light', 'dark'].map((v) => h('option', { value: v, selected: theme === v }, t(`st.theme.${v}`))));
  view.append(h('div', { class: 'card stack' }, h('h3', null, t('st.profile')),
    h('label', { class: 'field' }, h('span', null, `${t('st.name')} (${t('common.optional')})`), name),
    h('div', { class: 'grid two' }, h('label', { class: 'field' }, h('span', null, t('st.lang')), langSel), h('label', { class: 'field' }, h('span', null, t('st.theme')), themeSel))));

  // goals
  const gmin = h('input', { type: 'number', min: 10, max: 3000, value: goal.minutes });
  const gq = h('input', { type: 'number', min: 5, max: 1000, value: goal.questions });
  view.append(h('div', { class: 'card stack' }, h('h3', null, t('st.goals')), h('div', { class: 'grid two' },
    h('label', { class: 'field' }, h('span', null, t('st.goalMin')), gmin), h('label', { class: 'field' }, h('span', null, t('st.goalQ')), gq)),
    btn(t('common.save'), async () => { await setSetting('goal', { minutes: Math.max(10, Number(gmin.value) || goal.minutes), questions: Math.max(5, Number(gq.value) || goal.questions) }); toast(t('common.saved')); }, 'soft'),
    h('div', { class: 'tiny' }, t('st.goalNote'))));

  // AI
  const ai = aiSettings();
  const ep = h('input', { type: 'text', class: 'ltr', value: ai.endpoint, placeholder: '/api/study' });
  const code = h('input', { type: 'password', class: 'ltr', value: ai.accessCode || '', autocomplete: 'off', placeholder: t('st.accessPh') });
  const consent = h('input', { type: 'checkbox', checked: !!ai.consent });
  view.append(h('div', { class: 'card stack' }, h('h3', null, `🤖 ${t('st.ai')}`), notice(t('st.aiNote'), 'info'),
    h('label', { class: 'field' }, h('span', null, t('st.endpoint')), ep), h('label', { class: 'field' }, h('span', null, t('st.access')), code),
    h('label', { class: 'row' }, consent, h('span', null, t('st.consent'))),
    h('div', { class: 'row' }, btn(t('common.save'), async () => { await setSetting('ai', { ...DEFAULT_AI, endpoint: ep.value.trim(), accessCode: code.value.trim(), consent: consent.checked }); toast(t('common.saved')); }, 'primary'),
      btn(t('st.test'), async () => {
        try { const r = await fetch(`${ep.value.trim() || '/api/study'}`, { method: 'GET' }); toast(r.status === 405 || r.ok || r.status === 401 ? t('st.reachable') : `HTTP ${r.status}`, r.status < 500 ? 'info' : 'error'); } catch { toast(t('st.unreachable'), 'error'); }
      }, 'ghost'))));

  // backup
  const file = h('input', { type: 'file', accept: 'application/json,.json', hidden: true, onchange: async (e) => {
    const f = e.target.files[0]; if (!f) return;
    try { const json = JSON.parse(await f.text()); const counts = await ctx.store.importAll(json); toast(t('st.restored', { n: Object.values(counts).reduce((a, b) => a + b, 0) })); ctx.rerender(); } catch (err) { toast(`${t('st.restoreFail')}: ${err.message}`, 'error'); }
  } });
  view.append(h('div', { class: 'card stack' }, h('h3', null, t('st.backup')), h('p', { class: 'muted small' }, t('st.backupNote')),
    h('div', { class: 'row' }, btn(`⬇ ${t('st.export')}`, async () => { const data = await ctx.store.exportAll(); download(`medstudy-backup-${new Date().toISOString().slice(0, 10)}.json`, new Blob([JSON.stringify(data)], { type: 'application/json' })); toast(t('st.exported')); }, 'primary'),
      btn(`⬆ ${t('st.import')}`, () => file.click(), 'soft'), file)));

  // storage + wipe
  const store = h('div', { class: 'small muted' }, '…');
  navigator.storage?.estimate?.().then((e) => { store.textContent = t('st.storage', { used: Math.round((e.usage || 0) / 1048576), quota: Math.round((e.quota || 0) / 1048576) }); }).catch(() => { store.textContent = ''; });
  view.append(h('div', { class: 'card stack' }, h('h3', null, t('st.data')), notice(t('st.localNote'), 'info'), store,
    btn(`🗑 ${t('st.wipe')}`, async () => {
      if (!(await confirmDialog(t('st.wipe'), t('st.wipeAsk'), { ok: t('st.wipe'), danger: true }))) return;
      ctx.store.close(); await deleteDatabase(); try { localStorage.removeItem('ms_theme'); localStorage.removeItem('ms_lang'); } catch { /* ignore */ }
      location.hash = '#/'; location.reload();
    }, 'danger')));
  view.append(h('div', { class: 'tiny' }, t('common.eduNotice')));
  mount(root, view);
}
