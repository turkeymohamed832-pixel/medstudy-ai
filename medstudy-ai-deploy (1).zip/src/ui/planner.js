// Study planner: exam date + daily minutes -> realistic plan (never pretends to fit), postpone, redistribute, real progress.
import { h, mount, toast } from '../dom.js';
import { t } from '../i18n.js';
import { ctx, setSetting } from '../ctx.js';
import { dateStr, addDays, daysBetween, isOverdue, planProgress } from '../planner.js';
import { buildPlan, savePlan, toggleTask, postpone, redistributePlan } from '../planner-data.js';
import { bar, empty, notice, btn, link, chip, pageHead, section, skeleton, confirmDialog, dayLabel, afterActivity } from './common.js';
import { checkAchievements } from '../activity.js';

const KIND_ICON = { study: '📖', review: '🔁', practice: '📝', exam: '🎯' };

export async function renderPlanner(root) {
  mount(root, skeleton(3));
  const today = dateStr(new Date());
  const lectures = (await ctx.store.getAll('lectures')).filter((l) => !l.isDemo);
  let tasks = (await ctx.store.getAll('studyTasks')).sort((a, b) => (a.dueDate || '').localeCompare(b.dueDate || ''));
  const cfg = { exam: ctx.settings.examDate || '', daily: ctx.settings.dailyMinutes || 120, picks: new Set(ctx.settings.planLectures?.length ? ctx.settings.planLectures : lectures.map((l) => l.id)) };
  const view = h('div', { class: 'stack fade-in' }, pageHead(t('pl.title'), t('pl.sub')));
  const msg = h('div', { 'aria-live': 'polite' });

  if (!lectures.length) {
    mount(root, view, empty('🗓️', t('pl.noLecturesTitle'), t('pl.noLecturesText'), link(t('home.importFirst'), '#/import', 'primary')));
    return;
  }

  // ---------- setup form ----------
  const examIn = h('input', { type: 'date', value: cfg.exam, min: addDays(today, 1), onchange: (e) => { cfg.exam = e.target.value; } });
  const dailyIn = h('input', { type: 'number', min: 15, max: 600, step: 15, value: cfg.daily, onchange: (e) => { cfg.daily = Math.max(15, Math.min(600, Number(e.target.value) || 120)); e.target.value = cfg.daily; } });
  const lecList = h('div', { class: 'stack' }, lectures.map((l) => h('label', { class: 'chip' },
    h('input', { type: 'checkbox', checked: cfg.picks.has(l.id), onchange: (e) => { e.target.checked ? cfg.picks.add(l.id) : cfg.picks.delete(l.id); } }), ` ${l.title}`)));

  async function persistCfg() {
    await setSetting('examDate', cfg.exam); await setSetting('dailyMinutes', cfg.daily); await setSetting('planLectures', [...cfg.picks]);
  }
  async function generate() {
    mount(msg);
    if (!cfg.exam || daysBetween(today, cfg.exam) < 1) { mount(msg, notice(t('pl.needExam'), 'bad')); return; }
    if (!cfg.picks.size) { mount(msg, notice(t('pl.needLectures'), 'bad')); return; }
    if (tasks.some((x) => !x.done) && !(await confirmDialog(t('pl.replaceTitle'), t('pl.replaceAsk'), { ok: t('pl.generate') }))) return;
    const plan = await buildPlan(ctx.store, { exam: cfg.exam, dailyMinutes: cfg.daily, lectureIds: [...cfg.picks], today, labels: {
      study: (title, i, n) => (n > 1 ? `${t('pl.kind.study')}: ${title} (${i}/${n})` : `${t('pl.kind.study')}: ${title}`),
      review: (title, gap) => `${t('pl.kind.review')}: ${title} (+${gap})`,
      practice: (title) => `${t('pl.kind.practice')}: ${title}`,
      exam: () => t('pl.examDay'),
    } });
    await savePlan(ctx.store, plan.tasks);
    await persistCfg();
    ctx.lastPlan = { feasible: plan.feasible, unscheduled: plan.unscheduled, neededMinutes: plan.neededMinutes, availableMinutes: plan.availableMinutes };
    toast(t('pl.generated'));
    ctx.rerender();
  }
  view.append(h('div', { class: 'card stack' },
    h('div', { class: 'grid two' }, h('label', { class: 'field' }, h('span', null, t('pl.examDate')), examIn), h('label', { class: 'field' }, h('span', null, t('pl.daily')), dailyIn)),
    h('div', { class: 'small muted' }, t('pl.lectures')), lecList,
    btn(`🗓️ ${tasks.length ? t('pl.regenerate') : t('pl.generate')}`, generate, 'primary big'), msg));

  const plan = ctx.lastPlan;
  if (plan && !plan.feasible) {
    view.append(notice(`${t('pl.infeasible', { need: plan.neededMinutes, have: plan.availableMinutes })} ${plan.unscheduled.map((u) => `${u.title} (${u.minutes}${t('common.min')})`).join('، ')}. ${t('pl.infeasibleHint')}`, 'warn'));
  }

  if (!tasks.length) { mount(root, view, empty('🗓️', t('pl.emptyTitle'), t('pl.emptyText'))); return; }

  // ---------- progress + actions ----------
  const prog = planProgress(tasks);
  const exam = tasks.find((x) => x.kind === 'exam');
  const examDate = exam?.dueDate || cfg.exam;
  const overdue = tasks.filter((x) => isOverdue(x, today));
  view.append(h('div', { class: 'card stack' },
    h('div', { class: 'row between' }, h('b', null, t('pl.progress')), h('span', { class: 'muted small' }, examDate ? t('pl.daysLeft', { n: Math.max(0, daysBetween(today, examDate)) }) : '')),
    bar(prog.percent ?? 0), h('div', { class: 'small muted' }, t('pl.progressLine', { done: prog.doneTasks, total: prog.tasks, dm: prog.doneMinutes, pm: prog.plannedMinutes })),
    overdue.length ? notice(t('pl.overdueN', { n: overdue.length }), 'warn') : null,
    overdue.length ? btn(`↻ ${t('pl.redistribute')}`, async () => {
      const r = await redistributePlan(ctx.store, { exam: examDate, dailyMinutes: cfg.daily, today });
      toast(r.unscheduled?.length ? t('pl.redistPartial', { n: r.unscheduled.length }) : t('pl.redistOk'));
      ctx.rerender();
    }, 'soft') : null));

  // ---------- today ----------
  const byDate = new Map();
  for (const x of tasks) { const d = x.dueDate || '—'; if (!byDate.has(d)) byDate.set(d, []); byDate.get(d).push(x); }
  const row = (x) => {
    const late = isOverdue(x, today);
    const lec = lectures.find((l) => l.id === x.lectureId);
    const go = x.kind === 'study' && lec ? `#/lecture/${lec.id}` : x.kind === 'review' ? '#/cards?study=1' : x.kind === 'practice' ? '#/exams' : null;
    return h('div', { class: `item ${x.done ? 'done' : ''}` },
      h('input', { type: 'checkbox', checked: x.done, 'aria-label': t('pl.markDone'), onchange: async (e) => { const box = e.target; await toggleTask(ctx.store, x); await afterActivity(ctx, checkAchievements, toast); ctx.rerender(); box.blur(); } }),
      h('div', { class: 'grow' }, h('div', { style: { textDecoration: x.done ? 'line-through' : 'none' } }, `${KIND_ICON[x.kind] || ''} ${x.title}`),
        h('div', { class: 'tiny' }, x.kind === 'exam' ? '' : `${x.estMinutes} ${t('common.min')}`, late ? ` · ${t('pl.late')}` : '', x.postponedCount ? ` · ${t('pl.postponedN', { n: x.postponedCount })}` : '')),
      go && !x.done ? link(t('pl.open'), go, 'soft sm') : null,
      !x.done && x.kind !== 'exam' ? btn('⏭', async () => { await postpone(ctx.store, x, 1); toast(t('pl.postponed')); ctx.rerender(); }, 'ghost sm', { 'aria-label': t('pl.postpone'), title: t('pl.postpone') }) : null);
  };
  const todays = byDate.get(today) || [];
  view.append(section(t('home.today')), h('div', { class: 'list' }, todays.length ? todays.map(row) : [h('div', { class: 'muted small' }, t('home.noTaskToday'))]));
  if (overdue.length) view.append(section(t('pl.late')), h('div', { class: 'list' }, overdue.map(row)));
  const future = [...byDate.entries()].filter(([d]) => d > today);
  view.append(section(t('pl.upcoming')));
  for (const [d, list] of future) view.append(h('div', { class: 'stack' }, h('div', { class: 'small', style: { fontWeight: '700' } }, `${dayLabel(d, ctx.lang, { weekday: 'long', day: 'numeric', month: 'short' })}`), h('div', { class: 'list' }, list.map(row))));
  mount(root, view);
}
