import { h, mount, fmtDuration } from '../dom.js';
import { t } from '../i18n.js';
import { ctx } from '../ctx.js';
import { loadSnapshot } from '../stats-data.js';
import { resumePoint, nextUnreadIndex } from '../study.js';
import { dayLabel, bar, ring, skeleton, empty, section, chip, notice, btn, link, fmtNum } from './common.js';
import { quoteOfTheDay } from './quotes.js';
import { addDemo } from '../demo.js';
import { toast } from '../dom.js';

const greetKey = (d) => { const hr = d.getHours(); return hr < 12 ? 'home.morning' : hr < 18 ? 'home.afternoon' : 'home.evening'; };

export async function renderHome(root) {
  mount(root, skeleton(4));
  const snap = await loadSnapshot(ctx.store, new Date());
  const resume = await resumePoint(ctx.store);
  const L = ctx.lang;
  const name = (ctx.settings.studentName || '').trim();
  const real = snap.lectures;
  const view = h('div', { class: 'stack fade-in' });

  view.append(h('div', { class: 'row between' },
    h('div', null, h('div', { class: 'muted small' }, t(greetKey(snap.now))), h('h1', null, name ? t('home.hello', { name }) : t('home.helloNoName'))),
    h('div', { class: 'row' },
      snap.streak.current ? chip(`🔥 ${t('home.streakDays', { n: snap.streak.current })}`, 'ok') : chip(`🔥 ${t('home.noStreak')}`),
      chip(`⭐ ${t('home.level', { n: snap.level.level })}`))));

  if (!real.length) {
    view.append(h('div', { class: 'card' }, empty('📚', t('home.emptyTitle'), t('home.emptyText'),
      link(t('home.importFirst'), '#/import', 'primary'),
      btn(t('home.tryDemo'), async () => { await addDemo(ctx.store); toast(t('home.demoAdded')); ctx.navigate('#/library'); }, 'soft'))));
    view.append(h('div', { class: 'card tint-lav quote' }, '“', quoteOfTheDay(L, snap.today), '”'));
    mount(root, view);
    return;
  }

  // --- journey hero ---
  const startTarget = resume ? `#/lecture/${resume.lecture.id}?p=${resume.pageIndex}` : `#/lecture/${real[0].id}?p=${await nextUnreadIndex(ctx.store, real[0].id)}`;
  const hero = h('div', { class: 'hero stack' },
    h('div', { class: 'row', style: { gap: '1rem', flexWrap: 'nowrap' } },
      ring(snap.overall.percent ?? 0, snap.overall.percent === null ? '—' : `${snap.overall.percent}%`),
      h('div', { class: 'grow' }, h('h2', null, t('home.journey')),
        h('div', { class: 'muted' }, t('home.journeySub', { read: snap.overall.read, total: snap.overall.total })),
        h('div', { class: 'small' }, t('home.xpLine', { xp: fmtNum(snap.xpTotal, L), n: snap.level.level })),
        bar(snap.level.percent))),
    link(`▶ ${t('home.start')}`, startTarget, 'on-hero big'));
  view.append(hero);

  // --- continue ---
  if (resume) {
    view.append(h('a', { class: 'item', href: `#/lecture/${resume.lecture.id}?p=${resume.pageIndex}` },
      h('div', { class: 'thumb' }, '📖'),
      h('div', { class: 'grow' }, h('div', { class: 'small muted' }, t('home.continue')), h('b', null, resume.lecture.title),
        h('div', { class: 'small muted' }, t('home.pageOf', { n: resume.pageIndex, total: resume.pageCount }))),
      h('span', { 'aria-hidden': 'true' }, ctx.lang === 'ar' ? '‹' : '›')));
  }

  // --- the three essentials ---
  const due = snap.deck.due;
  const next = snap.tasks.filter((x) => !x.done && x.kind !== 'exam' && x.dueDate && x.dueDate <= snap.today).sort((a, b) => a.dueDate.localeCompare(b.dueDate))[0];
  view.append(section(t('home.today')));
  view.append(h('div', { class: 'grid two' },
    h('div', { class: 'card tint-sky stack' }, h('h3', null, `📝 ${t('home.whatToStudy')}`),
      next ? h('div', null, h('b', null, next.title), h('div', { class: 'small muted' }, `${next.estMinutes} ${t('common.min')}`)) : h('div', { class: 'muted' }, t('home.noTaskToday')),
      link(next ? t('home.openPlan') : t('home.makePlan'), '#/planner', 'soft sm')),
    h('div', { class: 'card tint-coral stack' }, h('h3', null, `🔁 ${t('home.reviewToday')}`),
      h('div', null, h('b', null, fmtNum(due, L)), ' ', t('home.cardsDue')),
      due ? link(t('home.reviewNow'), '#/cards', 'primary sm') : h('div', { class: 'small muted' }, snap.deck.total ? t('home.allCaughtUp') : t('home.noCards')))));

  // --- daily summary ---
  const td = snap.todayStat || {};
  view.append(section(t('home.summary')));
  view.append(h('div', { class: 'card grid three' },
    h('div', { class: 'stat' }, h('b', null, snap.overall.completedLectures), h('span', null, t('home.completedLectures'))),
    h('div', { class: 'stat' }, h('b', null, fmtDuration(td.seconds || 0, L)), h('span', null, t('home.studyTime'))),
    h('div', { class: 'stat' }, h('b', null, td.questions || 0), h('span', null, t('home.answered')))));

  // --- readiness ---
  const r = snap.readiness;
  const rc = h('div', { class: 'card stack' }, h('h3', null, `🎯 ${t('home.readiness')}`));
  if (r.score === null) {
    rc.append(h('p', { class: 'muted' }, t('home.readinessNone')),
      h('ul', { class: 'small muted' }, r.missing.map((m) => h('li', null, t(`home.need.${m}`)))));
  } else {
    rc.append(h('div', { class: 'row', style: { flexWrap: 'nowrap', gap: '1rem' } }, ring(r.score, `${r.score}%`, r.band === 'low' ? '' : ''),
      h('div', { class: 'grow small' }, ...Object.entries(r.parts).map(([k, v]) => h('div', null, t(`home.part.${k}`), ` ${v}%`, bar(v))))),
      h('div', { class: 'tiny' }, t('home.readinessNote')));
  }
  view.append(rc);

  // --- weak points ---
  const wk = h('div', { class: 'card stack' }, h('h3', null, `⚠️ ${t('home.weak')}`));
  const lecs = new Map(snap.lectures.map((l) => [l.id, l]));
  if (!snap.weak.length) wk.append(h('p', { class: 'muted small' }, t('home.weakNone')));
  else {
    for (const w of snap.weak.slice(0, 5)) {
      const l = lecs.get(w.lectureId);
      const pg = (snap.pagesByLecture.get(w.lectureId) || []).find((p) => p.id === w.pageId);
      if (!l || !pg) continue;
      wk.append(h('a', { class: 'item', href: `#/lecture/${l.id}?p=${pg.index}` }, h('div', { class: 'grow' }, h('b', null, l.title), h('div', { class: 'small muted' }, `${pg.label || t('lecture.page', { n: pg.index })} — ${t('home.weakWhy', { wrong: w.wrong, lapses: w.lapses })}`))));
    }
    wk.append(link(t('home.weakExam'), '#/exams?weak=1', 'soft sm'));
  }
  view.append(wk);

  // --- weekly calendar ---
  const byDate = new Map(snap.dailyStats.map((d) => [d.date, d]));
  const tasksBy = (date) => snap.tasks.filter((x) => x.dueDate === date && x.kind !== 'exam');
  const detail = h('div', { class: 'card flat small', 'aria-live': 'polite' });
  const showDay = (date) => {
    const s = byDate.get(date); const tk = tasksBy(date);
    mount(detail, h('b', null, dayLabel(date, L, { weekday: 'long', day: 'numeric', month: 'long' })),
      h('div', null, s ? t('home.dayStat', { min: Math.round((s.seconds || 0) / 60), q: s.questions || 0, c: s.cards || 0 }) : t('home.dayNone')),
      tk.length ? h('ul', null, tk.map((x) => h('li', null, `${x.done ? '✅' : '⬜'} ${x.title}`))) : null);
  };
  const cells = snap.weekDates.map((date) => {
    const s = byDate.get(date); const active = s && (s.seconds >= 60 || s.questions || s.cards || s.newPages || s.tasks);
    const cell = h('button', { type: 'button', class: `day ${date === snap.today ? 'today' : ''} ${active ? 'active' : ''}`, 'aria-pressed': 'false', onclick: () => { cells.forEach((c) => c.setAttribute('aria-pressed', 'false')); cell.setAttribute('aria-pressed', 'true'); showDay(date); } },
      h('span', { class: 'tiny' }, dayLabel(date, L)), h('b', null, String(Number(date.slice(8)))), h('span', { class: `dot ${active ? '' : 'none'}` }), tasksBy(date).length ? h('span', { class: 'tiny' }, `📌${tasksBy(date).length}`) : null);
    return cell;
  });
  view.append(section(t('home.week'), h('span', { class: 'small muted' }, t('home.weekGoal', { min: snap.week.minutes, gmin: snap.week.goal.minutes, q: snap.week.questions, gq: snap.week.goal.questions }))));
  view.append(h('div', { class: 'card stack' }, h('div', { class: 'week' }, cells), detail,
    h('div', { class: 'grid two' }, h('div', null, h('div', { class: 'tiny' }, t('home.goalTime')), bar(snap.week.minutesPct)), h('div', null, h('div', { class: 'tiny' }, t('home.goalQuestions')), bar(snap.week.questionsPct, 'lav')))));
  showDay(snap.today); cells[snap.weekDates.indexOf(snap.today)]?.setAttribute('aria-pressed', 'true');

  view.append(h('div', { class: 'card tint-lav quote' }, '“', quoteOfTheDay(L, snap.today), '”'));
  view.append(notice(t('common.eduNotice'), 'info'));
  mount(root, view);
}
