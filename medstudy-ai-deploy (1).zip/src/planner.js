// Study planner: deterministic schedule generation. All output is editable by the user.

export const pad = (n) => String(n).padStart(2, '0');
export const dateStr = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const parseDate = (s) => {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, m - 1, d);
};
export const addDays = (s, n) => {
  const d = parseDate(s);
  d.setDate(d.getDate() + n);
  return dateStr(d);
};
export const daysBetween = (a, b) => Math.round((parseDate(b) - parseDate(a)) / 86400000);

/**
 * Simple plan: one study task per lecture spread evenly from `start` to two days before `exam`,
 * a review task for each lecture at +1, +3 and +7 days after it is studied (if before the
 * exam), and an exam task on the exam date.
 * lectures: [{id, title, pageCount}]
 */
export function generatePlan({ lectures, start, exam, minutesPerPage = 4 }) {
  if (!lectures.length) return [];
  if (daysBetween(start, exam) < 1) throw new Error('تاريخ الامتحان لازم يكون بعد تاريخ البداية.');
  const lastStudyDay = Math.max(0, daysBetween(start, exam) - 2);
  const tasks = [];
  lectures.forEach((lec, i) => {
    const offset = lectures.length === 1 ? 0 : Math.round((i * lastStudyDay) / (lectures.length - 1));
    const day = addDays(start, Math.min(offset, lastStudyDay));
    tasks.push({
      title: `مذاكرة: ${lec.title}`, lectureId: lec.id, dueDate: day, kind: 'study',
      estMinutes: Math.max(15, Math.min(120, (lec.pageCount || 5) * minutesPerPage)),
    });
    for (const gap of [1, 3, 7]) {
      const rd = addDays(day, gap);
      if (daysBetween(rd, exam) >= 0) {
        tasks.push({ title: `مراجعة (${gap === 1 ? 'اليوم التالي' : `بعد ${gap} أيام`}): ${lec.title}`, lectureId: lec.id, dueDate: rd, kind: 'review', estMinutes: 15 });
      }
    }
  });
  tasks.push({ title: 'يوم الامتحان', lectureId: null, dueDate: exam, kind: 'exam', estMinutes: 0 });
  return tasks.sort((a, b) => a.dueDate.localeCompare(b.dueDate));
}

export function groupByDate(tasks) {
  const m = new Map();
  for (const t of tasks) {
    const k = t.dueDate || 'بدون تاريخ';
    if (!m.has(k)) m.set(k, []);
    m.get(k).push(t);
  }
  return [...m.entries()].sort((a, b) => a[0].localeCompare(b[0]));
}

// ---------- capacity-aware planner (v2) ----------

const DEFAULT_LABELS = {
  study: (title, i, n) => `مذاكرة: ${title}${n > 1 ? ` (${i}/${n})` : ''}`,
  review: (title, gap) => `مراجعة (${gap === 1 ? 'اليوم التالي' : `بعد ${gap} أيام`}): ${title}`,
  practice: (title) => `حل أسئلة: ${title}`,
  exam: () => 'يوم الامتحان',
};

const roundTo5 = (n) => Math.max(5, Math.round(n / 5) * 5);

/**
 * Capacity-aware plan. Each day has `dailyMinutes`; `reviewShare` of it is reserved for reviews and
 * practice. Lectures are ordered by `priority` (weak / late first). Work that does not fit before the
 * exam is returned in `unscheduled` and `feasible` is false: the plan never pretends to fit.
 *
 * lectures: [{id, title, pageCount, unreadPages?, priority?}]
 * Returns { tasks, feasible, neededMinutes, availableMinutes, unscheduled: [{lectureId, title, minutes}] }.
 */
export function generatePlanV2({ lectures, start, exam, dailyMinutes = 120, minutesPerPage = 4, reviewShare = 0.25, labels = {} }) {
  const L = { ...DEFAULT_LABELS, ...labels };
  const n = daysBetween(start, exam);
  if (n < 1) throw new Error('EXAM_BEFORE_START');
  const studyCap = Math.max(10, Math.round(dailyMinutes * (1 - reviewShare)));
  const reviewCap = Math.max(0, dailyMinutes - studyCap);
  const days = Array.from({ length: n }, (_, i) => ({ date: addDays(start, i), study: studyCap, review: reviewCap }));
  const ordered = lectures.map((l, i) => ({ l, i })).sort((a, b) => (b.l.priority || 0) - (a.l.priority || 0) || a.i - b.i).map((x) => x.l);

  const tasks = [];
  const unscheduled = [];
  let needed = 0;
  let cursor = 0;
  for (const lec of ordered) {
    const pages = lec.unreadPages ?? lec.pageCount ?? 5;
    if (pages <= 0) { // fully read: only spaced reviews remain
      for (const gap of [1, 3, 7]) {
        for (let d = Math.min(gap - 1, n - 1); d < n; d++) {
          if (days[d].review >= 10) { days[d].review -= 10; tasks.push({ title: L.review(lec.title, gap), lectureId: lec.id, dueDate: days[d].date, kind: 'review', estMinutes: 10 }); break; }
        }
      }
      continue;
    }
    const minutes = roundTo5(Math.min(600, pages * minutesPerPage));
    needed += minutes;
    let remaining = minutes;
    const chunks = [];
    while (remaining > 0 && cursor < n) {
      if (days[cursor].study <= 0) { cursor++; continue; }
      const take = Math.min(remaining, days[cursor].study);
      days[cursor].study -= take;
      remaining -= take;
      chunks.push({ date: days[cursor].date, minutes: take, idx: cursor });
    }
    if (remaining > 0) unscheduled.push({ lectureId: lec.id, title: lec.title, minutes: remaining });
    chunks.forEach((c, i) => tasks.push({ title: L.study(lec.title, i + 1, chunks.length), lectureId: lec.id, dueDate: c.date, kind: 'study', estMinutes: c.minutes }));
    if (!chunks.length) continue;
    const lastIdx = chunks[chunks.length - 1].idx;
    const place = (targetIdx, minutesNeeded) => {
      for (let d = targetIdx; d < n; d++) {
        if (days[d].review >= minutesNeeded) { days[d].review -= minutesNeeded; return days[d].date; }
      }
      return null;
    };
    for (const gap of [1, 3, 7]) {
      const date = place(lastIdx + gap, 10);
      if (date) tasks.push({ title: L.review(lec.title, gap), lectureId: lec.id, dueDate: date, kind: 'review', estMinutes: 10 });
    }
    const pdate = place(lastIdx + 2, 15);
    if (pdate) tasks.push({ title: L.practice(lec.title), lectureId: lec.id, dueDate: pdate, kind: 'practice', estMinutes: 15 });
  }
  tasks.push({ title: L.exam(), lectureId: null, dueDate: exam, kind: 'exam', estMinutes: 0 });
  tasks.sort((a, b) => a.dueDate.localeCompare(b.dueDate));
  return { tasks, feasible: unscheduled.length === 0, neededMinutes: needed, availableMinutes: studyCap * n, unscheduled };
}

const KIND_ORDER = { study: 0, practice: 1, review: 2, exam: 3 };

/**
 * Re-pack the NOT-done tasks from `today` to the day before the exam, `dailyMinutes` per day.
 * Overdue tasks go first; no task moves earlier than its original date (reviews keep their spacing).
 * Done tasks and the exam day stay as they are. Tasks that no longer fit come back in `unscheduled`
 * (and keep their date) so the student sees the real situation.
 */
export function redistribute({ tasks, today, exam, dailyMinutes = 120 }) {
  const fixed = tasks.filter((t) => t.done || t.kind === 'exam');
  const pending = tasks.filter((t) => !t.done && t.kind !== 'exam');
  const n = Math.max(0, daysBetween(today, exam));
  const cap = Array.from({ length: n }, (_, i) => ({ date: addDays(today, i), left: dailyMinutes }));
  for (const t of fixed) {
    if (t.done && t.dueDate && t.dueDate >= today) {
      const d = cap.find((c) => c.date === t.dueDate);
      if (d) d.left = Math.max(0, d.left - (t.estMinutes || 0));
    }
  }
  const order = [...pending].sort((a, b) => {
    const ao = a.dueDate && a.dueDate < today ? 0 : 1;
    const bo = b.dueDate && b.dueDate < today ? 0 : 1;
    return ao - bo || (a.dueDate || '9').localeCompare(b.dueDate || '9') || KIND_ORDER[a.kind] - KIND_ORDER[b.kind];
  });
  const moved = [];
  const unscheduled = [];
  const out = [...fixed];
  for (const t of order) {
    const lower = t.dueDate && t.dueDate > today ? t.dueDate : today;
    const mins = t.estMinutes || 0;
    const slot = cap.find((c) => c.date >= lower && (c.left >= mins || c.left === dailyMinutes));
    if (!slot) { unscheduled.push(t); out.push(t); continue; }
    slot.left = Math.max(0, slot.left - mins);
    if (slot.date !== t.dueDate) { moved.push(t.id); out.push({ ...t, dueDate: slot.date }); } else out.push(t);
  }
  return { tasks: out.sort((a, b) => (a.dueDate || '9').localeCompare(b.dueDate || '9')), moved, unscheduled };
}

export const postponeTask = (task, toDate) => ({ ...task, dueDate: toDate, postponedCount: (task.postponedCount || 0) + 1 });

export const isOverdue = (task, today) => !task.done && !!task.dueDate && task.dueDate < today && task.kind !== 'exam';

/** Real progress from completed tasks: minutes done / minutes planned (exam day excluded). */
export function planProgress(tasks) {
  const work = tasks.filter((t) => t.kind !== 'exam');
  const planned = work.reduce((s, t) => s + (t.estMinutes || 0), 0);
  const done = work.filter((t) => t.done).reduce((s, t) => s + (t.estMinutes || 0), 0);
  return { tasks: work.length, doneTasks: work.filter((t) => t.done).length, plannedMinutes: planned, doneMinutes: done, percent: work.length ? Math.round((work.filter((t) => t.done).length / work.length) * 100) : null };
}

/** The 7 dates of the week containing `today`; weekStart: 0=Sun..6=Sat (Saturday by default). */
export function weekDays(today, weekStart = 6) {
  const d = parseDate(today);
  const back = (d.getDay() - weekStart + 7) % 7;
  const first = addDays(today, -back);
  return Array.from({ length: 7 }, (_, i) => addDays(first, i));
}
