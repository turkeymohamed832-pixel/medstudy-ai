// Lazy loaders for the heavy engines (self-hosted in /vendor). Nothing is fetched until a file is imported.
let pdfjs, jszip, ocr;
const loadScript = (src) => new Promise((res, rej) => {
  const s = document.createElement('script');
  s.src = src; s.onload = res; s.onerror = () => rej(new Error(`Could not load ${src}`));
  document.head.append(s);
});
export const loaders = {
  async getPdfjs() {
    if (!pdfjs) {
      pdfjs = await import('../vendor/pdfjs/pdf.min.mjs');
      pdfjs.GlobalWorkerOptions.workerSrc = new URL('../vendor/pdfjs/pdf.worker.min.mjs', import.meta.url).href;
    }
    return pdfjs;
  },
  async getJSZip() {
    if (!jszip) { if (!globalThis.JSZip) await loadScript(new URL('../vendor/jszip/jszip.min.js', import.meta.url).href); jszip = globalThis.JSZip; }
    return jszip;
  },
  async getOcr() {
    if (!ocr) {
      if (!globalThis.Tesseract) await loadScript(new URL('../vendor/tesseract/tesseract.min.js', import.meta.url).href);
      const base = new URL('../vendor/', import.meta.url).href;
      ocr = async (data, langs = 'eng+ara') => {
        const worker = await globalThis.Tesseract.createWorker(langs, 1, {
          workerPath: `${base}tesseract/worker.min.js`, corePath: `${base}tesseract/core/`, langPath: `${base}tessdata/`, gzip: true,
        });
        try {
          const { data: out } = await worker.recognize(new Blob([data]));
          return { text: out.text, confidence: out.confidence };
        } finally { await worker.terminate(); }
      };
    }
    return ocr;
  },
};
