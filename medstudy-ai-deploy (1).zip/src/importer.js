// File import orchestration: detect type -> extract -> build records -> store.
// Extraction never silently drops anything: empty/failed pages are kept with a status
// and warnings the UI shows.

import { extractPdf } from './importers/pdf.js';
import { extractPptx } from './importers/pptx.js';
import { extractImage } from './importers/image.js';
import { normalizeText, sha256Hex } from './importers/textutil.js';
import {
  PROCESSING, makeLecture, makeSourcePage, makeOriginalText, makeLearningProgress, makeCachedAsset, pageId,
} from './models.js';

const IMAGE_EXT = /\.(png|jpe?g|webp|bmp|gif)$/i;
export const MAX_FILE_BYTES = 100 * 1024 * 1024;

export function detectKind(name, bytes) {
  const head = bytes.subarray(0, 5);
  const isPdf = head[0] === 0x25 && head[1] === 0x50 && head[2] === 0x44 && head[3] === 0x46; // %PDF
  const isZip = head[0] === 0x50 && head[1] === 0x4b; // PK
  if (/\.pdf$/i.test(name)) return isPdf ? 'pdf' : 'invalid';
  if (/\.pptx$/i.test(name)) return isZip ? 'pptx' : 'invalid';
  if (/\.ppt$/i.test(name)) return 'legacy_ppt';
  if (IMAGE_EXT.test(name)) return 'image';
  if (/\.(txt|md|text)$/i.test(name)) return 'text';
  return 'unsupported';
}

export const KIND_ERRORS = {
  invalid: 'The file contents do not match its extension, so it was not imported.',
  legacy_ppt: 'Old .ppt files are not supported. Open it in PowerPoint and save as .pptx, or export as PDF.',
  unsupported: 'Unsupported file type. Supported: PDF, PPTX, images (PNG/JPG/WEBP), TXT/MD.',
};

/**
 * Extract a file into pages.
 * deps: { pdfjsLib, JSZip, ocr }  (only the ones needed for the file kind)
 * Returns { kind, extractor, pages, warnings, sourceHash }.
 */
export async function extractFile({ name, data }, deps = {}) {
  const bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
  if (bytes.length === 0) throw new Error('The file is empty.');
  if (bytes.length > MAX_FILE_BYTES) throw new Error('The file is larger than 100 MB.');
  const kind = detectKind(name, bytes);
  if (KIND_ERRORS[kind]) throw new Error(KIND_ERRORS[kind]);

  let result;
  if (kind === 'pdf') {
    if (!deps.pdfjsLib) throw new Error('PDF engine is not loaded.');
    result = await extractPdf(bytes, deps);
  } else if (kind === 'pptx') {
    if (!deps.JSZip) throw new Error('PPTX engine is not loaded.');
    result = await extractPptx(bytes, deps);
  } else if (kind === 'image') {
    result = await extractImage(bytes, { ocr: deps.ocr, fileName: name });
  } else {
    const text = normalizeText(new TextDecoder('utf-8').decode(bytes));
    result = {
      kind: 'text', extractor: 'text', warnings: [],
      pages: [{ index: 1, label: name, text, status: text ? 'ok' : 'empty', warnings: text ? [] : ['The file has no text.'] }],
    };
  }
  result.sourceHash = await sha256Hex(bytes);
  return result;
}

function lectureStateFor(pages) {
  const bad = pages.filter((p) => p.status !== 'ok').length;
  if (bad === 0) return PROCESSING.DONE;
  if (bad === pages.length) return PROCESSING.FAILED;
  return PROCESSING.PARTIAL;
}

function collectErrors(pages, extra = []) {
  const errs = [...extra];
  for (const p of pages) for (const w of p.warnings) errs.push({ page: p.index, code: p.status, message: w });
  return errs;
}

/** Create a new lecture from an extraction result and save everything atomically. */
export async function saveNewLecture(store, { subjectId, title, fileName, result, fileBlob = null, isDemo = false, examTag = '' }) {
  const lecture = makeLecture({
    subjectId, title, examTag, sourceFileName: fileName, sourceKind: result.kind, sourceHash: result.sourceHash,
    pageCount: result.pages.length, processingState: lectureStateFor(result.pages),
    errors: collectErrors(result.pages, result.warnings), isDemo,
  });
  const rows = buildPageRows(lecture.id, result);
  const batch = {
    lectures: [lecture],
    sourcePages: rows.pages,
    originalTexts: rows.texts,
    learningProgress: [makeLearningProgress({ lectureId: lecture.id })],
  };
  if (fileBlob) {
    batch.cachedAssets = [makeCachedAsset({ lectureId: lecture.id, name: fileName, mime: fileBlob.type, size: fileBlob.size, blob: fileBlob })];
  }
  await store.putMany(batch);
  return lecture;
}

function buildPageRows(lectureId, result) {
  const pages = [];
  const texts = [];
  for (const p of result.pages) {
    pages.push(makeSourcePage({ lectureId, index: p.index, label: p.label, status: p.status, warnings: p.warnings }));
    texts.push(makeOriginalText({
      lectureId, pageId: pageId(lectureId, p.index), extractedText: p.text, extractor: result.extractor,
    }));
  }
  return { pages, texts };
}

/**
 * Re-import a newer version of a lecture. Page ids are stable per index, so notes,
 * translations, flashcards and the user's corrections stay attached. Nothing is deleted:
 * pages missing from the new file are marked "removed_in_update".
 */
export async function reimportLecture(store, lectureId, result) {
  const lecture = await store.get('lectures', lectureId);
  if (!lecture) throw new Error('Lecture not found');
  const oldPages = await store.getAllBy('sourcePages', 'lectureId', lectureId);
  const oldTexts = await store.getAllBy('originalTexts', 'lectureId', lectureId);
  const textByPage = new Map(oldTexts.map((t) => [t.pageId, t]));
  const newIdx = new Set(result.pages.map((p) => p.index));

  const pages = [];
  const texts = [];
  const changedWithCorrection = [];
  for (const p of result.pages) {
    const id = pageId(lectureId, p.index);
    pages.push(makeSourcePage({ lectureId, index: p.index, label: p.label, status: p.status, warnings: p.warnings }));
    const old = textByPage.get(id);
    const ot = makeOriginalText({ lectureId, pageId: id, extractedText: p.text, extractor: result.extractor });
    if (old) {
      ot.createdAt = old.createdAt;
      ot.reviewedText = old.reviewedText;
      ot.edits = old.edits;
      if (old.reviewedText !== null && old.reviewedText !== undefined && old.extractedText !== p.text) {
        ot.edits = [...old.edits, { at: new Date().toISOString(), note: 'Source text changed in a re-import; your correction was kept — please re-check it.' }];
        changedWithCorrection.push(p.index);
      }
    }
    texts.push(ot);
  }
  for (const op of oldPages) {
    if (!newIdx.has(op.index)) pages.push({ ...op, status: 'removed_in_update', warnings: ['This page is not in the newer file. Your notes were kept.'] });
  }
  const updated = {
    ...lecture,
    sourceKind: result.kind,
    sourceHash: result.sourceHash,
    pageCount: result.pages.length,
    processingState: lectureStateFor(result.pages),
    errors: collectErrors(result.pages, result.warnings),
  };
  await store.putMany({ sourcePages: pages, originalTexts: texts, lectures: [updated] });
  return { lecture: updated, changedWithCorrection };
}

/** Find an existing lecture with the same file content (to warn about duplicates). */
export async function findDuplicate(store, sourceHash) {
  const all = await store.getAll('lectures');
  return all.find((l) => l.sourceHash && l.sourceHash === sourceHash) || null;
}

/**
 * Extract one or several files. Several files are allowed only when all are images; they
 * become consecutive pages of one lecture (e.g. photos of slides). Returns the same shape
 * as extractFile. `loaders` are lazy async loaders: { getPdfjs, getJSZip, getOcr }.
 */
export async function extractFiles(files, loaders = {}) {
  if (!files.length) throw new Error('NO_FILE');
  const kinds = files.map((f) => detectKind(f.name, f.data instanceof Uint8Array ? f.data : new Uint8Array(f.data)));
  if (files.length > 1 && !kinds.every((k) => k === 'image')) {
    throw new Error('MULTI_NON_IMAGE');
  }
  const deps = {};
  if (kinds.includes('pdf')) deps.pdfjsLib = await loaders.getPdfjs();
  if (kinds.includes('pptx')) deps.JSZip = await loaders.getJSZip();
  if (kinds.includes('image')) deps.ocr = await loaders.getOcr();
  if (files.length === 1) return extractFile(files[0], deps);

  const pages = [];
  const hashes = [];
  for (const f of files) {
    const r = await extractFile(f, deps);
    hashes.push(r.sourceHash);
    pages.push({ ...r.pages[0], index: pages.length + 1, label: f.name });
  }
  return {
    kind: 'image', extractor: 'tesseract', warnings: [], pages,
    sourceHash: await sha256Hex(new TextEncoder().encode(hashes.join(','))),
  };
}
