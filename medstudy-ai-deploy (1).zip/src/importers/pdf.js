// PDF text extraction with pdf.js. The pdf.js module is injected so the same code runs in
// the browser (vendored build) and in Node tests (legacy build).

import { normalizeText } from './textutil.js';

/** Join pdf.js text items into lines using hasEOL and vertical position changes. */
export function itemsToText(items) {
  let out = '';
  let lastY = null;
  for (const it of items) {
    if (typeof it.str !== 'string') continue;
    const y = it.transform ? it.transform[5] : null;
    if (lastY !== null && y !== null && Math.abs(y - lastY) > 2 && !out.endsWith('\n')) out += '\n';
    out += it.str;
    if (it.hasEOL) out += '\n';
    if (y !== null) lastY = y;
  }
  return out;
}

export async function extractPdf(data, { pdfjsLib }) {
  const bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
  let doc;
  const task = pdfjsLib.getDocument({ data: bytes, useSystemFonts: true, isEvalSupported: false });
  try {
    doc = await task.promise;
  } catch (e) {
    try { await task.destroy(); } catch { /* ignore */ }
    if (e && e.name === 'PasswordException') {
      throw new Error('This PDF is password-protected. Remove the password and import it again.');
    }
    throw new Error(`Could not open this PDF (${e && e.message ? e.message : 'unknown error'}).`);
  }
  const pages = [];
  const warnings = [];
  for (let i = 1; i <= doc.numPages; i++) {
    const page = { index: i, label: `Page ${i}`, text: '', status: 'ok', warnings: [] };
    try {
      const p = await doc.getPage(i);
      const tc = await p.getTextContent();
      page.text = normalizeText(itemsToText(tc.items));
      if (!page.text) {
        page.status = 'needs_ocr';
        page.warnings.push('No text layer on this page (probably a scanned image or a picture). Import it as an image to run OCR.');
      }
      p.cleanup();
    } catch (e) {
      page.status = 'failed';
      page.warnings.push(`Could not read this page: ${e.message}`);
    }
    pages.push(page);
  }
  const meta = { numPages: doc.numPages };
  await task.destroy();
  return { kind: 'pdf', extractor: 'pdfjs', pages, warnings, meta };
}
