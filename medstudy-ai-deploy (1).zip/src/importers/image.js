// Image import via OCR (tesseract.js). The OCR engine is injected: in the app it is the
// vendored tesseract.js worker; in tests a fake can be passed. OCR output is flagged as
// machine-read text that the user must review.

import { normalizeText } from './textutil.js';

export async function extractImage(data, { ocr, fileName = 'image' }) {
  if (typeof ocr !== 'function') {
    throw new Error('OCR engine is not available in this environment.');
  }
  const { text, confidence } = await ocr(data);
  const page = { index: 1, label: fileName, text: normalizeText(text), status: 'ok', warnings: [] };
  if (!page.text) {
    page.status = 'empty';
    page.warnings.push('OCR found no readable text in this image.');
  } else {
    page.warnings.push('Text was read by OCR. Review it against the image before relying on numbers, doses or units.');
    if (typeof confidence === 'number' && confidence < 70) {
      page.warnings.push(`Low OCR confidence (${Math.round(confidence)}%). Expect mistakes.`);
    }
  }
  return { kind: 'image', extractor: 'tesseract', pages: [page], warnings: [] };
}
