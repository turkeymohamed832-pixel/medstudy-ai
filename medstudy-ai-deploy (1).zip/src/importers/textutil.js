// Small text helpers shared by importers and tools.
// Rule: never alter meaning. We only normalise line endings and strip NUL / control chars.

export function normalizeText(s) {
  return String(s ?? '')
    .replace(/\r\n?/g, '\n')
    .replace(/\u0000/g, '')
    // strip control characters except tab/newline
    .replace(/[\u0001-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{4,}/g, '\n\n\n')
    .trim();
}

const XML_ENTITIES = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" };

export function decodeXml(s) {
  return s.replace(/&(#x[0-9a-fA-F]+|#\d+|amp|lt|gt|quot|apos);/g, (_, e) => {
    if (e[0] === '#') {
      const code = e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      try {
        return String.fromCodePoint(code);
      } catch {
        return '';
      }
    }
    return XML_ENTITIES[e];
  });
}

/** Fraction of letters that are Arabic (0..1). Used to pick text direction in the UI. */
export function arabicRatio(s) {
  const letters = s.match(/\p{L}/gu);
  if (!letters || !letters.length) return 0;
  const ar = s.match(/[؀-ۿݐ-ݿﭐ-﷿ﹰ-﻿]/g);
  return (ar ? ar.length : 0) / letters.length;
}

export async function sha256Hex(buf) {
  const d = await globalThis.crypto.subtle.digest('SHA-256', buf);
  return [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, '0')).join('');
}
