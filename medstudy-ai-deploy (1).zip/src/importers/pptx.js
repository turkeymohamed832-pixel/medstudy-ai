// PowerPoint (.pptx) text extraction using JSZip. No DOM needed; XML is scanned with
// regular expressions, so imported files are never parsed as HTML or executed.
// The file is treated as untrusted: entry count and per-entry size are capped.

import { decodeXml, normalizeText } from './textutil.js';

const MAX_ENTRIES = 5000;
const MAX_XML_CHARS = 20 * 1024 * 1024;

const attr = (tag, name) => {
  const m = new RegExp(`\\b${name}="([^"]*)"`).exec(tag);
  return m ? m[1] : null;
};

function paragraphText(pXml) {
  // a:p contents in order: runs (a:t), line breaks (a:br), tabs
  const lvlTag = /<a:pPr\b[^>]*>/.exec(pXml);
  const lvl = lvlTag ? parseInt(attr(lvlTag[0], 'lvl') || '0', 10) || 0 : 0;
  let out = '';
  const re = /<a:t(?:\s[^>]*)?>([\s\S]*?)<\/a:t>|<a:t\s*\/>|<a:br\b[^>]*\/?>|<a:tab\b[^>]*\/?>/g;
  let m;
  while ((m = re.exec(pXml))) {
    if (m[0].startsWith('<a:br')) out += '\n';
    else if (m[0].startsWith('<a:tab')) out += '\t';
    else if (m[1] !== undefined) out += decodeXml(m[1]);
  }
  return out.trim() ? '  '.repeat(Math.min(lvl, 6)) + out : '';
}

function paragraphsOf(xml) {
  const ps = xml.match(/<a:p\b[\s\S]*?<\/a:p>/g) || [];
  return ps.map(paragraphText).filter(Boolean);
}

function tableText(frameXml) {
  const rows = frameXml.match(/<a:tr\b[\s\S]*?<\/a:tr>/g) || [];
  return rows
    .map((r) => {
      const cells = r.match(/<a:tc\b[\s\S]*?<\/a:tc>/g) || [];
      return cells.map((c) => paragraphsOf(c).join(' ').trim()).join(' | ');
    })
    .filter((r) => r.replace(/[|\s]/g, ''))
    .join('\n');
}

/** Extract text from one slide or notes XML. Returns {text, pictures, otherGraphics}. */
export function extractSlideXml(xml, { notes = false } = {}) {
  const blocks = xml.match(/<p:sp\b[\s\S]*?<\/p:sp>|<p:graphicFrame\b[\s\S]*?<\/p:graphicFrame>/g) || [];
  const parts = [];
  let otherGraphics = 0;
  for (const b of blocks) {
    if (b.startsWith('<p:graphicFrame')) {
      if (/<a:tbl\b/.test(b)) {
        const t = tableText(b);
        if (t) parts.push(t);
      } else otherGraphics++;
      continue;
    }
    const ph = /<p:ph\b[^>]*>/.exec(b);
    const phType = ph ? attr(ph[0], 'type') : null;
    // slide-number placeholders and (in notes) the slide thumbnail carry no study content
    if (phType === 'sldNum' || phType === 'sldImg') continue;
    if (notes && phType && phType !== 'body') continue;
    const t = paragraphsOf(b).join('\n');
    if (t) parts.push(t);
  }
  const pictures = (xml.match(/<p:pic\b/g) || []).length;
  return { text: parts.join('\n\n'), pictures, otherGraphics };
}

function relsMap(relsXml) {
  const map = {};
  const re = /<Relationship\b[^>]*>/g;
  let m;
  while ((m = re.exec(relsXml || ''))) {
    const id = attr(m[0], 'Id');
    if (id) map[id] = { target: attr(m[0], 'Target'), type: attr(m[0], 'Type') || '' };
  }
  return map;
}

function resolvePath(baseDir, target) {
  if (target.startsWith('/')) return target.slice(1);
  const parts = baseDir.split('/').filter(Boolean);
  for (const seg of target.split('/')) {
    if (seg === '..') parts.pop();
    else if (seg && seg !== '.') parts.push(seg);
  }
  return parts.join('/');
}

/**
 * @param {ArrayBuffer|Uint8Array} data
 * @param {{JSZip: any}} deps JSZip constructor (injected so Node and browser can differ)
 */
export async function extractPptx(data, { JSZip }) {
  let zip;
  try {
    zip = await JSZip.loadAsync(data);
  } catch (e) {
    throw new Error('This file is not a valid .pptx (could not open it as a PowerPoint package).');
  }
  const names = Object.keys(zip.files);
  if (names.length > MAX_ENTRIES) throw new Error('This .pptx has an unusually large number of parts and was rejected.');

  const read = async (name) => {
    const f = zip.file(name);
    if (!f) return null;
    const s = await f.async('string');
    if (s.length > MAX_XML_CHARS) throw new Error(`Part ${name} is too large to process safely.`);
    return s;
  };

  // 1. slide order from presentation.xml (falls back to numeric file order)
  let slidePaths = [];
  const pres = await read('ppt/presentation.xml');
  const presRels = relsMap(await read('ppt/_rels/presentation.xml.rels'));
  if (pres) {
    const ids = [...pres.matchAll(/<p:sldId\b[^>]*>/g)].map((m) => attr(m[0], 'r:id'));
    slidePaths = ids
      .map((id) => presRels[id] && resolvePath('ppt', presRels[id].target))
      .filter((p) => p && zip.file(p));
  }
  let fallback = false;
  if (!slidePaths.length) {
    fallback = true;
    slidePaths = names
      .filter((n) => /^ppt\/slides\/slide\d+\.xml$/.test(n))
      .sort((a, b) => parseInt(a.match(/(\d+)\.xml$/)[1], 10) - parseInt(b.match(/(\d+)\.xml$/)[1], 10));
  }
  if (!slidePaths.length) throw new Error('No slides were found in this .pptx file.');

  const pages = [];
  const warnings = [];
  if (fallback) warnings.push({ page: null, code: 'slide_order_fallback', message: 'Slide order was inferred from file names.' });

  for (let i = 0; i < slidePaths.length; i++) {
    const path = slidePaths[i];
    const index = i + 1;
    const page = { index, label: `Slide ${index}`, text: '', status: 'ok', warnings: [] };
    try {
      const xml = await read(path);
      const s = extractSlideXml(xml);
      let text = s.text;

      // speaker notes, if any
      const dir = path.slice(0, path.lastIndexOf('/'));
      const relPath = `${dir}/_rels/${path.slice(path.lastIndexOf('/') + 1)}.rels`;
      const rels = relsMap(await read(relPath));
      const notesRel = Object.values(rels).find((r) => /\/notesSlide$/.test(r.type));
      if (notesRel) {
        const nxml = await read(resolvePath(dir, notesRel.target));
        if (nxml) {
          const n = extractSlideXml(nxml, { notes: true });
          if (n.text) text += (text ? '\n\n' : '') + '[Speaker notes]\n' + n.text;
        }
      }
      page.text = normalizeText(text);
      if (s.pictures) page.warnings.push(`${s.pictures} picture(s) on this slide are not extracted as text (import them as images to OCR).`);
      if (s.otherGraphics) page.warnings.push(`${s.otherGraphics} chart/diagram object(s) on this slide are not extracted.`);
      if (!page.text) {
        page.status = 'empty';
        page.warnings.push('No text found on this slide.');
      }
    } catch (e) {
      page.status = 'failed';
      page.warnings.push(`Could not read this slide: ${e.message}`);
    }
    pages.push(page);
  }
  return { kind: 'pptx', extractor: 'jszip-pptx', pages, warnings };
}
