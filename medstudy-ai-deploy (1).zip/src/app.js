import { Store } from './db.js';
import { ctx, loadSettings, setSetting } from './ctx.js';
import { loaders } from './loaders.js';
import { h, mount, toast } from './dom.js';
import { t, setLang } from './i18n.js';
import { applyTheme } from './prefs.js';
import { createTracker, checkAchievements } from './activity.js';
import { celebrate } from './ui/common.js';
import { openMore, MORE_ITEMS } from './ui/more-sheet.js';

const ROUTES = {
  home: () => import('./ui/home.js').then((m) => m.renderHome),
  library: () => import('./ui/library.js').then((m) => m.renderLibrary),
  import: () => import('./ui/import.js').then((m) => m.renderImport),
  lecture: () => import('./ui/lecture.js').then((m) => m.renderLecture),
  cards: () => import('./ui/flashcards.js').then((m) => m.renderCards),
  exams: () => import('./ui/exams.js').then((m) => m.renderExams),
  planner: () => import('./ui/planner.js').then((m) => m.renderPlanner),
  assistant: () => import('./ui/assistant.js').then((m) => m.renderAssistant),
  progress: () => import('./ui/progress.js').then((m) => m.renderProgress),
  achievements: () => import('./ui/progress.js').then((m) => m.renderAchievements),
  bookmarks: () => import('./ui/progress.js').then((m) => m.renderBookmarks),
  settings: () => import('./ui/settings.js').then((m) => m.renderSettings),
};
const STUDY = new Set(['lecture', 'cards', 'exams', 'assistant']);
const NAV = [['home', '🏠', 'nav.home'], ['library', '📚', 'nav.library'], ['cards', '🃏', 'nav.cards'], ['exams', '📝', 'nav.exams']];
let renderToken = 0;

export function parseHash(hash = location.hash) {
  const [path, query = ''] = hash.replace(/^#\/?/, '').split('?');
  const [route = 'home', ...rest] = path.split('/');
  return { route: route || 'home', args: rest.map(decodeURIComponent), query: new URLSearchParams(query) };
}

function drawNav(route) {
  const items = [...NAV];
  const mk = (cls) => [
    ...items.map(([r, ic, key]) => h('a', { class: 'nav-item', href: `#/${r}`, 'aria-current': r === route ? 'page' : null }, h('span', { class: 'ic', 'aria-hidden': 'true' }, ic), t(key))),
    h('button', { type: 'button', class: 'nav-item', onclick: openMore, 'aria-current': MORE_ITEMS.some(([r]) => r === route) || route === 'import' ? 'page' : null }, h('span', { class: 'ic', 'aria-hidden': 'true' }, '☰'), t('nav.more')),
  ];
  const side = document.getElementById('sidebar');
  mount(side, h('div', { class: 'topbar' }, h('span', { class: 'brand' }, h('span', { class: 'logo', 'aria-hidden': 'true' }, '＋'), 'MedStudy')),
    ...mk().slice(0, 4), ...MORE_ITEMS.map(([r, ic, key]) => h('a', { class: 'nav-item', href: `#/${r}`, 'aria-current': r === route ? 'page' : null }, h('span', { class: 'ic', 'aria-hidden': 'true' }, ic), t(key))));
  mount(document.getElementById('bottom-nav'), ...mk());
}

export async function render() {
  const token = ++renderToken;
  document.querySelectorAll('dialog.modal').forEach((d) => { try { d.close(); } catch { /* ignore */ } d.remove(); });
  const { route, args, query } = parseHash();
  const main = document.getElementById('main');
  ctx.tracker?.setActive(STUDY.has(route));
  drawNav(route);
  const loader = ROUTES[route] || ROUTES.home;
  try {
    const fn = await loader();
    if (token !== renderToken) return;
    window.scrollTo(0, 0);
    await fn(main, { args, query });
  } catch (e) {
    console.error(e);
    mount(main, h('div', { class: 'notice bad', role: 'alert' }, `${t('common.error')}: ${e.message}`));
  }
  main.focus({ preventScroll: true });
}

ctx.navigate = (hash) => { if (location.hash === hash) render(); else location.hash = hash; };
ctx.refreshChrome = () => render();
ctx.rerender = render;

export async function init() {
  ctx.store = await Store.open();
  ctx.loaders = loaders;
  await loadSettings();
  try { setLang(localStorage.getItem('ms_lang') || ctx.settings.lang || 'ar'); } catch { setLang(ctx.settings.lang || 'ar'); }
  try { if (ctx.settings.theme && !localStorage.getItem('ms_theme')) localStorage.setItem('ms_theme', ctx.settings.theme); } catch { /* ignore */ }
  matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change', () => { if ((localStorage.getItem('ms_theme') || 'auto') === 'auto') applyTheme('auto'); });

  ctx.tracker = createTracker({ store: ctx.store });
  for (const ev of ['pointerdown', 'keydown', 'scroll', 'touchstart']) addEventListener(ev, () => ctx.tracker.touch(), { passive: true });
  setInterval(async () => { ctx.tracker.tick(); await ctx.tracker.flush().catch(() => {}); }, 5000);
  document.addEventListener('visibilitychange', () => { ctx.tracker.tick(); if (document.visibilityState === 'hidden') ctx.tracker.flush(true).catch(() => {}); });
  addEventListener('pagehide', () => { ctx.tracker.tick(); ctx.tracker.flush(true).catch(() => {}); });

  addEventListener('hashchange', render);
  addEventListener('online', () => document.body.classList.remove('offline'));
  addEventListener('offline', () => { document.body.classList.add('offline'); toast(t('common.offlineNow')); });
  await render();

  // badges: unlock + light celebration (once per badge)
  try {
    const fresh = await checkAchievements(ctx.store, new Date());
    if (fresh && fresh.length) { celebrate('🏆'); toast(t('ach.unlocked', { name: t(`badge.${fresh[0]}.name`) })); }
  } catch (e) { console.warn('achievements', e); }

  if ('serviceWorker' in navigator && globalThis.isSecureContext) navigator.serviceWorker.register('sw.js').catch((e) => console.warn('sw', e));
}
init().catch((e) => {
  console.error(e);
  mount(document.getElementById('main'), h('div', { class: 'notice bad' }, `MedStudy: ${e.message}`));
});
