// Sample content so a new user can try every screen. Marked isDemo: excluded from ALL statistics and badges.
import { makeSubject } from './models.js';
import { saveNewLecture } from './importer.js';

export const DEMO_PAGES = [
  { label: 'Slide 1', text: 'Menstrual cycle overview\n\nThe normal menstrual cycle lasts 28 days (range 21-35 days).\nOvulation occurs around day 14 in a 28-day cycle.' },
  { label: 'Slide 2', text: 'Menstrual blood loss\n\nNormal blood loss is about 30-40 ml per cycle.\nHeavy menstrual bleeding (HMB) is blood loss above 80 ml per cycle.\nTranexamic acid is an antifibrinolytic used to reduce menstrual bleeding.' },
  { label: 'Slide 3', text: 'Uterine prolapse\n\nUterine prolapse is descent of the uterus into or beyond the vagina.\nA pessary should be changed or cleaned regularly, as advised by the clinician.' },
];

export async function addDemo(store) {
  const existing = (await store.getAll('lectures')).find((l) => l.isDemo);
  if (existing) return existing;
  const subject = makeSubject({ name: 'Demo — Gynecology', isDemo: true });
  await store.put('subjects', subject);
  const result = {
    kind: 'text', extractor: 'text', warnings: [], sourceHash: 'demo-lecture-v1',
    pages: DEMO_PAGES.map((p, i) => ({ index: i + 1, label: p.label, text: p.text, status: 'ok', warnings: [] })),
  };
  return saveNewLecture(store, { subjectId: subject.id, title: 'Demo — Menstrual cycle (sample)', fileName: 'demo.txt', result, isDemo: true });
}
