// Theme + language preferences (kept out of app.js so screens can use them without booting the app).
import { ctx, setSetting } from './ctx.js';
import { setLang } from './i18n.js';

export async function applyTheme(mode) {
  try { localStorage.setItem('ms_theme', mode); } catch { /* ignore */ }
  const dark = mode === 'dark' || (mode === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', dark ? '#0b1f1e' : '#0f766e');
  await setSetting('theme', mode);
}
export async function changeLang(lang) {
  setLang(lang);
  await setSetting('lang', lang);
  ctx.rerender?.();
}
