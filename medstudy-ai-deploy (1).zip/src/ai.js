// AI service client.
//
// Privacy / security design:
//  * The app never holds a secret API key. It talks to an endpoint the user configures
//    (for example the reference proxy in /server, which keeps the key in its own environment).
//  * Lecture text is only sent after explicit consent (see requireConsent), and the UI shows
//    what is sent and where.
//  * Generated text is stored as generated (origin 'ai') and never replaces the original.
//  * Numbers in the source must survive translation; missing ones are reported as warnings,
//    and numbers that appear in an output but not in the source are reported too.

import { toWesternDigits } from './quiz.js';

export class AiError extends Error {
  constructor(code, message, extra = {}) {
    super(message);
    this.code = code; // offline | not_configured | no_consent | http | unauthorized | bad_response | timeout
    Object.assign(this, extra);
  }
}

export function requireConsent(settings) {
  if (!settings || !settings.endpoint) throw new AiError('not_configured', 'The AI service is not configured. Open Settings and enter the service address.');
  if (!settings.consent) throw new AiError('no_consent', 'You have not agreed to send lecture text to the external service.');
}

/** Numbers (with decimals) found in a string, normalised to western digits. */
export function extractNumbers(s) {
  return (toWesternDigits(String(s)).match(/\d+(?:[.,]\d+)?/g) || []).map((n) => n.replace(',', '.'));
}

/** Numbers present in the source but missing from the translation (multiset-aware). */
export function missingNumbers(source, translated) {
  const have = new Map();
  for (const n of extractNumbers(translated)) have.set(n, (have.get(n) || 0) + 1);
  const missing = [];
  for (const n of extractNumbers(source)) {
    const c = have.get(n) || 0;
    if (c > 0) have.set(n, c - 1);
    else missing.push(n);
  }
  return missing;
}

/** Numbers that appear in the output but nowhere in the source: possible additions by the model. */
export function addedNumbers(source, output) {
  const src = new Set(extractNumbers(source));
  return [...new Set(extractNumbers(output).filter((n) => !src.has(n)))];
}

export async function callAi(settings, payload, { fetchFn = globalThis.fetch, timeoutMs = 60000, online = () => globalThis.navigator?.onLine !== false } = {}) {
  requireConsent(settings);
  if (!online()) throw new AiError('offline', 'No internet connection. Saved content works offline, but generation needs a connection.');
  const ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctl ? setTimeout(() => ctl.abort(), timeoutMs) : null;
  let resp;
  try {
    resp = await fetchFn(settings.endpoint, {
      method: 'POST',
      headers: { 'content-type': 'application/json', ...(settings.accessCode ? { 'x-access-code': settings.accessCode } : {}) },
      body: JSON.stringify(payload),
      signal: ctl ? ctl.signal : undefined,
      credentials: 'omit',
    });
  } catch (e) {
    if (e && e.name === 'AbortError') throw new AiError('timeout', 'The AI service timed out.');
    throw new AiError('offline', 'Could not reach the AI service. Check the address and your connection.');
  } finally {
    if (timer) clearTimeout(timer);
  }
  if (!resp.ok) {
    let detail = '';
    try { detail = (await resp.json()).error || ''; } catch { /* ignore */ }
    if (resp.status === 401) throw new AiError('unauthorized', 'Wrong or missing access code. Check it in Settings.', { status: 401 });
    throw new AiError('http', `The service rejected the request (${resp.status}). ${detail}`.trim(), { status: resp.status, detail });
  }
  let data;
  try { data = await resp.json(); } catch { throw new AiError('bad_response', 'The service reply is not valid.'); }
  if (!data || typeof data.text !== 'string' || !data.text.trim()) throw new AiError('bad_response', 'The service reply is empty.');
  return { text: data.text, model: data.model || 'unknown' };
}

/** Translate one page. Returns {text, model, warnings: [{code, numbers}]}. */
export async function translatePage(settings, sourceText, opts) {
  const r = await callAi(settings, { task: 'translate', text: sourceText, targetLang: 'ar' }, opts);
  const miss = missingNumbers(sourceText, r.text);
  const warnings = miss.length ? [{ code: 'missing_numbers', numbers: [...new Set(miss)] }] : [];
  return { ...r, warnings };
}

export async function explainPage(settings, sourceText, opts) {
  const r = await callAi(settings, { task: 'explain', text: sourceText, dialect: 'egyptian' }, opts);
  const added = addedNumbers(sourceText, r.text);
  return { ...r, warnings: added.length ? [{ code: 'added_numbers', numbers: added }] : [] };
}

/** Exam-focused key points for one page. */
export async function highYieldPage(settings, sourceText, opts) {
  const r = await callAi(settings, { task: 'highyield', text: sourceText }, opts);
  const added = addedNumbers(sourceText, r.text);
  return { ...r, warnings: added.length ? [{ code: 'added_numbers', numbers: added }] : [] };
}

/** Parse and validate MCQs returned by the AI. Invalid items are dropped and counted. */
export function parseAiQuestions(text) {
  const m = /\[[\s\S]*\]/.exec(text);
  if (!m) return { questions: [], dropped: 0, error: 'no_json' };
  let arr;
  try { arr = JSON.parse(m[0]); } catch { return { questions: [], dropped: 0, error: 'bad_json' }; }
  if (!Array.isArray(arr)) return { questions: [], dropped: 0, error: 'bad_json' };
  const questions = [];
  let dropped = 0;
  for (const q of arr) {
    const ok = q && typeof q.prompt === 'string' && Array.isArray(q.choices) && q.choices.length >= 2 && q.choices.length <= 6
      && q.choices.every((c) => typeof c === 'string') && Number.isInteger(q.answerIndex) && q.answerIndex >= 0 && q.answerIndex < q.choices.length;
    if (ok) questions.push({ prompt: q.prompt, choices: q.choices, answerIndex: q.answerIndex, explanation: typeof q.explanation === 'string' ? q.explanation : '' });
    else dropped++;
  }
  return { questions, dropped, error: null };
}

export async function generateAiQuestions(settings, sourceText, count, opts) {
  const r = await callAi(settings, { task: 'mcq', text: sourceText, count }, opts);
  return { ...parseAiQuestions(r.text), model: r.model };
}

/** Essay questions with a model answer, as JSON [{prompt, modelAnswer}] (answers are NOT verified). */
export function parseAiEssays(text) {
  const m = /\[[\s\S]*\]/.exec(text);
  if (!m) return { items: [], dropped: 0, error: 'no_json' };
  let arr;
  try { arr = JSON.parse(m[0]); } catch { return { items: [], dropped: 0, error: 'bad_json' }; }
  if (!Array.isArray(arr)) return { items: [], dropped: 0, error: 'bad_json' };
  const items = [];
  let dropped = 0;
  for (const q of arr) {
    if (q && typeof q.prompt === 'string' && q.prompt.trim() && typeof q.modelAnswer === 'string' && q.modelAnswer.trim()) items.push({ prompt: q.prompt.trim(), modelAnswer: q.modelAnswer.trim() });
    else dropped++;
  }
  return { items, dropped, error: null };
}

export async function generateAiEssays(settings, sourceText, count, opts) {
  const r = await callAi(settings, { task: 'essay', text: sourceText, count }, opts);
  return { ...parseAiEssays(r.text), model: r.model };
}

// ---------- assistant (chat) ----------

const SEC_LECTURE = /^\s*#{1,3}\s*FROM YOUR LECTURE\s*$/im;
const SEC_EXTRA = /^\s*#{1,3}\s*ADDED KNOWLEDGE[^\n]*$/im;

/**
 * Split the assistant reply into "from your lecture" and "added knowledge" sections and validate
 * citation numbers against the context that was actually sent. Unknown citations are reported.
 */
export function parseChatAnswer(text, contextCount) {
  const mL = SEC_LECTURE.exec(text);
  const mE = SEC_EXTRA.exec(text);
  let lecture = '', extra = '';
  const structured = !!(mL || mE);
  if (structured) {
    // each section runs from the end of its heading line to the start of the next heading (or the end)
    const heads = [mL && { kind: 'lecture', start: mL.index, body: mL.index + mL[0].length }, mE && { kind: 'extra', start: mE.index, body: mE.index + mE[0].length }]
      .filter(Boolean).sort((a, b) => a.start - b.start);
    heads.forEach((h, i) => {
      const end = i + 1 < heads.length ? heads[i + 1].start : text.length;
      const body = text.slice(h.body, end).trim();
      if (h.kind === 'lecture') lecture = body; else extra = body;
    });
  }
  const none = (s) => /^(none|لا يوجد|-|—)\.?$/i.test(s.trim());
  if (none(lecture)) lecture = '';
  if (none(extra)) extra = '';
  const cited = new Set();
  for (const m of (structured ? lecture : text).matchAll(/\[(\d{1,2})\]/g)) cited.add(Number(m[1]));
  const invalid = [...cited].filter((n) => n < 1 || n > contextCount);
  return { structured, lecture, extra, citations: [...cited].filter((n) => !invalid.includes(n)).sort((a, b) => a - b), invalid, raw: text };
}

/**
 * Ask the study assistant. context: [{n, ref, text}] chosen locally from the student's lectures.
 * history: last few turns [{role, content}].
 */
export async function askAssistant(settings, { question, mode = 'ask', context = [], history = [] }, opts) {
  const r = await callAi(settings, { task: 'chat', question, mode, context: context.map(({ n, ref, text }) => ({ n, ref, text })), history: history.slice(-6) }, opts);
  const parsed = parseChatAnswer(r.text, context.length);
  const warnings = [];
  if (!parsed.structured) warnings.push({ code: 'unstructured' });
  if (parsed.invalid.length) warnings.push({ code: 'bad_citations', numbers: parsed.invalid });
  if (parsed.structured && context.length && !parsed.citations.length && parsed.lecture) warnings.push({ code: 'no_citations' });
  const srcText = context.map((c) => c.text).join('\n');
  const added = addedNumbers(srcText + '\n' + question, parsed.lecture || '');
  if (added.length) warnings.push({ code: 'added_numbers', numbers: added });
  return { ...parsed, model: r.model, warnings };
}
