// IndexedDB storage layer. Works in browsers and (with fake-indexeddb) in Node tests.

export const DB_NAME = 'medstudy-ai';
export const DB_VERSION = 2; // v2 adds bookmarks, highlights, dailyStats, examAttempts, achievements, chatMessages (no data is touched)

// store -> secondary indexes (all stores use keyPath "id")
export const SCHEMA = {
  subjects: [],
  lectures: ['subjectId'],
  sourcePages: ['lectureId'],
  originalTexts: ['lectureId', 'pageId'],
  translations: ['lectureId', 'pageId'],
  explanations: ['lectureId', 'pageId'],
  studyNotes: ['lectureId', 'pageId'],
  quizzes: ['lectureId'],
  questions: ['lectureId', 'quizId'],
  answers: ['questionId', 'quizId', 'lectureId'],
  flashcards: ['lectureId'],
  reviewSchedules: ['flashcardId', 'lectureId', 'due'],
  studyTasks: ['lectureId', 'dueDate'],
  examAnalyses: ['subjectId'],
  learningProgress: ['lectureId'],
  cachedAssets: ['lectureId'],
  settings: [],
  bookmarks: ['lectureId', 'pageId'],
  highlights: ['lectureId', 'pageId'],
  dailyStats: [],
  examAttempts: [],
  achievements: [],
  chatMessages: ['conversationId'],
};

// stores whose rows belong to a lecture and are removed with it
const LECTURE_CHILDREN = [
  'sourcePages', 'originalTexts', 'translations', 'explanations', 'studyNotes', 'quizzes',
  'questions', 'answers', 'flashcards', 'reviewSchedules', 'studyTasks', 'learningProgress', 'cachedAssets',
  'bookmarks', 'highlights',
];

const wrap = (req) =>
  new Promise((res, rej) => {
    req.onsuccess = () => res(req.result);
    req.onerror = () => rej(req.error);
  });

const txDone = (tx) =>
  new Promise((res, rej) => {
    tx.oncomplete = () => res();
    tx.onerror = () => rej(tx.error);
    tx.onabort = () => rej(tx.error || new Error('Transaction aborted'));
  });

export class Store {
  constructor(db) {
    this.db = db;
  }

  static async open(name = DB_NAME, idb = globalThis.indexedDB) {
    if (!idb) throw new Error('IndexedDB is not available in this environment');
    const db = await new Promise((res, rej) => {
      const req = idb.open(name, DB_VERSION);
      req.onupgradeneeded = () => {
        const d = req.result;
        for (const [store, indexes] of Object.entries(SCHEMA)) {
          if (d.objectStoreNames.contains(store)) continue;
          const os = d.createObjectStore(store, { keyPath: 'id' });
          for (const ix of indexes) os.createIndex(ix, ix, { unique: false });
        }
      };
      req.onsuccess = () => res(req.result);
      req.onerror = () => rej(req.error);
      req.onblocked = () => rej(new Error('Database upgrade blocked by another tab'));
    });
    return new Store(db);
  }

  close() {
    this.db.close();
  }

  async get(store, id) {
    return wrap(this.db.transaction(store).objectStore(store).get(id));
  }

  async getAll(store) {
    return wrap(this.db.transaction(store).objectStore(store).getAll());
  }

  async getAllBy(store, index, value) {
    return wrap(this.db.transaction(store).objectStore(store).index(index).getAll(value));
  }

  /** Insert or replace one or many rows in a single transaction. Sets updatedAt. */
  async put(store, rows) {
    const list = Array.isArray(rows) ? rows : [rows];
    const tx = this.db.transaction(store, 'readwrite');
    const os = tx.objectStore(store);
    const t = new Date().toISOString();
    for (const r of list) os.put({ ...r, updatedAt: t });
    await txDone(tx);
    return list;
  }

  /** Write rows into several stores atomically: { storeName: [rows] }. */
  async putMany(map, { keepTimestamps = false } = {}) {
    const names = Object.keys(map);
    const tx = this.db.transaction(names, 'readwrite');
    const t = new Date().toISOString();
    for (const n of names) for (const r of map[n]) tx.objectStore(n).put(keepTimestamps ? r : { ...r, updatedAt: t });
    await txDone(tx);
  }

  async delete(store, id) {
    const tx = this.db.transaction(store, 'readwrite');
    tx.objectStore(store).delete(id);
    await txDone(tx);
  }

  async count(store) {
    return wrap(this.db.transaction(store).objectStore(store).count());
  }

  /** Remove a lecture and everything that belongs to it. */
  async deleteLecture(lectureId) {
    const tx = this.db.transaction([...LECTURE_CHILDREN, 'lectures'], 'readwrite');
    for (const s of LECTURE_CHILDREN) {
      const os = tx.objectStore(s);
      if (!os.indexNames.contains('lectureId')) continue;
      const req = os.index('lectureId').openKeyCursor(IDBKeyRange.only(lectureId));
      req.onsuccess = () => {
        const cur = req.result;
        if (cur) {
          os.delete(cur.primaryKey);
          cur.continue();
        }
      };
    }
    tx.objectStore('lectures').delete(lectureId);
    await txDone(tx);
    // exam attempts that were about this lecture only are removed too (multi-lecture attempts are kept)
    const attempts = await this.getAll('examAttempts');
    const mine = attempts.filter((a) => a.lectureIds.length === 1 && a.lectureIds[0] === lectureId);
    for (const a of mine) await this.delete('examAttempts', a.id);
  }

  /** Remove a subject, its lectures, and all their data. */
  async deleteSubject(subjectId) {
    const lectures = await this.getAllBy('lectures', 'subjectId', subjectId);
    for (const l of lectures) await this.deleteLecture(l.id);
    await this.delete('subjects', subjectId);
  }

  /** Wipe every store (used by "delete all local data"). */
  async clearAll() {
    const names = Object.keys(SCHEMA);
    const tx = this.db.transaction(names, 'readwrite');
    for (const n of names) tx.objectStore(n).clear();
    await txDone(tx);
  }

  /** Export every store as plain JSON (blobs in cachedAssets are skipped). */
  async exportAll() {
    const out = { app: 'medstudy-ai', schema: DB_VERSION, exportedAt: new Date().toISOString(), data: {} };
    for (const s of Object.keys(SCHEMA)) {
      const rows = await this.getAll(s);
      out.data[s] = s === 'cachedAssets' ? rows.map(({ blob, ...r }) => r) : rows;
    }
    return out;
  }

  /** Import a backup produced by exportAll (v1 or v2). Validates shape; never executes content. */
  async importAll(json) {
    if (!json || json.app !== 'medstudy-ai' || typeof json.data !== 'object') {
      throw new Error('Not a MedStudy AI backup file');
    }
    const map = {};
    for (const s of Object.keys(SCHEMA)) {
      const rows = json.data[s];
      if (rows === undefined) continue;
      if (!Array.isArray(rows) || rows.some((r) => !r || typeof r.id !== 'string')) {
        throw new Error(`Backup is malformed in "${s}"`);
      }
      map[s] = rows;
    }
    await this.putMany(map, { keepTimestamps: true });
    return Object.fromEntries(Object.entries(map).map(([k, v]) => [k, v.length]));
  }
}

/** Delete the whole database (and with it every stored file). */
export function deleteDatabase(name = DB_NAME, idb = globalThis.indexedDB) {
  return new Promise((res, rej) => {
    const req = idb.deleteDatabase(name);
    req.onsuccess = () => res();
    req.onerror = () => rej(req.error);
    req.onblocked = () => res();
  });
}
