// Reader text helpers (pure): paragraphs, highlight anchoring, and segmentation for rendering.
// The text is always rendered as text nodes (never HTML), segment by segment.

export const HL_COLORS = ['yellow', 'green', 'blue', 'pink'];

/** Paragraph blocks with their character offsets: blank-line separated, or line by line if there are none. */
export function paragraphs(text) {
  const out = [];
  const hasBlank = /\n\s*\n/.test(text);
  const re = hasBlank ? /[^\n](?:[\s\S]*?[^\n])?(?=\n\s*\n|$)/g : /[^\n]+/g;
  for (const m of text.matchAll(re)) {
    if (m[0].trim()) out.push({ index: out.length, start: m.index, end: m.index + m[0].length, text: m[0] });
  }
  return out;
}

/**
 * Re-attach saved highlights to the current text. If the text under [start,end) is still the quoted
 * text it is kept; otherwise the nearest occurrence of the quote is used; otherwise the highlight is
 * reported as orphaned (never silently moved to different words).
 */
export function anchorHighlights(text, highlights) {
  const ok = [];
  const orphans = [];
  for (const h of highlights) {
    if (text.slice(h.start, h.end) === h.text) { ok.push(h); continue; }
    let best = -1;
    let idx = text.indexOf(h.text);
    while (idx !== -1) {
      if (best === -1 || Math.abs(idx - h.start) < Math.abs(best - h.start)) best = idx;
      idx = text.indexOf(h.text, idx + 1);
    }
    if (best === -1) orphans.push(h); else ok.push({ ...h, start: best, end: best + h.text.length });
  }
  return { ok, orphans };
}

const NUM_RE = /\d+(?:[.,]\d+)?(?:\s?[-–]\s?\d+(?:[.,]\d+)?)?(?:\s?(?:%|mg|mcg|µg|kg|g|ml|mL|L|IU|cm|mm|mmHg|days?|weeks?|months?|years?|hours?|hrs?|minutes?|mins?))?/g;
const ABBR_RE = /\b[A-Z]{2,6}\b/g;

/** Ranges of numbers/doses/units and of ABBREVIATIONS, used for the optional "mark numbers" view. */
export function keyTokenRanges(text) {
  const out = [];
  for (const m of text.matchAll(NUM_RE)) out.push({ start: m.index, end: m.index + m[0].length, cls: 'num' });
  for (const m of text.matchAll(ABBR_RE)) out.push({ start: m.index, end: m.index + m[0].length, cls: 'abbr' });
  return out;
}

/**
 * Split text into segments with style classes.
 * layers: { highlights: [{id,start,end,color}], search: [{start,end}], keys: [{start,end,cls}] }
 * Returns [{text, hl: color|null, hlId, search: bool, key: 'num'|'abbr'|null}] covering the whole text in order.
 */
export function segmentText(text, { highlights = [], search = [], keys = [] } = {}) {
  const cuts = new Set([0, text.length]);
  const clamp = (n) => Math.max(0, Math.min(text.length, n));
  for (const r of [...highlights, ...search, ...keys]) { cuts.add(clamp(r.start)); cuts.add(clamp(r.end)); }
  const points = [...cuts].sort((a, b) => a - b);
  const out = [];
  for (let i = 0; i < points.length - 1; i++) {
    const a = points[i], b = points[i + 1];
    if (a === b) continue;
    const covers = (r) => r.start <= a && r.end >= b;
    const hl = [...highlights].reverse().find(covers); // the most recent highlight wins
    const key = keys.find(covers);
    const seg = { text: text.slice(a, b), hl: hl ? hl.color : null, hlId: hl ? hl.id : null, search: search.some(covers), key: key ? key.cls : null };
    const prev = out[out.length - 1];
    if (prev && prev.hl === seg.hl && prev.hlId === seg.hlId && prev.search === seg.search && prev.key === seg.key) prev.text += seg.text;
    else out.push(seg);
  }
  return out;
}

/**
 * Offsets of a DOM selection inside `container` (whose textContent equals the page text).
 * Returns null when the selection is empty or outside the container.
 */
export function selectionOffsets(container, selection) {
  if (!selection || selection.rangeCount === 0 || selection.isCollapsed) return null;
  const range = selection.getRangeAt(0);
  if (!container.contains(range.startContainer) || !container.contains(range.endContainer)) return null;
  const pre = range.cloneRange();
  pre.selectNodeContents(container);
  pre.setEnd(range.startContainer, range.startOffset);
  const start = pre.toString().length;
  const text = range.toString();
  if (!text.trim()) return null;
  return { start, end: start + text.length, text };
}
