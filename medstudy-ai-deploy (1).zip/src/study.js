// Data helpers that combine several stores. UI-free so they can be tested in Node.

import {
  effectiveText, makeReviewSchedule, makeLearningProgress, makeQuiz, makeQuestion, makeAnswer, makeFlashcard, makeExamAttempt,
  makeBookmark, makeHighlight, ORIGIN,
} from './models.js';
import { review, isDue } from './srs.js';
import { buildClozeItems, buildQuestions, buildFlashcards, buildCardsByKind, buildExamQuestions, scoreAttempt } from './quiz.js';
import { onPageOpened, onCardReviewed, onQuestionsAnswered, onExamFinished } from './activity.js';

/** Pages of a lecture with their effective (corrected-if-any) text, in order. */
export async function loadLecturePages(store, lectureId, { includeRemoved = false } = {}) {
  const [pages, texts] = await Promise.all([
    store.getAllBy('sourcePages', 'lectureId', lectureId),
    store.getAllBy('originalTexts', 'lectureId', lectureId),
  ]);
  const byPage = new Map(texts.map((t) => [t.pageId, t]));
  return pages
    .filter((p) => includeRemoved || p.status !== 'removed_in_update')
    .sort((a, b) => a.index - b.index)
    .map((p) => ({ page: p, original: byPage.get(p.id) || null, lectureId, pageId: p.id, index: p.index, text: byPage.get(p.id) ? effectiveText(byPage.get(p.id)) : '' }));
}

/** Pages of several lectures, ready for search / exam generation. */
export async function loadPagesOf(store, lectureIds) {
  const lectures = new Map((await store.getAll('lectures')).map((l) => [l.id, l]));
  const out = [];
  for (const id of lectureIds) {
    const l = lectures.get(id);
    if (!l) continue;
    for (const p of await loadLecturePages(store, id)) out.push({ ...p, title: l.title, label: p.page.label });
  }
  return out;
}

/** Record that a page was opened (marks it read, keeps the resume position, feeds real stats). */
export async function markPageOpened(store, lectureId, pageIdValue, { demo = false } = {}) {
  const lp = (await store.get('learningProgress', `lp_${lectureId}`)) || makeLearningProgress({ lectureId });
  const read = new Set(lp.pagesRead);
  const first = !read.has(pageIdValue);
  read.add(pageIdValue);
  await store.put('learningProgress', { ...lp, pagesRead: [...read], lastOpenedPage: pageIdValue, lastOpenedAt: new Date().toISOString() });
  await onPageOpened(store, { first, demo });
  return { first };
}

/** Where to continue: the most recently opened real lecture and the page index (1-based) to open next. */
export async function resumePoint(store, { includeDemo = false } = {}) {
  const [lps, lectures] = await Promise.all([store.getAll('learningProgress'), store.getAll('lectures')]);
  const byId = new Map(lectures.filter((l) => includeDemo || !l.isDemo).map((l) => [l.id, l]));
  const last = lps.filter((p) => p.lastOpenedAt && byId.has(p.lectureId)).sort((a, b) => b.lastOpenedAt.localeCompare(a.lastOpenedAt))[0];
  if (!last) return null;
  const lecture = byId.get(last.lectureId);
  const pages = (await store.getAllBy('sourcePages', 'lectureId', lecture.id)).filter((p) => p.status !== 'removed_in_update').sort((a, b) => a.index - b.index);
  const cur = pages.find((p) => p.id === last.lastOpenedPage);
  return { lecture, pageIndex: cur ? cur.index : 1, lastOpenedAt: last.lastOpenedAt, pagesRead: last.pagesRead.length, pageCount: pages.length };
}

/** First page not yet read (or page 1 if everything was read). */
export async function nextUnreadIndex(store, lectureId) {
  const lp = await store.get('learningProgress', `lp_${lectureId}`);
  const read = new Set(lp ? lp.pagesRead : []);
  const pages = (await store.getAllBy('sourcePages', 'lectureId', lectureId)).filter((p) => p.status !== 'removed_in_update').sort((a, b) => a.index - b.index);
  const nxt = pages.find((p) => !read.has(p.id));
  return nxt ? nxt.index : 1;
}

// ---------- flashcards ----------

export async function loadDeck(store, lectureId = null, { includeDemo = true } = {}) {
  let cards = lectureId ? await store.getAllBy('flashcards', 'lectureId', lectureId) : await store.getAll('flashcards');
  if (!includeDemo) {
    const demoIds = new Set((await store.getAll('lectures')).filter((l) => l.isDemo).map((l) => l.id));
    cards = cards.filter((c) => !demoIds.has(c.lectureId));
  }
  const scheds = new Map((await store.getAll('reviewSchedules')).map((s) => [s.flashcardId, s]));
  return cards.filter((c) => !c.suspended).map((card) => ({ card, schedule: scheds.get(card.id) || null }));
}

export function buildQueue(deck, now = new Date(), newLimit = 20) {
  const due = deck.filter((d) => d.schedule && isDue(d.schedule, now)).sort((a, b) => a.schedule.due.localeCompare(b.schedule.due));
  const fresh = deck.filter((d) => !d.schedule).slice(0, newLimit);
  return [...due, ...fresh];
}

export async function rateCard(store, entry, rating, now = new Date(), { demo = false } = {}) {
  const base = entry.schedule || makeReviewSchedule({ flashcardId: entry.card.id, lectureId: entry.card.lectureId });
  const next = review(base, rating, now);
  await store.put('reviewSchedules', next);
  await onCardReviewed(store, { rating, demo }, now);
  return next;
}

/** Save new flashcards, skipping ones whose front text already exists in the lecture. */
export async function saveFlashcards(store, lectureId, cards) {
  const existing = new Set((await store.getAllBy('flashcards', 'lectureId', lectureId)).map((c) => c.front));
  const fresh = cards.filter((c) => !existing.has(c.front));
  if (fresh.length) await store.put('flashcards', fresh);
  return { added: fresh.length, skipped: cards.length - fresh.length };
}

export async function generateCards(store, lectureId, { kinds, max = 10, pageIds = null } = {}) {
  let pages = (await loadLecturePages(store, lectureId)).filter((p) => p.text);
  if (pageIds) pages = pages.filter((p) => pageIds.includes(p.pageId));
  const cards = buildCardsByKind(lectureId, pages, { kinds, max, seed: `${lectureId}:${Date.now()}` });
  if (!cards.length) return { added: 0, skipped: 0, none: true };
  return { ...(await saveFlashcards(store, lectureId, cards)), none: false };
}

export async function addManualCard(store, lectureId, { front, back, sourceRef = null }) {
  const card = makeFlashcard({ lectureId, front: front.trim(), back: back.trim(), kind: 'manual', origin: ORIGIN.MANUAL, sourceRef });
  await store.put('flashcards', card);
  return card;
}

export async function updateCard(store, card, { front, back }) {
  const next = { ...card, front: front.trim(), back: back.trim() };
  await store.put('flashcards', next);
  return next;
}

export async function deleteCard(store, cardId) {
  await store.delete('flashcards', cardId);
  await store.delete('reviewSchedules', `rs_${cardId}`);
}

// ---------- quizzes ----------

/** Rule-based quiz from the lecture's current text. Answers are verbatim from the source. */
export async function generateRuleQuiz(store, lectureId, { count = 10, title, pageIds = null } = {}) {
  let pages = (await loadLecturePages(store, lectureId)).filter((p) => p.text);
  if (pageIds) pages = pages.filter((p) => pageIds.includes(p.pageId));
  const seed = `${lectureId}:${Date.now()}`;
  const items = buildClozeItems(pages, { max: count, seed });
  if (!items.length) return { quiz: null, questions: [], reason: 'no_candidates' };
  const quiz = makeQuiz({ lectureId, title: title || `Quiz ${new Date().toISOString().slice(0, 10)}`, origin: ORIGIN.RULE });
  const questions = buildQuestions(lectureId, items, { seed, quizId: quiz.id });
  quiz.questionIds = questions.map((q) => q.id);
  await store.putMany({ quizzes: [quiz], questions });
  return { quiz, questions, items };
}

/** Save AI-generated questions. They are stored unverified until the user confirms them. */
export async function saveAiQuiz(store, lectureId, aiQuestions, { title, model }) {
  const quiz = makeQuiz({ lectureId, title: title || 'AI quiz', origin: ORIGIN.AI });
  const questions = aiQuestions.map((q) => makeQuestion({
    lectureId, quizId: quiz.id, type: 'mcq', prompt: q.prompt, choices: q.choices, correctAnswer: q.answerIndex,
    explanation: q.explanation, origin: ORIGIN.AI, verified: false,
  }));
  quiz.questionIds = questions.map((q) => q.id);
  quiz.model = model;
  await store.putMany({ quizzes: [quiz], questions });
  return { quiz, questions };
}

/** Essay questions: from the AI (model answer NOT verified) or typed by the student (their own model answer). */
export async function saveEssayQuestions(store, lectureId, items, { origin, model = null }) {
  const questions = items.map((it) => makeQuestion({
    lectureId, quizId: null, type: 'essay', prompt: it.prompt, correctAnswer: it.modelAnswer, explanation: it.modelAnswer,
    origin, verified: origin === ORIGIN.MANUAL, sourceRef: it.pageId ? { pageId: it.pageId } : null,
  }));
  await store.put('questions', questions);
  return questions;
}

/**
 * Grade a finished attempt, store answers + the attempt record, and feed the real statistics.
 * entries: [{question, response, selfRating?}]. Questions that are not stored yet are stored first.
 */
export async function submitExam(store, { title, kind = 'exam', lectureIds, config = {}, entries, startedAt, timeLimitSec = null, timedOut = false, demo = false }) {
  const score = scoreAttempt(entries);
  const finishedAt = new Date().toISOString();
  const attempt = makeExamAttempt({
    title, kind, lectureIds, config, startedAt, finishedAt, timeLimitSec, timedOut,
    durationSec: Math.max(0, Math.round((new Date(finishedAt) - new Date(startedAt)) / 1000)),
    entries: entries.map((e, i) => ({ questionId: e.question.id, response: e.response ?? null, correct: score.results[i].gradable ? !!score.results[i].correct : null, selfRating: e.selfRating ?? null })),
    graded: score.graded, correct: score.correct, percent: score.percent,
  });
  const have = new Set((await store.getAll('questions')).map((q) => q.id));
  const toSave = entries.map((e) => e.question).filter((q) => !have.has(q.id));
  const answers = entries.map((e, i) => makeAnswer({
    questionId: e.question.id, quizId: e.question.quizId, lectureId: e.question.lectureId, attemptId: attempt.id, response: e.response ?? null,
    correct: score.results[i].gradable ? (score.results[i].partial ? false : !!score.results[i].correct) : null, selfRating: e.selfRating ?? null,
  }));
  await store.putMany({ questions: toSave, answers, examAttempts: [attempt] });
  const answered = entries.filter((e, i) => score.results[i].gradable).length;
  await onQuestionsAnswered(store, { answered, correct: Math.round(score.correct), demo });
  await onExamFinished(store, { percent: score.percent, demo });
  return { score, attempt };
}

/** Old API kept for the lecture quiz screen: a quiz attempt. */
export async function submitAttempt(store, quiz, entries, extra = {}) {
  const { score } = await submitExam(store, {
    title: quiz.title, kind: 'quiz', lectureIds: [quiz.lectureId], config: { quizId: quiz.id }, entries,
    startedAt: extra.startedAt || new Date().toISOString(), demo: !!extra.demo,
  });
  return score;
}

/** Attempts, oldest first. Optionally only those about one lecture. */
export async function attemptsHistory(store, { lectureId = null } = {}) {
  const all = await store.getAll('examAttempts');
  return all.filter((a) => !lectureId || a.lectureIds.includes(lectureId)).sort((a, b) => a.finishedAt.localeCompare(b.finishedAt));
}

/** Build an exam over several lectures (not saved until it is taken). */
export async function buildCustomExam(store, { lectureIds, count, difficulty, types, topic, seed }) {
  const pages = (await loadPagesOf(store, lectureIds)).filter((p) => p.text);
  const questions = buildExamQuestions(pages, { count, difficulty, types, topic, seed: seed || `exam:${Date.now()}` });
  return { questions, pagesUsed: pages.length };
}

/** Questions of an earlier attempt that were answered wrongly (for the retake). */
export async function wrongQuestionsOf(store, attempt) {
  const wrongIds = attempt.entries.filter((e) => e.correct === false || (e.selfRating !== null && e.selfRating < 1)).map((e) => e.questionId);
  const all = new Map((await store.getAll('questions')).map((q) => [q.id, q]));
  return wrongIds.map((id) => all.get(id)).filter(Boolean);
}

// ---------- bookmarks / highlights ----------

export async function toggleBookmark(store, { lectureId, pageId, paragraphIndex, snippet }) {
  const rows = (await store.getAllBy('bookmarks', 'pageId', pageId)).filter((b) => b.paragraphIndex === paragraphIndex);
  if (rows.length) { for (const r of rows) await store.delete('bookmarks', r.id); return null; }
  const b = makeBookmark({ lectureId, pageId, paragraphIndex, snippet });
  await store.put('bookmarks', b);
  return b;
}

export async function addHighlight(store, { lectureId, pageId, start, end, text, color }) {
  const h = makeHighlight({ lectureId, pageId, start, end, text, color });
  await store.put('highlights', h);
  return h;
}

export { buildFlashcards, buildClozeItems };
