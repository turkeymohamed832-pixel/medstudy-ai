// Text search and retrieval helpers (pure). Used by the library search, in-lecture search and the assistant.

const DIACRITICS = /[ً-ٟـ]/g; // Arabic tashkeel + tatweel

/** Lowercase, strip Arabic diacritics and unify alef/ya/ta-marbuta forms so Arabic search is forgiving. */
export function normalizeForSearch(s) {
  return String(s)
    .toLowerCase()
    .replace(DIACRITICS, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه');
}

export function tokenize(s) {
  return (normalizeForSearch(s).match(/[\p{L}\p{N}]+/gu) || []).filter((w) => w.length > 1 || /\d/.test(w));
}

const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

/** Ranges of the query inside the ORIGINAL text (case-insensitive, whole phrase or each word). */
export function highlightRanges(text, query) {
  const q = query.trim();
  if (!q) return [];
  const words = [...new Set([q, ...q.split(/\s+/).filter((w) => w.length > 1)])];
  const re = new RegExp(words.map(escapeRe).sort((a, b) => b.length - a.length).join('|'), 'giu');
  const out = [];
  for (const m of text.matchAll(re)) out.push({ start: m.index, end: m.index + m[0].length });
  return out;
}

export function makeSnippet(text, query, radius = 70) {
  const r = highlightRanges(text, query)[0];
  const flat = (s) => s.replace(/\s+/g, ' ');
  if (!r) return flat(text.slice(0, radius * 2)).trim();
  const from = Math.max(0, r.start - radius);
  const to = Math.min(text.length, r.end + radius);
  return (from > 0 ? '…' : '') + flat(text.slice(from, to)).trim() + (to < text.length ? '…' : '');
}

/**
 * Find pages containing ALL words of the query (accent-insensitive). pages: [{lectureId,pageId,index,text,label?}].
 * Returns [{lectureId,pageId,index,count,snippet}] best first, at most `limit`.
 */
export function searchPages(pages, query, { limit = 100 } = {}) {
  const toks = tokenize(query);
  if (!toks.length) return [];
  const phrase = normalizeForSearch(query.trim());
  const out = [];
  for (const p of pages) {
    const n = normalizeForSearch(p.text);
    if (!toks.every((t) => n.includes(t))) continue;
    let count = 0;
    for (const t of toks) count += n.split(t).length - 1;
    if (n.includes(phrase)) count += 5;
    out.push({ lectureId: p.lectureId, pageId: p.pageId, index: p.index, count, snippet: makeSnippet(p.text, query) });
  }
  return out.sort((a, b) => b.count - a.count).slice(0, limit);
}

/**
 * Retrieve the pages most relevant to a question (BM25-style) within a character budget.
 * Used to build the assistant's context locally, so only relevant pages are ever sent.
 * Returns [{...page, score}] best first.
 */
export function rankPages(pages, question, { k = 6, maxChars = 12000 } = {}) {
  const toks = [...new Set(tokenize(question))];
  const live = pages.filter((p) => p.text && p.text.trim());
  if (!toks.length || !live.length) return [];
  const docs = live.map((p) => {
    const words = tokenize(p.text);
    const tf = new Map();
    for (const w of words) tf.set(w, (tf.get(w) || 0) + 1);
    return { p, tf, len: words.length || 1 };
  });
  const avg = docs.reduce((s, d) => s + d.len, 0) / docs.length;
  const df = new Map();
  for (const t of toks) df.set(t, docs.filter((d) => d.tf.has(t)).length);
  const scored = docs.map((d) => {
    let score = 0;
    for (const t of toks) {
      const f = d.tf.get(t) || 0;
      if (!f) continue;
      const idf = Math.log(1 + (docs.length - df.get(t) + 0.5) / (df.get(t) + 0.5));
      score += idf * ((f * 2.2) / (f + 1.2 * (0.25 + 0.75 * (d.len / avg))));
    }
    return { ...d.p, score };
  }).filter((x) => x.score > 0).sort((a, b) => b.score - a.score);
  const out = [];
  let used = 0;
  for (const x of scored) {
    if (out.length >= k) break;
    const len = Math.min(x.text.length, 2500);
    if (used + len > maxChars && out.length) break;
    used += len;
    out.push(x);
  }
  return out;
}

/**
 * Heuristic headings of a page: short first lines, ALL-CAPS lines, numbered lines.
 * Heuristic only (slides/PDFs have no reliable heading markup), so the UI labels it as such.
 */
export function findHeadings(text) {
  const lines = text.split('\n');
  const out = [];
  lines.forEach((raw, i) => {
    const line = raw.trim();
    if (!line || line.length > 80 || /^\[Speaker notes\]$/.test(line)) return;
    const caps = /[A-Z]{3}/.test(line) && line === line.toUpperCase() && !/\d{3,}/.test(line);
    const numbered = /^(\d+(\.\d+)*[.)]|[IVX]+\.)\s+\S/.test(line);
    const first = i === 0 && line.length <= 70 && !/[.:;,]$/.test(line);
    if (caps || numbered || first) out.push({ line: i, text: line });
  });
  return out;
}
