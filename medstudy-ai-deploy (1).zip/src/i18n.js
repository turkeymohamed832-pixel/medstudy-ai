// Tiny i18n: dictionaries per language, {param} interpolation, falls back to Arabic then to the key itself.
import ar from './i18n/ar.js';
import en from './i18n/en.js';

export const DICTS = { ar, en };
let lang = 'ar';

export function setLang(l) {
  lang = DICTS[l] ? l : 'ar';
  if (typeof document !== 'undefined') {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }
  try { localStorage.setItem('ms_lang', lang); } catch { /* ignore */ }
  // keep ctx.lang in sync without importing ctx (avoids a cycle)
  import('./ctx.js').then((m) => { m.ctx.lang = lang; });
}
export const getLang = () => lang;

export function t(key, params) {
  let s = DICTS[lang][key] ?? DICTS.ar[key] ?? key;
  if (params) s = s.replace(/\{(\w+)\}/g, (m, k) => (params[k] ?? m));
  return s;
}
