// Loads everything the dashboard / progress / achievements screens need from the store and computes
// the real statistics with the pure functions in stats.js. Demo lectures and everything attached to them
// are excluded, so sample data can never show up as the student's own results.

import { dateStr, weekDays } from './planner.js';
import {
  lectureCompletion, overallProgress, computeWeakPoints, computeStreak, isActiveDay, computeReadiness, levelInfo, weekProgress, DEFAULT_GOAL,
} from './stats.js';
import { scheduleStats } from './srs.js';

export async function loadSnapshot(store, now = new Date()) {
  const today = dateStr(now);
  const [allLectures, subjects, allPages, progressRows, dailyStats, answersAll, questionsAll, cardsAll, schedulesAll, tasksAll, attemptsAll, achievements, settingsRows] = await Promise.all([
    store.getAll('lectures'), store.getAll('subjects'), store.getAll('sourcePages'), store.getAll('learningProgress'), store.getAll('dailyStats'),
    store.getAll('answers'), store.getAll('questions'), store.getAll('flashcards'), store.getAll('reviewSchedules'), store.getAll('studyTasks'),
    store.getAll('examAttempts'), store.getAll('achievements'), store.getAll('settings'),
  ]);
  const settings = Object.fromEntries(settingsRows.map((r) => [r.id, r.value]));
  const lectures = allLectures.filter((l) => !l.isDemo);
  const ids = new Set(lectures.map((l) => l.id));
  const pagesByLecture = new Map();
  for (const p of allPages) {
    if (!ids.has(p.lectureId)) continue;
    if (!pagesByLecture.has(p.lectureId)) pagesByLecture.set(p.lectureId, []);
    pagesByLecture.get(p.lectureId).push(p);
  }
  const progress = new Map(progressRows.map((p) => [p.lectureId, p]));
  const completions = lectures.map((l) => lectureCompletion(l, pagesByLecture.get(l.id) || [], progress.get(l.id)));
  const overall = overallProgress(completions);

  const answers = answersAll.filter((a) => ids.has(a.lectureId));
  const questions = new Map(questionsAll.filter((q) => ids.has(q.lectureId)).map((q) => [q.id, q]));
  const cards = new Map(cardsAll.filter((c) => ids.has(c.lectureId)).map((c) => [c.id, c]));
  const schedules = schedulesAll.filter((s) => cards.has(s.flashcardId));
  const tasks = tasksAll.filter((t) => !t.lectureId || ids.has(t.lectureId));
  const attempts = attemptsAll.filter((a) => a.lectureIds.length && a.lectureIds.every((id) => ids.has(id)));

  const weak = computeWeakPoints({ answers, questions, schedules, cards });
  const activeDates = new Set(dailyStats.filter(isActiveDay).map((d) => d.date));
  const streak = computeStreak(activeDates, today);
  const goal = { ...DEFAULT_GOAL, ...(settings.goal || {}) };
  const weekStart = settings.weekStart ?? 6;
  const week = weekProgress(dailyStats, today, goal, weekStart);

  const graded = answers.filter((a) => a.correct !== null && a.correct !== undefined);
  const ninety = new Date(now.getTime() - 90 * 86400000).toISOString();
  const recent = graded.filter((a) => a.createdAt >= ninety);
  const readiness = computeReadiness({
    pagesRead: overall.read, pagesTotal: overall.total, gradedAnswers: recent.length, correctAnswers: recent.filter((a) => a.correct).length,
    schedules, cardCount: cards.size,
  });
  const xpTotal = dailyStats.reduce((s, d) => s + (d.xp || 0), 0);
  const deck = scheduleStats(schedules, now);
  const planWork = tasks.filter((t) => t.kind !== 'exam');
  const percents = attempts.map((a) => a.percent).filter((p) => p !== null);
  const badgeInput = {
    lectures: lectures.length,
    completedLectures: completions.filter((c) => c.complete).length,
    attempts: attempts.length,
    bestPercent: percents.length ? Math.max(...percents) : null,
    totalQuestions: dailyStats.reduce((s, d) => s + (d.questions || 0), 0),
    totalCards: dailyStats.reduce((s, d) => s + (d.cards || 0), 0),
    mature: deck.mature,
    bestStreak: streak.best,
    weekMet: week.met,
    planTasks: planWork.length,
    planDone: planWork.filter((t) => t.done).length,
  };
  return {
    today, now, settings, subjects, lectures, allLectures, pagesByLecture, progress, completions, overall, dailyStats, answers, questions, cards, schedules,
    deck, tasks, attempts, weak, streak, week, weekStart, readiness, xpTotal, level: levelInfo(xpTotal), achievements, badgeInput,
    todayStat: dailyStats.find((d) => d.date === today) || null,
    weekDates: weekDays(today, weekStart),
  };
}
