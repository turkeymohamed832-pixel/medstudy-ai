// Real-data statistics. Pure functions: they take plain arrays/maps and return numbers.
// Nothing here invents data: with too little data they return null / "missing" instead of a score.

import { addDays, daysBetween, weekDays } from './planner.js';
import { cardMastery } from './srs.js';

// ---------- completion ----------

/** Reading completion of one lecture. `complete` only when EVERY page was opened. */
export function lectureCompletion(lecture, pages, progress) {
  const live = pages.filter((p) => p.status !== 'removed_in_update');
  const readSet = new Set(progress ? progress.pagesRead : []);
  const read = live.filter((p) => readSet.has(p.id)).length;
  const total = live.length;
  const issues = live.filter((p) => p.status !== 'ok').length;
  return { lectureId: lecture.id, read, total, issues, percent: total ? Math.round((read / total) * 100) : 0, complete: total > 0 && read >= total };
}

export function overallProgress(completions) {
  const read = completions.reduce((s, c) => s + c.read, 0);
  const total = completions.reduce((s, c) => s + c.total, 0);
  return { read, total, percent: total ? Math.round((read / total) * 100) : null, completedLectures: completions.filter((c) => c.complete).length, lectures: completions.length };
}

// ---------- weak points ----------

/**
 * Pages where the student keeps getting questions wrong or forgetting cards.
 * answers: [{questionId, correct}]; questions: Map id -> question; schedules: [{flashcardId, lapses}]; cards: Map id -> card.
 * Returns [{lectureId, pageId, total, wrong, lapses, score, rate}] sorted worst first (only "weak" ones).
 */
export function computeWeakPoints({ answers, questions, schedules, cards }) {
  const map = new Map();
  const get = (lectureId, pageId) => {
    const k = `${lectureId}|${pageId}`;
    if (!map.has(k)) map.set(k, { lectureId, pageId, total: 0, wrong: 0, lapses: 0 });
    return map.get(k);
  };
  for (const a of answers) {
    if (a.correct === null || a.correct === undefined) continue;
    const q = questions.get(a.questionId);
    if (!q || !q.sourceRef || !q.sourceRef.pageId) continue;
    const e = get(q.lectureId, q.sourceRef.pageId);
    e.total++;
    if (!a.correct) e.wrong++;
  }
  for (const s of schedules) {
    if (!s.lapses) continue;
    const c = cards.get(s.flashcardId);
    if (!c || !c.sourceRef || !c.sourceRef.pageId) continue;
    get(c.lectureId, c.sourceRef.pageId).lapses += s.lapses;
  }
  return [...map.values()]
    .map((e) => ({ ...e, score: e.wrong + e.lapses, rate: e.total ? e.wrong / e.total : 0 }))
    .filter((e) => (e.wrong >= 2 && e.rate >= 0.5) || e.lapses >= 2 || (e.wrong >= 1 && e.lapses >= 1))
    .sort((a, b) => b.score - a.score || b.rate - a.rate);
}

// ---------- streak ----------

export const isActiveDay = (d) => !!d && (d.seconds >= 60 || d.questions > 0 || d.cards > 0 || d.tasks > 0 || d.newPages > 0);

/**
 * Consecutive active days. If today has no activity yet the streak is counted up to yesterday, so a
 * streak is never "lost" just because the day is not over. A missed day only resets the counter.
 */
export function computeStreak(activeDates, today) {
  const set = activeDates instanceof Set ? activeDates : new Set(activeDates);
  let d = set.has(today) ? today : addDays(today, -1);
  let current = 0;
  while (set.has(d)) { current++; d = addDays(d, -1); }
  const sorted = [...set].sort();
  let best = 0, run = 0, prev = null;
  for (const date of sorted) {
    run = prev && daysBetween(prev, date) === 1 ? run + 1 : 1;
    best = Math.max(best, run);
    prev = date;
  }
  return { current, best, activeToday: set.has(today) };
}

// ---------- readiness ----------

export const READINESS_WEIGHTS = { coverage: 0.35, accuracy: 0.45, cards: 0.2 };
export const READINESS_MIN = { gradedAnswers: 10, cards: 10, reviewedCards: 5 };

/**
 * Exam readiness from REAL study data. Returns { score: null, missing } when there is not enough data.
 * It is an estimate of preparation, not a prediction of the exam mark.
 * input: { pagesRead, pagesTotal, gradedAnswers, correctAnswers, schedules: [..], cardCount }
 */
export function computeReadiness({ pagesRead, pagesTotal, gradedAnswers, correctAnswers, schedules, cardCount }) {
  const parts = {};
  if (pagesTotal > 0) parts.coverage = { value: pagesRead / pagesTotal, weight: READINESS_WEIGHTS.coverage };
  if (gradedAnswers >= READINESS_MIN.gradedAnswers) parts.accuracy = { value: correctAnswers / gradedAnswers, weight: READINESS_WEIGHTS.accuracy };
  const reviewed = schedules.filter((s) => s.lastReviewed).length;
  if (cardCount >= READINESS_MIN.cards && reviewed >= READINESS_MIN.reviewedCards) {
    parts.cards = { value: schedules.reduce((s, x) => s + cardMastery(x), 0) / cardCount, weight: READINESS_WEIGHTS.cards };
  }
  const missing = [];
  if (!parts.coverage) missing.push('coverage');
  if (!parts.accuracy) missing.push('accuracy');
  if (!parts.cards) missing.push('cards');
  if (!parts.coverage || Object.keys(parts).length < 2) return { score: null, missing, parts: {} };
  const w = Object.values(parts).reduce((s, p) => s + p.weight, 0);
  const score = Math.round((Object.values(parts).reduce((s, p) => s + p.value * p.weight, 0) / w) * 100);
  const band = score >= 70 ? 'good' : score >= 40 ? 'medium' : 'low';
  const out = {};
  for (const [k, p] of Object.entries(parts)) out[k] = Math.round(p.value * 100);
  return { score, band, missing, parts: out };
}

// ---------- XP, levels, goals ----------

export const XP = { newPage: 2, card: 1, cardGood: 2, question: 1, questionCorrect: 2, task: 5, exam: 10, examGood: 5, cardsDailyCap: 100 };

export const xpForLevel = (level) => 40 * (level - 1) * (level - 1);
export function levelInfo(xp) {
  const level = Math.floor(Math.sqrt(Math.max(0, xp) / 40)) + 1;
  const cur = xpForLevel(level);
  const next = xpForLevel(level + 1);
  return { level, xp, into: xp - cur, span: next - cur, percent: Math.round(((xp - cur) / (next - cur)) * 100) };
}

export const DEFAULT_GOAL = { minutes: 120, questions: 30 };

/** Progress of this calendar week's goals from real daily stats. */
export function weekProgress(dailyStats, today, goal = DEFAULT_GOAL, weekStart = 6) {
  const days = weekDays(today, weekStart);
  const set = new Set(days);
  let seconds = 0, questions = 0;
  for (const d of dailyStats) if (set.has(d.date)) { seconds += d.seconds; questions += d.questions; }
  const minutes = Math.floor(seconds / 60);
  return {
    days, minutes, questions, goal,
    minutesPct: Math.min(100, Math.round((minutes / goal.minutes) * 100)),
    questionsPct: Math.min(100, Math.round((questions / goal.questions) * 100)),
    met: minutes >= goal.minutes && questions >= goal.questions,
  };
}

// ---------- badges (all computed from real data) ----------

/** snapshot: { lectures, completions, attempts, dailyStats, streak, tasks, weekMet, mature } */
export const BADGES = [
  { key: 'first_lecture', icon: '📘', test: (s) => s.lectures >= 1, progress: (s) => ({ cur: Math.min(1, s.lectures), target: 1 }) },
  { key: 'first_complete', icon: '✅', test: (s) => s.completedLectures >= 1, progress: (s) => ({ cur: Math.min(1, s.completedLectures), target: 1 }) },
  { key: 'first_exam', icon: '📝', test: (s) => s.attempts >= 1, progress: (s) => ({ cur: Math.min(1, s.attempts), target: 1 }) },
  { key: 'exam_80', icon: '🎯', test: (s) => s.bestPercent !== null && s.bestPercent >= 80, progress: (s) => ({ cur: Math.min(80, s.bestPercent || 0), target: 80 }) },
  { key: 'questions_100', icon: '❓', test: (s) => s.totalQuestions >= 100, progress: (s) => ({ cur: Math.min(100, s.totalQuestions), target: 100 }) },
  { key: 'card_expert', icon: '🃏', test: (s) => s.totalCards >= 100 && s.mature >= 10, progress: (s) => ({ cur: Math.min(100, s.totalCards), target: 100 }) },
  { key: 'streak_3', icon: '🔥', test: (s) => s.bestStreak >= 3, progress: (s) => ({ cur: Math.min(3, s.bestStreak), target: 3 }) },
  { key: 'streak_7', icon: '🌟', test: (s) => s.bestStreak >= 7, progress: (s) => ({ cur: Math.min(7, s.bestStreak), target: 7 }) },
  { key: 'weekly_goal', icon: '🏁', test: (s) => !!s.weekMet, progress: (s) => ({ cur: s.weekMet ? 1 : 0, target: 1 }) },
  { key: 'plan_done', icon: '🗓️', test: (s) => s.planTasks >= 3 && s.planDone >= s.planTasks, progress: (s) => ({ cur: s.planDone, target: Math.max(3, s.planTasks) }) },
];

export const evaluateBadges = (snapshot) => BADGES.map((b) => ({ key: b.key, icon: b.icon, earned: b.test(snapshot), ...b.progress(snapshot) }));
