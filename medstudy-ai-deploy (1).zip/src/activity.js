// Real activity tracking: daily aggregates, XP, study time, achievements.
// Only real study counts: demo content never produces stats, XP or badges.

import { makeDailyStat, makeAchievement } from './models.js';
import { dateStr } from './planner.js';
import { XP, evaluateBadges } from './stats.js';
import { loadSnapshot } from './stats-data.js';

/** Add numbers to today's aggregate (creates it on first use). */
export async function bump(store, delta, now = new Date()) {
  const date = dateStr(now);
  const cur = (await store.get('dailyStats', `ds_${date}`)) || makeDailyStat(date);
  const next = { ...cur };
  for (const [k, v] of Object.entries(delta)) if (v) next[k] = (next[k] || 0) + v;
  await store.put('dailyStats', next);
  return next;
}

export const onPageOpened = (store, { first, demo = false }, now) =>
  demo ? null : bump(store, { pages: 1, newPages: first ? 1 : 0, xp: first ? XP.newPage : 0 }, now);

export async function onCardReviewed(store, { rating, demo = false }, now = new Date()) {
  if (demo) return null;
  const cur = await store.get('dailyStats', `ds_${dateStr(now)}`);
  const room = Math.max(0, XP.cardsDailyCap - (cur ? cur.cardXp || 0 : 0));
  const gain = Math.min(room, rating === 'good' || rating === 'easy' ? XP.cardGood : XP.card);
  return bump(store, { cards: 1, cardXp: gain, xp: gain }, now);
}

export const onQuestionsAnswered = (store, { answered, correct, demo = false }, now) =>
  demo || !answered ? null : bump(store, { questions: answered, correct, xp: answered * XP.question + correct * XP.questionCorrect }, now);

export const onTaskDone = (store, now) => bump(store, { tasks: 1, xp: XP.task }, now);

export const onExamFinished = (store, { percent, demo = false }, now) =>
  demo ? null : bump(store, { exams: 1, xp: XP.exam + (percent !== null && percent >= 80 ? XP.examGood : 0) }, now);

export const addStudySeconds = (store, seconds, now) => (seconds > 0 ? bump(store, { seconds }, now) : null);

/**
 * Study-time tracker. Time only counts while the app is visible, a study screen is open and there was
 * input in the last `idleMs`. Each tick adds at most `maxTick` ms, so a forgotten open tab adds nothing.
 */
export function createTracker({ store, now = () => Date.now(), isVisible = () => (typeof document === 'undefined' ? true : document.visibilityState !== 'hidden'), idleMs = 90000, maxTick = 20000, flushAt = 15 } = {}) {
  let last = now();
  let lastTouch = now();
  let active = false;
  let pending = 0; // ms
  let demo = false;
  return {
    touch() { lastTouch = now(); },
    setActive(on, isDemo = false) { active = on; demo = isDemo; last = now(); },
    tick() {
      const t = now();
      const elapsed = Math.min(t - last, maxTick);
      last = t;
      if (active && !demo && isVisible() && t - lastTouch < idleMs) pending += Math.max(0, elapsed);
      return pending;
    },
    async flush(force = false) {
      const secs = Math.floor(pending / 1000);
      if (secs >= flushAt || (secs > 0 && force)) {
        pending -= secs * 1000;
        await addStudySeconds(store, secs, new Date(now()));
        return secs;
      }
      return 0;
    },
    get pendingMs() { return pending; },
  };
}

/** Persist badges that are now earned. Returns the keys unlocked by THIS call (for the celebration). */
export async function checkAchievements(store, now = new Date()) {
  const snap = await loadSnapshot(store, now);
  const have = new Set((await store.getAll('achievements')).map((a) => a.key));
  const fresh = evaluateBadges(snap.badgeInput).filter((b) => b.earned && !have.has(b.key));
  if (fresh.length) await store.put('achievements', fresh.map((b) => makeAchievement({ key: b.key, unlockedAt: now.toISOString() })));
  return fresh.map((b) => b.key);
}
