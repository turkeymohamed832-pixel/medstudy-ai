// Shared application context (store, language, settings). One object so screens stay small.
export const ctx = {
  store: null,
  lang: 'ar',
  settings: {},
  loaders: null,
  tracker: null,
  online: () => globalThis.navigator?.onLine !== false,
  navigate: (hash) => { location.hash = hash; },
  refreshChrome: () => {},
};
export async function loadSettings() {
  const rows = await ctx.store.getAll('settings');
  ctx.settings = Object.fromEntries(rows.map((r) => [r.id, r.value]));
  return ctx.settings;
}
export async function setSetting(key, value) {
  const { makeSetting } = await import('./models.js');
  await ctx.store.put('settings', makeSetting(key, value));
  ctx.settings = { ...ctx.settings, [key]: value };
}
