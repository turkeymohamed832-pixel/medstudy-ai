// Runs before first paint (external file because the CSP forbids inline scripts): applies the saved theme/language
// so there is no flash of the wrong colors or direction.
try {
  const t = localStorage.getItem('ms_theme') || 'auto';
  const dark = t === 'dark' || (t === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  const l = localStorage.getItem('ms_lang') || 'ar';
  document.documentElement.lang = l; document.documentElement.dir = l === 'ar' ? 'rtl' : 'ltr';
} catch { /* storage unavailable: defaults (light, Arabic) stay */ }
