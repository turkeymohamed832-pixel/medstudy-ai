// server/prompts.js
var RULES = `Rules: keep every number, dose, unit, range and abbreviation exactly as in the source text (never convert units, never round). Do not add facts that are not in the text. If something in the text looks like an error, keep it and add a short note at the end starting with "Note:".`;
var MODES = {
  ask: "Answer the question.",
  explain_term: "Explain the medical term or concept simply and accurately.",
  translate: "Translate the requested passage into clear medical Arabic (keep standard English medical terms in parentheses).",
  simplify: "Simplify the mechanism step by step, as if teaching a first-year nursing student.",
  compare: "Compare the items asked about in a compact markdown table (rows = features), then one short sentence of takeaway.",
  mcq: "Write 5 multiple-choice questions (4 options each) with the answer key, based ONLY on the sources.",
  tf: "Write 6 true/false statements with the answer key, based ONLY on the sources.",
  summary: "Write a concise revision summary as bullet points."
};
var CHAT_LIMITS = { question: 2e3, context: 8, history: 6, turn: 4e3 };
var isStr = (v) => typeof v === "string";
function buildPrompt(data) {
  const { task } = data || {};
  switch (task) {
    case "translate":
      if (!isStr(data.text)) return null;
      return {
        system: `You translate medical and nursing lecture text from English into clear Modern Standard Arabic for a nursing student. Keep standard medical terms in English in parentheses after the Arabic term the first time they appear. ${RULES} Output only the translation.`,
        user: data.text
      };
    case "explain":
      if (!isStr(data.text)) return null;
      return {
        system: `You are a tutor explaining a nursing lecture page to an Egyptian nursing student in simple Egyptian Arabic (\u0639\u0627\u0645\u064A\u0629 \u0645\u0635\u0631\u064A\u0629 \u0628\u0633\u064A\u0637\u0629). Keep the English medical terms as they are. Explain what the page says step by step, using only the content of the page; no outside facts. ${RULES}`,
        user: data.text
      };
    case "highyield":
      if (!isStr(data.text)) return null;
      return {
        system: `You pick the exam-focused ("high-yield") points from ONE lecture page for a nursing student. Output at most 8 short bullet points in English, most testable first, using ONLY facts stated on the page (numbers, doses, definitions, classifications, steps). Do not add outside knowledge. ${RULES}`,
        user: data.text
      };
    case "mcq":
      if (!isStr(data.text)) return null;
      return {
        system: `You write exam questions from lecture text. Write exactly ${Math.min(Math.max(Number(data.count) || 8, 1), 20)} multiple-choice questions in English, each with 4 choices and exactly one correct answer that is directly supported by the text. Output ONLY a JSON array, no prose, with objects of the form {"prompt": string, "choices": [string, string, string, string], "answerIndex": number, "explanation": string}. ${RULES}`,
        user: data.text
      };
    case "essay":
      if (!isStr(data.text)) return null;
      return {
        system: `You write essay (written exam) questions from lecture text for a nursing student. Write exactly ${Math.min(Math.max(Number(data.count) || 3, 1), 8)} questions in English, each answerable from the text, with a model answer that uses ONLY facts in the text. Output ONLY a JSON array, no prose, with objects of the form {"prompt": string, "modelAnswer": string}. ${RULES}`,
        user: data.text
      };
    case "chat": {
      if (!isStr(data.question) || !data.question.trim() || data.question.length > CHAT_LIMITS.question) return null;
      const ctx = Array.isArray(data.context) ? data.context : [];
      if (ctx.length > CHAT_LIMITS.context || ctx.some((c) => !c || !Number.isInteger(c.n) || !isStr(c.ref) || !isStr(c.text))) return null;
      const hist = Array.isArray(data.history) ? data.history : [];
      if (hist.length > CHAT_LIMITS.history || hist.some((h) => !h || !["user", "assistant"].includes(h.role) || !isStr(h.content) || h.content.length > CHAT_LIMITS.turn)) return null;
      const mode = MODES[data.mode] ? data.mode : "ask";
      const sources = ctx.length ? ctx.map((c) => `[${c.n}] ${c.ref}
${c.text}`).join("\n\n") : "(no excerpts were found for this question)";
      const past = hist.length ? `

Previous conversation:
${hist.map((h) => `${h.role === "user" ? "Student" : "Assistant"}: ${h.content}`).join("\n")}` : "";
      return {
        system: `You are a study assistant for a nursing/medical student. The student's own lecture excerpts are given as numbered sources [1], [2], \u2026 Answer in the language of the question (Arabic question \u2192 Arabic answer, keeping medical terms in English). Use EXACTLY these two markdown headings, in this order:
## FROM YOUR LECTURE
Only what the excerpts state, each statement followed by its source number like [2]. If the excerpts do not cover it, write "None".
## ADDED KNOWLEDGE (NOT IN YOUR LECTURE)
General medical knowledge that is NOT in the excerpts, clearly kept separate and brief, with no source numbers. Write "None" if you add nothing.
Never invent sources, page numbers, quotes or references. Keep every number, dose, unit and abbreviation exactly as in the excerpts and never convert units. This is educational support, not clinical advice. Task: ${MODES[mode]}`,
        user: `SOURCES:
${sources}${past}

QUESTION:
${data.question}`
      };
    }
    default:
      return null;
  }
}

// server/core.js
var MAX_BODY_CHARS = 2e5;
function safeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
var TOKENS = { mcq: 4e3, essay: 3500, chat: 2500, highyield: 1200 };
async function handleStudy({ body, accessCode }, env, { requireAccessCode = true, fetchFn = globalThis.fetch } = {}) {
  const expected = env.ACCESS_CODE || "";
  if (requireAccessCode && !expected) {
    return { status: 500, json: { error: "Server is not configured: set the ACCESS_CODE secret." } };
  }
  if (expected && !safeEqual(accessCode || "", expected)) {
    return { status: 401, json: { error: "Wrong or missing access code" } };
  }
  if (typeof body !== "string" || body.length > MAX_BODY_CHARS) return { status: 413, json: { error: "Request too large" } };
  let data;
  try {
    data = JSON.parse(body);
  } catch {
    return { status: 400, json: { error: "Invalid JSON" } };
  }
  if (data && data.task === "ping") return { status: 200, json: { text: "ok", model: "proxy" } };
  const maxChars = Number(env.MAX_CHARS) || 2e4;
  if (data && typeof data.text === "string" && data.text.length > maxChars) return { status: 413, json: { error: `Text longer than ${maxChars} characters` } };
  if (data && data.task === "chat" && Array.isArray(data.context) && data.context.reduce((s, c) => s + (typeof c?.text === "string" ? c.text.length : 0), 0) > maxChars) {
    return { status: 413, json: { error: `Context longer than ${maxChars} characters` } };
  }
  const p = data ? buildPrompt(data) : null;
  if (!p) return { status: 400, json: { error: "Unknown task or invalid request" } };
  if (!env.ANTHROPIC_API_KEY) return { status: 500, json: { error: "Server has no ANTHROPIC_API_KEY configured" } };
  const model = env.MODEL || "claude-sonnet-5-5";
  try {
    const r = await fetchFn(env.UPSTREAM_URL || "https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model, max_tokens: TOKENS[data.task] || 3e3, system: p.system, messages: [{ role: "user", content: p.user }] })
    });
    if (!r.ok) return { status: 502, json: { error: `Upstream error ${r.status}` } };
    const out = await r.json();
    const text = (out.content || []).filter((b) => b.type === "text").map((b) => b.text).join("");
    if (!text.trim()) return { status: 502, json: { error: "Empty upstream response" } };
    return { status: 200, json: { text, model: out.model || model } };
  } catch {
    return { status: 502, json: { error: "Upstream unreachable" } };
  }
}

// functions/api/study.js
var json = (status, obj) => new Response(JSON.stringify(obj), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });
async function onRequestPost({ request, env }) {
  const origin = request.headers.get("origin");
  if (origin && origin !== new URL(request.url).origin) return json(403, { error: "Cross-origin requests are not allowed" });
  const body = await request.text();
  const r = await handleStudy({ body, accessCode: request.headers.get("x-access-code") }, env, { requireAccessCode: true });
  return json(r.status, r.json);
}

// worker/csp.js
var CSP = "default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; style-src 'self'; img-src 'self' data: blob:; font-src 'self'; worker-src 'self' blob:; connect-src 'self' https: http://localhost:* http://127.0.0.1:*; object-src 'none'; base-uri 'self'; form-action 'none'; frame-ancestors 'none'";

// worker/index.js
var NO_CACHE = /* @__PURE__ */ new Set(["/", "/index.html", "/sw.js", "/manifest.webmanifest", "/theme-init.js"]);
var index_default = {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/api/study") {
      if (request.method === "POST") return onRequestPost({ request, env });
      return new Response(JSON.stringify({ error: "POST only" }), { status: 405, headers: { "content-type": "application/json", allow: "POST" } });
    }
    const res = await env.ASSETS.fetch(request);
    const headers = new Headers(res.headers);
    headers.set("Content-Security-Policy", CSP);
    headers.set("X-Content-Type-Options", "nosniff");
    headers.set("Referrer-Policy", "no-referrer");
    headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
    if (NO_CACHE.has(url.pathname)) headers.set("Cache-Control", "no-cache");
    return new Response(res.body, { status: res.status, statusText: res.statusText, headers });
  }
};
export {
  index_default as default
};
